"""
@author: phelg
References:
-pandas:Data structures for statistical computing in python, McKinney, Proceedings of the 9th Python in Science Conference, Volume 445, 2010.
-numpy:Harris, C.R., Millman, K.J., van der Walt, S.J. et al. Array programming with NumPy. Nature 585, 357–362 (2020). DOI: 10.1038/s41586-020-2649-2. (Publisher link).
-seaborn:Waskom, M. L., (2021). seaborn: statistical data visualization. Journal of Open Source Software, 6(60), 3021, https://doi.org/10.21105/joss.03021
-fun2: Christian Mücher, Financial Econometrics tutorials and Advanced Topics in Econometrics tutorials. Summer Semester 2022. University of Freiburg.
-garches: Kevin Sheppard (2021, March 3). bashtage/arch: Release 4.18 (Version v4.18). Zenodo. https://doi.org/10.5281/zenodo.593254
-Matplotlib: A 2D Graphics Environment", Computing in Science & Engineering, vol. 9, no. 3, pp. 90-95, 2007.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import scipy.stats as stats
sns.set(color_codes=True)
np.set_printoptions(precision = 4,suppress=True)

data_CTS = pd.read_csv('cts_1sec.csv', sep=',' , header = None)
data_BTS=pd.read_csv('bts_1sec.csv', sep=',' , header = None)
data_TTS=pd.read_csv('tts_1sec.csv', sep=',' , header = None)
data_TT=pd.read_csv('tt_1sec.csv', sep=',' , header = None)
data_TRTS=pd.read_csv('trts_1sec.csv', sep=',' , header = None)
data_DA=pd.read_csv('da_1sec.csv', sep=',' , header = None)
data_WSD=pd.read_csv('wsd_1sec.csv', sep=',' , header = None)

data_CTS = data_CTS.astype(float, errors='ignore')
day_CTS = np.unique(data_CTS[0])
time_CTS = data_CTS[1][:23401].values
price_CTS = data_CTS[data_CTS.columns[2]].values

data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:23401].values
price_BTS = data_BTS[data_BTS.columns[2]].values

data_TTS = data_TTS.astype(float, errors='ignore')
day_TTS = np.unique(data_TTS[0])
time_TTS = data_TTS[1][:23401].values
price_TTS = data_TTS[data_TTS.columns[2]].values

data_TT = data_TT.astype(float, errors='ignore')
day_TT = np.unique(data_TT[0])
time_TT = data_TT[1][:23401].values
price_TT = data_TT[data_TTS.columns[2]].values

data_TRTS = data_TRTS.astype(float, errors='ignore')
day_TRTS = np.unique(data_TRTS[0])
time_TRTS = data_TRTS[1][:23401].values
price_TRTS = data_TRTS[data_TRTS.columns[2]].values

data_DA = data_DA.astype(float, errors='ignore')
day_DA = np.unique(data_DA[0])
time_DA = data_DA[1][:23401].values
price_DA = data_DA[data_DA.columns[2]].values

data_WSD = data_WSD.astype(float, errors='ignore')
day_WSD = np.unique(data_WSD[0])
time_WSD = data_WSD[1][:23401].values
price_WSD = data_WSD[data_WSD.columns[2]].values

P_CTS = np.zeros([23401,len(day_CTS)])
for i in range(len(day_CTS)):
    P_CTS[:,i] = price_CTS[i*23401:(i+1)*23401]
intraday_returns_CTS = np.diff(np.log(P_CTS),axis=0)
#the days are shown horizontally and
#the timepoints are on the vertical axis

# RV_CTS_1s=pd.DataFrame(np.sum(intraday_returns_CTS**2,axis=0))
# with pd.ExcelWriter('RV CTS 1second.xlsx') as writer:  
#     RV_CTS_1s.to_excel(writer, sheet_name='Realized Variances')

# dailyret_CTS_1s=np.sum(intraday_returns_CTS,axis=0)
# with pd.ExcelWriter('dailyret CTS 1second.xlsx') as writer:  
#     RV_CTS_1s.to_excel(writer, sheet_name='Daily Returns')


P_BTS = np.zeros([23401,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*23401:(i+1)*23401]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

P_TTS = np.zeros([23401,len(day_TTS)])
for i in range(len(day_TTS)):
    P_TTS[:,i] = price_TTS[i*23401:(i+1)*23401]
intraday_returns_TTS = np.diff(np.log(P_TTS),axis=0)

#new sampling schemes: TT, TRTS, DA,SBTS,WSD
P_TT = np.zeros([23401,len(day_TT)])
for i in range(len(day_TT)):
    P_TT[:,i] = price_TT[i*23401:(i+1)*23401]
intraday_returns_TT = np.diff(np.log(P_TT),axis=0)

P_TRTS = np.zeros([23401,len(day_TRTS)])
for i in range(len(day_TRTS)):
    P_TRTS[:,i] = price_TRTS[i*23401:(i+1)*23401]
intraday_returns_TRTS = np.diff(np.log(P_TRTS),axis=0)

P_DA = np.zeros([23401,len(day_DA)])
for i in range(len(day_DA)):
    P_DA[:,i] = price_DA[i*23401:(i+1)*23401]
intraday_returns_DA = np.diff(np.log(P_DA),axis=0)

P_WSD = np.zeros([23401,len(day_WSD)])
for i in range(len(day_WSD)):
    P_WSD[:,i] = price_WSD[i*23401:(i+1)*23401]
intraday_returns_WSD = np.diff(np.log(P_WSD),axis=0)

def my_aggret(x,freq,flat=True):
    T = x.shape[1]
    l = int(np.floor(23400/freq))
    out = np.zeros([l,T])
    for i in range(l):
        out[i,:] = np.sum(x[i*freq:(i+1)*freq,:],axis=0)
    if flat == True:
        out = np.reshape(out.T,[l*T])
    return out


#CTS
def avg_RV_CTS(x):
    # define the average realized variances as a function of the frequency
   RV_table=pd.DataFrame(np.zeros([1]))
   for i in x:
           i=int(i)
           aux_CTS = my_aggret(intraday_returns_CTS,i,False)
           rv_CTS = np.sum(aux_CTS**2,axis=0)
           # plt.plot(i,np.mean(rv_CTS),marker='.',markersize=15,color='b')
           RV_table.insert(i,i,np.mean(rv_CTS))
   return RV_table

freq = np.arange(1,1800,1)
RV_est_CTS=avg_RV_CTS(freq).iloc[: , 1:].iloc[0 ,:].values

#standardize variables first
from NonParametrics import NonParametrics as NP
H = np.arange(0.5,1.5,0.1).round(4)
m_RV_est_CTS,s_RV_est_CTS = RV_est_CTS.mean(),RV_est_CTS.std()
RV_est_CTS = (RV_est_CTS-m_RV_est_CTS)/s_RV_est_CTS
m_freq,s_freq = freq.mean(),freq.std()
freq = (freq-m_freq)/s_freq
RV_est_CTS_freq = NP.Regression(RV_est_CTS,freq).fit(h='CV',CV_grid=H)
h_WE_CTS = RV_est_CTS_freq.h
RV_est_CTS_freq.plot()

#BTS
def avg_RV_BTS(x):
    # define the average realized variances as a function of the frequency
    RV_table=pd.DataFrame(np.zeros([1]))
    for i in x:
           i=int(i)
           aux_BTS = my_aggret(intraday_returns_BTS,i,False)
           rv_BTS = np.sum(aux_BTS**2,axis=0)
           # plt.plot(i,np.mean(rv_CTS),marker='.',markersize=15,color='b')
           RV_table.insert(i,i,np.mean(rv_BTS))
    return RV_table

freq = np.arange(1,1800,1)
RV_est_BTS=avg_RV_BTS(freq).iloc[: , 1:].iloc[0 ,:].values

#standardize variables first:
H = np.arange(0.5,1.5,0.1).round(4)
m_RV_est_BTS,s_RV_est_BTS = RV_est_BTS.mean(),RV_est_BTS.std()
RV_est_BTS = (RV_est_BTS-m_RV_est_BTS)/s_RV_est_BTS
m_freq,s_freq = freq.mean(),freq.std()
freq = (freq-m_freq)/s_freq
RV_est_BTS_freq = NP.Regression(RV_est_BTS,freq).fit(h='CV',CV_grid=H)
h_WE_BTS = RV_est_BTS_freq.h
RV_est_BTS_freq.plot()


#TTS
def avg_RV_TTS(x):
    # define the average realized variances as a function of the frequency
    RV_table=pd.DataFrame(np.zeros([1]))
    for i in x:
           i=int(i)
           aux_TTS = my_aggret(intraday_returns_TTS,i,False)
           rv_TTS = np.sum(aux_TTS**2,axis=0)
           # plt.plot(i,np.mean(rv_CTS),marker='.',markersize=15,color='b')
           RV_table.insert(i,i,np.mean(rv_TTS))
    return RV_table

freq = np.arange(1,1800,1)
RV_est_TTS=avg_RV_TTS(freq).iloc[: , 1:].iloc[0 ,:].values

#standardize variables first:
H = np.arange(0.5,1.5,0.1).round(4)
m_RV_est_TTS,s_RV_est_TTS = RV_est_TTS.mean(),RV_est_TTS.std()
RV_est_TTS = (RV_est_TTS-m_RV_est_TTS)/s_RV_est_TTS
m_freq,s_freq = freq.mean(),freq.std()
freq = (freq-m_freq)/s_freq
RV_est_TTS_freq = NP.Regression(RV_est_TTS,freq).fit(h='CV',CV_grid=H)
h_WE_TTS = RV_est_TTS_freq.h
RV_est_TTS_freq.plot()

#TT
def avg_RV_TT(x):
    RV_table=pd.DataFrame(np.zeros([1]))
    for i in x:
           i=int(i)
           aux_TT = my_aggret(intraday_returns_TT,i,False)
           rv_TT = np.sum(aux_TT**2,axis=0)
           RV_table.insert(i,i,np.mean(rv_TT))
    return RV_table

freq = np.arange(1,1800,1)
RV_est_TT=avg_RV_TT(freq).iloc[: , 1:].iloc[0 ,:].values

H = np.arange(0.5,1.5,0.1).round(4)
m_RV_est_TT,s_RV_est_TT = RV_est_TT.mean(),RV_est_TT.std()
RV_est_TT = (RV_est_TT-m_RV_est_TT)/s_RV_est_TT
m_freq,s_freq = freq.mean(),freq.std()
freq = (freq-m_freq)/s_freq
RV_est_TT_freq = NP.Regression(RV_est_TT,freq).fit(h='CV',CV_grid=H)
RV_est_TT_freq.plot()

#TRTS
def avg_RV_TRTS(x):
    RV_table=pd.DataFrame(np.zeros([1]))
    for i in x:
           i=int(i)
           aux_TRTS = my_aggret(intraday_returns_TRTS,i,False)
           rv_TRTS = np.sum(aux_TRTS**2,axis=0)
           RV_table.insert(i,i,np.mean(rv_TRTS))
    return RV_table

freq = np.arange(1,1800,1)
RV_est_TRTS=avg_RV_TRTS(freq).iloc[: , 1:].iloc[0 ,:].values

H = np.arange(0.5,1.5,0.1).round(4)
m_RV_est_TRTS,s_RV_est_TRTS = RV_est_TRTS.mean(),RV_est_TRTS.std()
RV_est_TRTS = (RV_est_TRTS-m_RV_est_TRTS)/s_RV_est_TRTS
m_freq,s_freq = freq.mean(),freq.std()
freq = (freq-m_freq)/s_freq
RV_est_TRTS_freq = NP.Regression(RV_est_TRTS,freq).fit(h='CV',CV_grid=H)
RV_est_TRTS_freq.plot()

#DA
def avg_RV_DA(x):
    RV_table=pd.DataFrame(np.zeros([1]))
    for i in x:
           i=int(i)
           aux_DA = my_aggret(intraday_returns_DA,i,False)
           rv_DA = np.sum(aux_DA**2,axis=0)
           RV_table.insert(i,i,np.mean(rv_DA))
    return RV_table

freq = np.arange(1,1800,1)
RV_est_DA=avg_RV_DA(freq).iloc[: , 1:].iloc[0 ,:].values

H = np.arange(0.5,1.5,0.1).round(4)
m_RV_est_DA,s_RV_est_DA = RV_est_DA.mean(),RV_est_DA.std()
RV_est_DA = (RV_est_DA-m_RV_est_DA)/s_RV_est_DA
m_freq,s_freq = freq.mean(),freq.std()
freq = (freq-m_freq)/s_freq
RV_est_DA_freq = NP.Regression(RV_est_DA,freq).fit(h='CV',CV_grid=H)
RV_est_DA_freq.plot()

#WSD
def avg_RV_WSD(x):
    RV_table=pd.DataFrame(np.zeros([1]))
    for i in x:
           i=int(i)
           aux_WSD = my_aggret(intraday_returns_WSD,i,False)
           rv_WSD = np.sum(aux_WSD**2,axis=0)
           RV_table.insert(i,i,np.mean(rv_WSD))
    return RV_table

freq = np.arange(1,1800,1)
RV_est_WSD=avg_RV_WSD(freq).iloc[: , 1:].iloc[0 ,:].values

H = np.arange(0.5,1.5,0.1).round(4)
m_RV_est_WSD,s_RV_est_WSD = RV_est_WSD.mean(),RV_est_WSD.std()
RV_est_WSD = (RV_est_WSD-m_RV_est_WSD)/s_RV_est_WSD
m_freq,s_freq = freq.mean(),freq.std()
freq = (freq-m_freq)/s_freq
RV_est_WSD_freq = NP.Regression(RV_est_WSD,freq).fit(h='CV',CV_grid=H)
RV_est_WSD_freq.plot()

RV_est_CTS_freq.my_regression()
RV_est_BTS_freq.my_regression()
RV_est_TTS_freq.my_regression()
RV_est_TT_freq.my_regression()
RV_est_TRTS_freq.my_regression()
RV_est_DA_freq.my_regression()
RV_est_WSD_freq.my_regression()

#save mean and std. into Excel:
mean=pd.DataFrame()
mean.insert(0,'mean_CTS', m_RV_est_CTS)
# RV_est_CTS.mean(),RV_est_CTS.std()
mean.insert(1,'mean_BTS', m_RV_est_BTS)
mean.insert(2,'mean_TTS', m_RV_est_TTS)
mean.insert(3,'mean_TT', m_RV_est_TT)
mean.insert(4,'mean_TRTS', m_RV_est_TRTS)
mean.insert(5,'mean_WSD', m_RV_est_WSD)
mean.insert(6,'mean_DA', m_RV_est_DA)

std=pd.DataFrame()
std.insert(0, 'std_CTS', s_RV_est_CTS)
std.insert(1, 'std_BTS', s_RV_est_BTS)
std.insert(2, 'std_TTS', s_RV_est_TTS)
std.insert(3, 'std_TT', s_RV_est_TT)
std.insert(4, 'std_TRTS', s_RV_est_TRTS)
std.insert(5, 'std_WSD', s_RV_est_WSD)
std.insert(6, 'std_DA', s_RV_est_DA)


with pd.ExcelWriter('Mean_and_Std.xlsx') as writer:  
    mean.to_excel(writer, sheet_name='Mean')
    std.to_excel(writer, sheet_name='Std')
    
estimate_CTS=pd.DataFrame()
estimate_CTS.insert(0,'grid',RV_est_CTS_freq.grid)
estimate_CTS.insert(1,'aux',RV_est_CTS_freq.aux)
raw_CTS=pd.DataFrame()
raw_CTS.insert(0,'X',RV_est_CTS_freq.X)
raw_CTS.insert(1,'Y',RV_est_CTS_freq.Y)

estimate_BTS=pd.DataFrame()
estimate_BTS.insert(0,'grid',RV_est_BTS_freq.grid)
estimate_BTS.insert(1,'aux',RV_est_BTS_freq.aux)
raw_BTS=pd.DataFrame()
raw_BTS.insert(0,'X',RV_est_BTS_freq.X)
raw_BTS.insert(1,'Y',RV_est_BTS_freq.Y)

estimate_TTS=pd.DataFrame()
estimate_TTS.insert(0,'grid',RV_est_TTS_freq.grid)
estimate_TTS.insert(1,'aux',RV_est_TTS_freq.aux)
raw_TTS=pd.DataFrame()
raw_TTS.insert(0,'X',RV_est_TTS_freq.X)
raw_TTS.insert(1,'Y',RV_est_TTS_freq.Y)

estimate_TT=pd.DataFrame()
estimate_TT.insert(0,'grid',RV_est_TT_freq.grid)
estimate_TT.insert(1,'aux',RV_est_TT_freq.aux)
raw_TT=pd.DataFrame()
raw_TT.insert(0,'X',RV_est_TT_freq.X)
raw_TT.insert(1,'Y',RV_est_TT_freq.Y)

estimate_TRTS=pd.DataFrame()
estimate_TRTS.insert(0,'grid',RV_est_TRTS_freq.grid)
estimate_TRTS.insert(1,'aux',RV_est_TRTS_freq.aux)
raw_TRTS=pd.DataFrame()
raw_TRTS.insert(0,'X',RV_est_TRTS_freq.X)
raw_TRTS.insert(1,'Y',RV_est_TRTS_freq.Y)

estimate_DA=pd.DataFrame()
estimate_DA.insert(0,'grid',RV_est_DA_freq.grid)
estimate_DA.insert(1,'aux',RV_est_DA_freq.aux)
raw_DA=pd.DataFrame()
raw_DA.insert(0,'X',RV_est_DA_freq.X)
raw_DA.insert(1,'Y',RV_est_DA_freq.Y)

estimate_WSD=pd.DataFrame()
estimate_WSD.insert(0,'grid',RV_est_WSD_freq.grid)
estimate_WSD.insert(1,'aux',RV_est_WSD_freq.aux)
raw_WSD=pd.DataFrame()
raw_WSD.insert(0,'X',RV_est_WSD_freq.X)
raw_WSD.insert(1,'Y',RV_est_WSD_freq.Y)


with pd.ExcelWriter('Results_for_plot_all_schemes.xlsx') as writer:  
    estimate_CTS.to_excel(writer, sheet_name='estimate_CTS')
    raw_CTS.to_excel(writer, sheet_name='raw_CTS')
    estimate_BTS.to_excel(writer, sheet_name='estimate_BTS')
    raw_BTS.to_excel(writer, sheet_name='raw_BTS')
    estimate_TTS.to_excel(writer, sheet_name='estimate_TTS')
    raw_TTS.to_excel(writer, sheet_name='raw_TTS')
    #new sampling schemes: TT, TRTS, DA,SBTS,WSD
    estimate_TT.to_excel(writer, sheet_name='estimate_TT')
    raw_TT.to_excel(writer, sheet_name='raw_TT')
    estimate_TRTS.to_excel(writer, sheet_name='estimate_TRTS')
    raw_TRTS.to_excel(writer, sheet_name='raw_TRTS')
    estimate_DA.to_excel(writer, sheet_name='estimate_DA')
    raw_DA.to_excel(writer, sheet_name='raw_DA')
    # estimate_SBTS.to_excel(writer, sheet_name='estimate_SBTS')
    # raw_SBTS.to_excel(writer, sheet_name='raw_SBTS')
    estimate_WSD.to_excel(writer, sheet_name='estimate_WSD')
    raw_WSD.to_excel(writer, sheet_name='raw_WSD')

#############save the Conf. Iv.
ConfidenceInterval=pd.DataFrame()
ConfidenceInterval.insert(0,'ci_CTS',ci_CTS)

with pd.ExcelWriter('Confidence Interval.xlsx') as writer:  
    ConfidenceInterval.to_excel(writer)