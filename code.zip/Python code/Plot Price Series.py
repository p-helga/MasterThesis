
"""
This code was prepared to analyze the price and return processes.
References:
-pandas:Data structures for statistical computing in python, McKinney, Proceedings of the 9th Python in Science Conference, Volume 445, 2010.
-numpy:Harris, C.R., Millman, K.J., van der Walt, S.J. et al. Array programming with NumPy. Nature 585, 357–362 (2020). DOI: 10.1038/s41586-020-2649-2. (Publisher link).
-seaborn:Waskom, M. L., (2021). seaborn: statistical data visualization. Journal of Open Source Software, 6(60), 3021, https://doi.org/10.21105/joss.03021
-fun2: Christian Mücher, Financial Econometrics tutorials and Advanced Topics in Econometrics tutorials. Summer Semester 2022. University of Freiburg.
-garches: Kevin Sheppard (2021, March 3). bashtage/arch: Release 4.18 (Version v4.18). Zenodo. https://doi.org/10.5281/zenodo.593254
-Matplotlib: A 2D Graphics Environment", Computing in Science & Engineering, vol. 9, no. 3, pp. 90-95, 2007.
"""
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
sns.set(color_codes=True)
np.set_printoptions(precision = 4,suppress=True)
#fun2 was created for the Financial Econometrics tutorials and made available by Christian Mücher in the Summer Semester 2022 at the University of Freiburg.
from fun2 import aggret, spacf_plot,dstats
from fun2 import JB_test
from statsmodels.api import qqplot
import statsmodels
import scipy.stats as stats

#1 second
data_CTS = pd.read_csv('cts_1sec.csv', sep=',' , header = None)
data_BTS=pd.read_csv('bts_1sec.csv', sep=',' , header = None)
data_TTS=pd.read_csv('tts_1sec.csv', sep=',' , header = None)
data_TT=pd.read_csv('tt_1sec.csv', sep=',' , header = None)
data_TRTS=pd.read_csv('trts_1sec.csv', sep=',' , header = None)
data_WSD=pd.read_csv('wsd_1sec.csv', sep=',' , header = None)
data_DA=pd.read_csv('da_1sec.csv', sep=',' , header = None)

data_CTS = data_CTS.astype(float, errors='ignore')
day_CTS = np.unique(data_CTS[0])
time_CTS = data_CTS[1][:23401].values
price_CTS = data_CTS[data_CTS.columns[2]].values

data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:23401].values
price_BTS = data_BTS[data_BTS.columns[2]].values

data_TTS = data_TTS.astype(float, errors='ignore')
day_TTS = np.unique(data_TTS[0])
time_TTS = data_TTS[1][:23401].values
price_TTS = data_TTS[data_TTS.columns[2]].values

data_TT = data_TT.astype(float, errors='ignore')
day_TT = np.unique(data_TT[0])
time_TT = data_TT[1][:23401].values
price_TT = data_TT[data_TT.columns[2]].values

data_TRTS = data_TRTS.astype(float, errors='ignore')
day_TRTS = np.unique(data_TRTS[0])
time_TRTS = data_TRTS[1][:23401].values
price_TRTS = data_TRTS[data_TRTS.columns[2]].values

data_WSD = data_WSD.astype(float, errors='ignore')
day_WSD = np.unique(data_WSD[0])
time_WSD = data_WSD[1][:23401].values
price_WSD = data_WSD[data_WSD.columns[2]].values

data_DA = data_DA.astype(float, errors='ignore')
day_DA = np.unique(data_DA[0])
time_DA = data_DA[1][:23401].values
price_DA = data_DA[data_DA.columns[2]].values

P_CTS = np.zeros([23401,len(day_CTS)])
for i in range(len(day_CTS)):
    P_CTS[:,i] = price_CTS[i*23401:(i+1)*23401]
intraday_returns_CTS = np.diff(np.log(P_CTS),axis=0) 
#the days are shown horizontally and
#the timepoints are on the vertical axis

P_BTS = np.zeros([23401,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*23401:(i+1)*23401]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

P_TTS = np.zeros([23401,len(day_TTS)])
for i in range(len(day_TTS)):
    P_TTS[:,i] = price_TTS[i*23401:(i+1)*23401]
intraday_returns_TTS = np.diff(np.log(P_TTS),axis=0)

P_TT = np.zeros([391,len(day_TT)])
for i in range(len(day_TT)):
    P_TT[:,i] = price_TT[i*391:(i+1)*391]
intraday_returns_TT = np.diff(np.log(P_TT),axis=0)

P_TRTS = np.zeros([391,len(day_TRTS)])
for i in range(len(day_TRTS)):
    P_TRTS[:,i] = price_TRTS[i*391:(i+1)*391]
intraday_returns_TRTS = np.diff(np.log(P_TRTS),axis=0)

P_WSD = np.zeros([391,len(day_WSD)])
for i in range(len(day_WSD)):
    P_WSD[:,i] = price_WSD[i*391:(i+1)*391]
intraday_returns_WSD = np.diff(np.log(P_WSD),axis=0)

P_DA = np.zeros([391,len(day_DA)])
for i in range(len(day_DA)):
    P_DA[:,i] = price_DA[i*391:(i+1)*391]
intraday_returns_DA = np.diff(np.log(P_DA),axis=0)


rv_CTS=np.sum(intraday_returns_CTS**2,axis=0)
rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)
rv_TTS=np.sum(intraday_returns_TTS**2,axis=0)
rv_TT=np.sum(intraday_returns_TT**2,axis=0)
rv_TRTS=np.sum(intraday_returns_TRTS**2,axis=0)
rv_WSD=np.sum(intraday_returns_WSD**2,axis=0)
rv_DA=np.sum(intraday_returns_DA**2,axis=0)

dailyret_CTS=np.sum(intraday_returns_CTS,axis=0)
dailyret_BTS=np.sum(intraday_returns_BTS,axis=0)
dailyret_TTS=np.sum(intraday_returns_TTS,axis=0)
dailyret_TT=np.sum(intraday_returns_TT,axis=0)
dailyret_TRTS=np.sum(intraday_returns_TRTS,axis=0)
dailyret_WSD=np.sum(intraday_returns_WSD,axis=0)
dailyret_DA=np.sum(intraday_returns_DA,axis=0)


fig,ax = plt.subplots()
plt.plot(price_CTS,label='CTS',color='#ADD8E6')
plt.plot(price_BTS,label='BTS',color='#FF4500')
plt.plot(price_TTS,label='TTS',color='#90EE90')
plt.plot(price_TT,label='TT',color='#FF0000')
plt.plot(price_TRTS,label='TRTS',color='#9370DB')
plt.plot(price_WSD,label='WSD',color='#FFB6C1')
plt.plot(price_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Prices in Euros',fontsize=15)
plt.xlabel('Observations',fontsize=15)
plt.title('IBM stock prices between 2001 and 2019, sampled every second')

fig,ax = plt.subplots()
plt.plot(rv_CTS,label='CTS',color='#ADD8E6')
plt.plot(rv_BTS,label='BTS',color='#FF4500')
plt.plot(rv_TTS,label='TTS',color='#90EE90')
plt.plot(rv_TT,label='TT',color='#FF0000')
plt.plot(rv_TRTS,label='TRTS',color='#9370DB')
plt.plot(rv_WSD,label='WSD',color='#FFB6C1')
plt.plot(rv_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('RV',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock RV between 2001 and 2019, sampled every second')

fig,ax = plt.subplots()
plt.plot(dailyret_CTS,label='CTS',color='#ADD8E6')
plt.plot(dailyret_BTS,label='BTS',color='#FF4500')
plt.plot(dailyret_TTS,label='TTS',color='#90EE90')
plt.plot(dailyret_TT,label='TT',color='#FF0000')
plt.plot(dailyret_TRTS,label='TRTS',color='#9370DB')
plt.plot(dailyret_WSD,label='WSD',color='#FFB6C1')
plt.plot(dailyret_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Daily Returns',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock daily returns between 2001 and 2019, sampled every second')

##ACF and PACF
spacf_plot(rv_CTS,lags = 500)
spacf_plot(rv_BTS,lags = 500)
spacf_plot(rv_TTS,lags = 500)
spacf_plot(rv_TT,lags = 500)
spacf_plot(rv_TRTS,lags = 500)
spacf_plot(rv_WSD,lags = 500)
spacf_plot(rv_DA,lags = 500)

#standardized log returns
stdlr_CTS=dailyret_CTS/np.sqrt(rv_CTS)
stdlr_BTS=dailyret_BTS/np.sqrt(rv_BTS)
stdlr_TTS=dailyret_TTS/np.sqrt(rv_TTS)
stdlr_TT=dailyret_TT/np.sqrt(rv_TT)
stdlr_TRTS=dailyret_TRTS/np.sqrt(rv_TRTS)
stdlr_WSD=dailyret_WSD/np.sqrt(rv_WSD)
stdlr_DA=dailyret_DA/np.sqrt(rv_DA)

#JB test:
JB = pd.DataFrame(columns = ('CTS', 'BTS', 'TTS', 'TT', 'TRTS', 'WSD', 'DA'))
JB['CTS'] = JB_test(stdlr_CTS).reshape([2,])
JB['BTS'] = JB_test(stdlr_BTS).reshape([2,])
JB['TTS'] = JB_test(stdlr_TTS).reshape([2,])
JB['TT'] = JB_test(stdlr_TT).reshape([2,])
JB['TRTS'] = JB_test(stdlr_TRTS).reshape([2,])
JB['WSD'] = JB_test(stdlr_WSD).reshape([2,])
JB['DA'] = JB_test(stdlr_DA).reshape([2,])

with pd.ExcelWriter('JB_1s_all_schemes.xlsx') as writer:
    JB.to_excel(writer, sheet_name='JB_test_1s')

#Compare the descriptive statistics
summary_statistics_daily_returns_CTS = pd.DataFrame(dstats(dailyret_CTS))
summary_statistics_std_daily_returns_CTS = pd.DataFrame(dstats(stdlr_CTS))
summary_statistics_daily_returns_BTS = pd.DataFrame(dstats(dailyret_BTS))
summary_statistics_std_daily_returns_BTS = pd.DataFrame(dstats(stdlr_BTS))
summary_statistics_daily_returns_TTS = pd.DataFrame(dstats(dailyret_TTS))
summary_statistics_std_daily_returns_TTS = pd.DataFrame(dstats(stdlr_TTS))
summary_statistics_daily_returns_TT = pd.DataFrame(dstats(dailyret_TT))
summary_statistics_std_daily_returns_TT = pd.DataFrame(dstats(stdlr_TT))
summary_statistics_daily_returns_TRTS = pd.DataFrame(dstats(dailyret_TRTS))
summary_statistics_std_daily_returns_TRTS = pd.DataFrame(dstats(stdlr_TRTS))
summary_statistics_daily_returns_WSD = pd.DataFrame(dstats(dailyret_WSD))
summary_statistics_std_daily_returns_WSD = pd.DataFrame(dstats(stdlr_WSD))
summary_statistics_daily_returns_DA = pd.DataFrame(dstats(dailyret_DA))
summary_statistics_std_daily_returns_DA = pd.DataFrame(dstats(stdlr_DA))

with pd.ExcelWriter('Summary Statistics_1sec_all_schemes.xlsx') as writer:  
    summary_statistics_daily_returns_CTS.to_excel(writer, sheet_name='stdlr_CTS')
    summary_statistics_std_daily_returns_CTS.to_excel(writer, sheet_name='dailyret_CTS')
    summary_statistics_daily_returns_BTS.to_excel(writer, sheet_name='stdlr_BTS')
    summary_statistics_std_daily_returns_BTS.to_excel(writer, sheet_name='dailyret_BTS')
    summary_statistics_daily_returns_TTS.to_excel(writer, sheet_name='stdlr_TTS')
    summary_statistics_std_daily_returns_TTS.to_excel(writer, sheet_name='dailyret_TTS')
    summary_statistics_daily_returns_TT.to_excel(writer, sheet_name='stdlr_TT')
    summary_statistics_std_daily_returns_TT.to_excel(writer, sheet_name='dailyret_TT')
    summary_statistics_daily_returns_TRTS.to_excel(writer, sheet_name='stdlr_TRTS')
    summary_statistics_std_daily_returns_TRTS.to_excel(writer, sheet_name='dailyret_TRTS')
    summary_statistics_daily_returns_WSD.to_excel(writer, sheet_name='stdlr_WSD')
    summary_statistics_std_daily_returns_WSD.to_excel(writer, sheet_name='dailyret_WSD')
    summary_statistics_daily_returns_DA.to_excel(writer, sheet_name='stdlr_DA')
    summary_statistics_std_daily_returns_DA.to_excel(writer, sheet_name='dailyret_DA')


#10 second
data_CTS = pd.read_csv('cts_10sec.csv', sep=',' , header = None)
data_BTS=pd.read_csv('bts_10sec.csv', sep=',' , header = None)
data_TTS=pd.read_csv('tts_10sec.csv', sep=',' , header = None)
data_TT=pd.read_csv('tt_10sec.csv', sep=',' , header = None)
data_TRTS=pd.read_csv('trts_10sec.csv', sep=',' , header = None)
data_WSD=pd.read_csv('wsd_10sec.csv', sep=',' , header = None)
data_DA=pd.read_csv('da_10sec.csv', sep=',' , header = None)

data_CTS = data_CTS.astype(float, errors='ignore')
day_CTS = np.unique(data_CTS[0])
time_CTS = data_CTS[1][:2341].values
price_CTS = data_CTS[data_CTS.columns[2]].values

data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:2341].values
price_BTS = data_BTS[data_BTS.columns[2]].values

data_TTS = data_TTS.astype(float, errors='ignore')
day_TTS = np.unique(data_TTS[0])
time_TTS = data_TTS[1][:2341].values
price_TTS = data_TTS[data_TTS.columns[2]].values

data_TT = data_TT.astype(float, errors='ignore')
day_TT = np.unique(data_TT[0])
time_TT = data_TT[1][:2341].values
price_TT = data_TT[data_TT.columns[2]].values

data_TRTS = data_TRTS.astype(float, errors='ignore')
day_TRTS = np.unique(data_TRTS[0])
time_TRTS = data_TRTS[1][:2341].values
price_TRTS = data_TRTS[data_TRTS.columns[2]].values

data_WSD = data_WSD.astype(float, errors='ignore')
day_WSD = np.unique(data_WSD[0])
time_WSD = data_WSD[1][:2341].values
price_WSD = data_WSD[data_WSD.columns[2]].values

data_DA = data_DA.astype(float, errors='ignore')
day_DA = np.unique(data_DA[0])
time_DA = data_DA[1][:2341].values
price_DA = data_DA[data_DA.columns[2]].values

P_CTS = np.zeros([2341,len(day_CTS)])
for i in range(len(day_CTS)):
    P_CTS[:,i] = price_CTS[i*2341:(i+1)*2341]
intraday_returns_CTS = np.diff(np.log(P_CTS),axis=0) 
#the days are shown horizontally and
#the timepoints are on the vertical axis

P_BTS = np.zeros([2341,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*2341:(i+1)*2341]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

P_TTS = np.zeros([2341,len(day_TTS)])
for i in range(len(day_TTS)):
    P_TTS[:,i] = price_TTS[i*2341:(i+1)*2341]
intraday_returns_TTS = np.diff(np.log(P_TTS),axis=0)

P_TT = np.zeros([2341,len(day_TT)])
for i in range(len(day_TT)):
    P_TT[:,i] = price_TT[i*2341:(i+1)*2341]
intraday_returns_TT = np.diff(np.log(P_TT),axis=0)

P_TRTS = np.zeros([2341,len(day_TRTS)])
for i in range(len(day_TRTS)):
    P_TRTS[:,i] = price_TRTS[i*2341:(i+1)*2341]
intraday_returns_TRTS = np.diff(np.log(P_TRTS),axis=0)

P_WSD = np.zeros([2341,len(day_WSD)])
for i in range(len(day_WSD)):
    P_WSD[:,i] = price_WSD[i*2341:(i+1)*2341]
intraday_returns_WSD = np.diff(np.log(P_WSD),axis=0)

P_DA = np.zeros([2341,len(day_DA)])
for i in range(len(day_DA)):
    P_DA[:,i] = price_DA[i*2341:(i+1)*2341]
intraday_returns_DA = np.diff(np.log(P_DA),axis=0)

rv_CTS=np.sum(intraday_returns_CTS**2,axis=0)
rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)
rv_TTS=np.sum(intraday_returns_TTS**2,axis=0)
rv_TT=np.sum(intraday_returns_TT**2,axis=0)
rv_TRTS=np.sum(intraday_returns_TRTS**2,axis=0)
rv_WSD=np.sum(intraday_returns_WSD**2,axis=0)
rv_DA=np.sum(intraday_returns_DA**2,axis=0)


dailyret_CTS=np.sum(intraday_returns_CTS,axis=0)
dailyret_BTS=np.sum(intraday_returns_BTS,axis=0)
dailyret_TTS=np.sum(intraday_returns_TTS,axis=0)
dailyret_TT=np.sum(intraday_returns_TT,axis=0)
dailyret_TRTS=np.sum(intraday_returns_TRTS,axis=0)
dailyret_WSD=np.sum(intraday_returns_WSD,axis=0)
dailyret_DA=np.sum(intraday_returns_DA,axis=0)

fig,ax = plt.subplots()
plt.plot(price_CTS,label='CTS',color='#ADD8E6')
plt.plot(price_BTS,label='BTS',color='#FF4500')
plt.plot(price_TTS,label='TTS',color='#90EE90')
plt.plot(price_TT,label='TT',color='#FF0000')
plt.plot(price_TRTS,label='TRTS',color='#9370DB')
plt.plot(price_WSD,label='WSD',color='#FFB6C1')
plt.plot(price_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Prices in Euros',fontsize=15)
plt.xlabel('Observations',fontsize=15)
plt.title('IBM stock prices between 2001 and 2019, sampled every 10 second')

fig,ax = plt.subplots()
plt.plot(rv_CTS,label='CTS',color='#ADD8E6')
plt.plot(rv_BTS,label='BTS',color='#FF4500')
plt.plot(rv_TTS,label='TTS',color='#90EE90')
plt.plot(rv_TT,label='TT',color='#FF0000')
plt.plot(rv_TRTS,label='TRTS',color='#9370DB')
plt.plot(rv_WSD,label='WSD',color='#FFB6C1')
plt.plot(rv_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('RV',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock RV between 2001 and 2019, sampled every 10 second')


fig,ax = plt.subplots()
plt.plot(dailyret_CTS,label='CTS',color='#ADD8E6')
plt.plot(dailyret_BTS,label='BTS',color='#FF4500')
plt.plot(dailyret_TTS,label='TTS',color='#90EE90')
plt.plot(dailyret_TT,label='TT',color='#FF0000')
plt.plot(dailyret_TRTS,label='TRTS',color='#9370DB')
plt.plot(dailyret_WSD,label='WSD',color='#FFB6C1')
plt.plot(dailyret_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Daily Returns',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock daily returns between 2001 and 2019, sampled every 10 second')

##ACF and PACF
spacf_plot(rv_CTS,lags = 500)
spacf_plot(rv_BTS,lags = 500)
spacf_plot(rv_TTS,lags = 500)
spacf_plot(rv_TT,lags = 500)
spacf_plot(rv_TRTS,lags = 500)
spacf_plot(rv_WSD,lags = 500)
spacf_plot(rv_DA,lags = 500)

#standardized log returns
stdlr_CTS=dailyret_CTS/np.sqrt(rv_CTS)
stdlr_BTS=dailyret_BTS/np.sqrt(rv_BTS)
stdlr_TTS=dailyret_TTS/np.sqrt(rv_TTS)
stdlr_TT=dailyret_TT/np.sqrt(rv_TT)
stdlr_TRTS=dailyret_TRTS/np.sqrt(rv_TRTS)
stdlr_WSD=dailyret_WSD/np.sqrt(rv_WSD)
stdlr_DA=dailyret_DA/np.sqrt(rv_DA)

#JB test:
JB = pd.DataFrame(columns = ('CTS', 'BTS', 'TTS', 'TT', 'TRTS', 'WSD', 'DA'))

JB['CTS'] = JB_test(stdlr_CTS).reshape([2,])
JB['BTS'] = JB_test(stdlr_BTS).reshape([2,])
JB['TTS'] = JB_test(stdlr_TTS).reshape([2,])
JB['TT'] = JB_test(stdlr_TT).reshape([2,])
JB['TRTS'] = JB_test(stdlr_TRTS).reshape([2,])
JB['WSD'] = JB_test(stdlr_WSD).reshape([2,])
JB['DA'] = JB_test(stdlr_DA).reshape([2,])

with pd.ExcelWriter('JB_10s_all_schemes.xlsx') as writer:  
    JB.to_excel(writer, sheet_name='JB_test_10s')

#Compare the descriptive statistics
summary_statistics_daily_returns_CTS = pd.DataFrame(dstats(dailyret_CTS))
summary_statistics_std_daily_returns_CTS = pd.DataFrame(dstats(stdlr_CTS))
summary_statistics_daily_returns_BTS = pd.DataFrame(dstats(dailyret_BTS))
summary_statistics_std_daily_returns_BTS = pd.DataFrame(dstats(stdlr_BTS))
summary_statistics_daily_returns_TTS = pd.DataFrame(dstats(dailyret_TTS))
summary_statistics_std_daily_returns_TTS = pd.DataFrame(dstats(stdlr_TTS))
summary_statistics_daily_returns_TT = pd.DataFrame(dstats(dailyret_TT))
summary_statistics_std_daily_returns_TT = pd.DataFrame(dstats(stdlr_TT))
summary_statistics_daily_returns_TRTS = pd.DataFrame(dstats(dailyret_TRTS))
summary_statistics_std_daily_returns_TRTS = pd.DataFrame(dstats(stdlr_TRTS))
summary_statistics_daily_returns_WSD = pd.DataFrame(dstats(dailyret_WSD))
summary_statistics_std_daily_returns_WSD = pd.DataFrame(dstats(stdlr_WSD))
summary_statistics_daily_returns_DA = pd.DataFrame(dstats(dailyret_DA))
summary_statistics_std_daily_returns_DA = pd.DataFrame(dstats(stdlr_DA))

with pd.ExcelWriter('Summary Statistics_10sec_all_schemes.xlsx') as writer:  
    summary_statistics_daily_returns_CTS.to_excel(writer, sheet_name='stdlr_CTS')
    summary_statistics_std_daily_returns_CTS.to_excel(writer, sheet_name='dailyret_CTS')
    summary_statistics_daily_returns_BTS.to_excel(writer, sheet_name='stdlr_BTS')
    summary_statistics_std_daily_returns_BTS.to_excel(writer, sheet_name='dailyret_BTS')
    summary_statistics_daily_returns_TTS.to_excel(writer, sheet_name='stdlr_TTS')
    summary_statistics_std_daily_returns_TTS.to_excel(writer, sheet_name='dailyret_TTS')
    summary_statistics_daily_returns_TT.to_excel(writer, sheet_name='stdlr_TT')
    summary_statistics_std_daily_returns_TT.to_excel(writer, sheet_name='dailyret_TT')
    summary_statistics_daily_returns_TRTS.to_excel(writer, sheet_name='stdlr_TRTS')
    summary_statistics_std_daily_returns_TRTS.to_excel(writer, sheet_name='dailyret_TRTS')
    summary_statistics_daily_returns_WSD.to_excel(writer, sheet_name='stdlr_WSD')
    summary_statistics_std_daily_returns_WSD.to_excel(writer, sheet_name='dailyret_WSD')
    summary_statistics_daily_returns_DA.to_excel(writer, sheet_name='stdlr_DA')
    summary_statistics_std_daily_returns_DA.to_excel(writer, sheet_name='dailyret_DA')

###########################################################################
#1 minute
data_CTS = pd.read_csv('cts_1min.csv', sep=',' , header = None)
data_BTS=pd.read_csv('bts_1min.csv', sep=',' , header = None)
data_TTS=pd.read_csv('tts_1min.csv', sep=',' , header = None)
data_TT=pd.read_csv('tt_1min.csv', sep=',' , header = None)
data_TRTS=pd.read_csv('trts_1min.csv', sep=',' , header = None)
data_WSD=pd.read_csv('wsd_1min.csv', sep=',' , header = None)
data_DA=pd.read_csv('da_1min.csv', sep=',' , header = None)

data_CTS = data_CTS.astype(float, errors='ignore')
day_CTS = np.unique(data_CTS[0])
time_CTS = data_CTS[1][:391].values
price_CTS = data_CTS[data_CTS.columns[2]].values

data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:391].values
price_BTS = data_BTS[data_BTS.columns[2]].values

data_TTS = data_TTS.astype(float, errors='ignore')
day_TTS = np.unique(data_TTS[0])
time_TTS = data_TTS[1][:391].values
price_TTS = data_TTS[data_TTS.columns[2]].values

data_TT = data_TT.astype(float, errors='ignore')
day_TT = np.unique(data_TT[0])
time_TT = data_TT[1][:391].values
price_TT = data_TT[data_TT.columns[2]].values

data_TRTS = data_TRTS.astype(float, errors='ignore')
day_TRTS = np.unique(data_TRTS[0])
time_TRTS = data_TRTS[1][:391].values
price_TRTS = data_TRTS[data_TRTS.columns[2]].values

data_WSD = data_WSD.astype(float, errors='ignore')
day_WSD = np.unique(data_WSD[0])
time_WSD = data_WSD[1][:391].values
price_WSD = data_WSD[data_WSD.columns[2]].values

data_DA = data_DA.astype(float, errors='ignore')
day_DA = np.unique(data_DA[0])
time_DA = data_DA[1][:391].values
price_DA = data_DA[data_DA.columns[2]].values


P_CTS = np.zeros([391,len(day_CTS)])
for i in range(len(day_CTS)):
    P_CTS[:,i] = price_CTS[i*391:(i+1)*391]
intraday_returns_CTS = np.diff(np.log(P_CTS),axis=0)
#the days are shown horizontally and
#the timepoints are on the vertical axis

P_BTS = np.zeros([391,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*391:(i+1)*391]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

P_TTS = np.zeros([391,len(day_TTS)])
for i in range(len(day_TTS)):
    P_TTS[:,i] = price_TTS[i*391:(i+1)*391]
intraday_returns_TTS = np.diff(np.log(P_TTS),axis=0)

P_TT = np.zeros([391,len(day_TT)])
for i in range(len(day_TT)):
    P_TT[:,i] = price_TT[i*391:(i+1)*391]
intraday_returns_TT = np.diff(np.log(P_TT),axis=0)

P_TRTS = np.zeros([391,len(day_TRTS)])
for i in range(len(day_TRTS)):
    P_TRTS[:,i] = price_TRTS[i*391:(i+1)*391]
intraday_returns_TRTS = np.diff(np.log(P_TRTS),axis=0)

P_WSD = np.zeros([391,len(day_WSD)])
for i in range(len(day_WSD)):
    P_WSD[:,i] = price_WSD[i*391:(i+1)*391]
intraday_returns_WSD = np.diff(np.log(P_WSD),axis=0)

P_DA = np.zeros([391,len(day_DA)])
for i in range(len(day_DA)):
    P_DA[:,i] = price_DA[i*391:(i+1)*391]
intraday_returns_DA = np.diff(np.log(P_DA),axis=0)


rv_CTS=np.sum(intraday_returns_CTS**2,axis=0)
rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)
rv_TTS=np.sum(intraday_returns_TTS**2,axis=0)
rv_TT=np.sum(intraday_returns_TT**2,axis=0)
rv_TRTS=np.sum(intraday_returns_TRTS**2,axis=0)
rv_WSD=np.sum(intraday_returns_WSD**2,axis=0)
rv_DA=np.sum(intraday_returns_DA**2,axis=0)


dailyret_CTS=np.sum(intraday_returns_CTS,axis=0)
dailyret_BTS=np.sum(intraday_returns_BTS,axis=0)
dailyret_TTS=np.sum(intraday_returns_TTS,axis=0)
dailyret_TT=np.sum(intraday_returns_TT,axis=0)
dailyret_TRTS=np.sum(intraday_returns_TRTS,axis=0)
dailyret_WSD=np.sum(intraday_returns_WSD,axis=0)
dailyret_DA=np.sum(intraday_returns_DA,axis=0)

fig,ax = plt.subplots()
plt.plot(price_CTS,label='CTS',color='#ADD8E6')
plt.plot(price_BTS,label='BTS',color='#FF4500')
plt.plot(price_TTS,label='TTS',color='#90EE90')
plt.plot(price_TT,label='TT',color='#FF0000')
plt.plot(price_TRTS,label='TRTS',color='#9370DB')
plt.plot(price_WSD,label='WSD',color='#FFB6C1')
plt.plot(price_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Prices in Euros',fontsize=15)
plt.xlabel('Observations',fontsize=15)
plt.title('IBM stock prices between 2001 and 2019, sampled every minute')

fig,ax = plt.subplots()
plt.plot(rv_CTS,label='CTS',color='#ADD8E6')
plt.plot(rv_BTS,label='BTS',color='#FF4500')
plt.plot(rv_TTS,label='TTS',color='#90EE90')
plt.plot(rv_TT,label='TT',color='#FF0000')
plt.plot(rv_TRTS,label='TRTS',color='#9370DB')
plt.plot(rv_WSD,label='WSD',color='#FFB6C1')
plt.plot(rv_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('RV',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock RV between 2001 and 2019, sampled every minute')


fig,ax = plt.subplots()
plt.plot(dailyret_CTS,label='CTS',color='#ADD8E6')
plt.plot(dailyret_BTS,label='BTS',color='#FF4500')
plt.plot(dailyret_TTS,label='TTS',color='#90EE90')
plt.plot(dailyret_TT,label='TT',color='#FF0000')
plt.plot(dailyret_TRTS,label='TRTS',color='#9370DB')
plt.plot(dailyret_WSD,label='WSD',color='#FFB6C1')
plt.plot(dailyret_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Daily Returns',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock daily returns between 2001 and 2019, sampled every minute')

##ACF and PACF
spacf_plot(rv_CTS,lags = 500)
spacf_plot(rv_BTS,lags = 500)
spacf_plot(rv_TTS,lags = 500)
spacf_plot(rv_TT,lags = 500)
spacf_plot(rv_TRTS,lags = 500)
spacf_plot(rv_WSD,lags = 500)
spacf_plot(rv_DA,lags = 500)

#standardized log returns
stdlr_CTS=dailyret_CTS/np.sqrt(rv_CTS)
stdlr_BTS=dailyret_BTS/np.sqrt(rv_BTS)
stdlr_TTS=dailyret_TTS/np.sqrt(rv_TTS)
stdlr_TT=dailyret_TT/np.sqrt(rv_TT)
stdlr_TRTS=dailyret_TRTS/np.sqrt(rv_TRTS)
stdlr_WSD=dailyret_WSD/np.sqrt(rv_WSD)
stdlr_DA=dailyret_DA/np.sqrt(rv_DA)


JB = pd.DataFrame(columns = ('CTS', 'BTS', 'TTS', 'TT', 'TRTS', 'WSD', 'DA'))

JB['CTS'] = JB_test(stdlr_CTS).reshape([2,])
JB['BTS'] = JB_test(stdlr_BTS).reshape([2,])
JB['TTS'] = JB_test(stdlr_TTS).reshape([2,])
JB['TT'] = JB_test(stdlr_TT).reshape([2,])
JB['TRTS'] = JB_test(stdlr_TRTS).reshape([2,])
JB['WSD'] = JB_test(stdlr_WSD).reshape([2,])
JB['DA'] = JB_test(stdlr_DA).reshape([2,])

with pd.ExcelWriter('JB_1m_all_schemes.xlsx') as writer:  
    JB.to_excel(writer, sheet_name='JB_test')
    
#Compare the descriptive statistics
summary_statistics_daily_returns_CTS = pd.DataFrame(dstats(dailyret_CTS))
summary_statistics_std_daily_returns_CTS = pd.DataFrame(dstats(stdlr_CTS))
summary_statistics_daily_returns_BTS = pd.DataFrame(dstats(dailyret_BTS))
summary_statistics_std_daily_returns_BTS = pd.DataFrame(dstats(stdlr_BTS))
summary_statistics_daily_returns_TTS = pd.DataFrame(dstats(dailyret_TTS))
summary_statistics_std_daily_returns_TTS = pd.DataFrame(dstats(stdlr_TTS))
summary_statistics_daily_returns_TT = pd.DataFrame(dstats(dailyret_TT))
summary_statistics_std_daily_returns_TT = pd.DataFrame(dstats(stdlr_TT))
summary_statistics_daily_returns_TRTS = pd.DataFrame(dstats(dailyret_TRTS))
summary_statistics_std_daily_returns_TRTS = pd.DataFrame(dstats(stdlr_TRTS))
summary_statistics_daily_returns_WSD = pd.DataFrame(dstats(dailyret_WSD))
summary_statistics_std_daily_returns_WSD = pd.DataFrame(dstats(stdlr_WSD))
summary_statistics_daily_returns_DA = pd.DataFrame(dstats(dailyret_DA))
summary_statistics_std_daily_returns_DA = pd.DataFrame(dstats(stdlr_DA))

with pd.ExcelWriter('Summary Statistics_1min_all_schemes.xlsx') as writer:  
    summary_statistics_daily_returns_CTS.to_excel(writer, sheet_name='stdlr_CTS')
    summary_statistics_std_daily_returns_CTS.to_excel(writer, sheet_name='dailyret_CTS')
    summary_statistics_daily_returns_BTS.to_excel(writer, sheet_name='stdlr_BTS')
    summary_statistics_std_daily_returns_BTS.to_excel(writer, sheet_name='dailyret_BTS')
    summary_statistics_daily_returns_TTS.to_excel(writer, sheet_name='stdlr_TTS')
    summary_statistics_std_daily_returns_TTS.to_excel(writer, sheet_name='dailyret_TTS')
    summary_statistics_daily_returns_TT.to_excel(writer, sheet_name='stdlr_TT')
    summary_statistics_std_daily_returns_TT.to_excel(writer, sheet_name='dailyret_TT')
    summary_statistics_daily_returns_TRTS.to_excel(writer, sheet_name='stdlr_TRTS')
    summary_statistics_std_daily_returns_TRTS.to_excel(writer, sheet_name='dailyret_TRTS')
    summary_statistics_daily_returns_WSD.to_excel(writer, sheet_name='stdlr_WSD')
    summary_statistics_std_daily_returns_WSD.to_excel(writer, sheet_name='dailyret_WSD')
    summary_statistics_daily_returns_DA.to_excel(writer, sheet_name='stdlr_DA')
    summary_statistics_std_daily_returns_DA.to_excel(writer, sheet_name='dailyret_DA')

##########################################################################
#3 minute
data_CTS = pd.read_csv('cts_3min.csv', sep=',' , header = None)
data_BTS=pd.read_csv('bts_3min.csv', sep=',' , header = None)
data_TTS=pd.read_csv('tts_3min.csv', sep=',' , header = None)
data_TT=pd.read_csv('tt_3min.csv', sep=',' , header = None)
data_TRTS=pd.read_csv('trts_3min.csv', sep=',' , header = None)
data_WSD=pd.read_csv('wsd_3min.csv', sep=',' , header = None)
data_DA=pd.read_csv('da_3min.csv', sep=',' , header = None)

data_CTS = data_CTS.astype(float, errors='ignore')
day_CTS = np.unique(data_CTS[0])
time_CTS = data_CTS[1][:131].values
price_CTS = data_CTS[data_CTS.columns[2]].values

data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:131].values
price_BTS = data_BTS[data_BTS.columns[2]].values

data_TTS = data_TTS.astype(float, errors='ignore')
day_TTS = np.unique(data_TTS[0])
time_TTS = data_TTS[1][:131].values
price_TTS = data_TTS[data_TTS.columns[2]].values

data_TT = data_TT.astype(float, errors='ignore')
day_TT = np.unique(data_TT[0])
time_TT = data_TT[1][:131].values
price_TT = data_TT[data_TT.columns[2]].values

data_TRTS = data_TRTS.astype(float, errors='ignore')
day_TRTS = np.unique(data_TRTS[0])
time_TRTS = data_TRTS[1][:131].values
price_TRTS = data_TRTS[data_TRTS.columns[2]].values

data_WSD = data_WSD.astype(float, errors='ignore')
day_WSD = np.unique(data_WSD[0])
time_WSD = data_WSD[1][:131].values
price_WSD = data_WSD[data_WSD.columns[2]].values

data_DA = data_DA.astype(float, errors='ignore')
day_DA = np.unique(data_DA[0])
time_DA = data_DA[1][:131].values
price_DA = data_DA[data_DA.columns[2]].values

P_CTS = np.zeros([131,len(day_CTS)])
for i in range(len(day_CTS)):
    P_CTS[:,i] = price_CTS[i*131:(i+1)*131]
intraday_returns_CTS = np.diff(np.log(P_CTS),axis=0)
#the days are shown horizontally and
#the timepoints are on the vertical axis

P_BTS = np.zeros([131,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*131:(i+1)*131]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

P_TTS = np.zeros([131,len(day_TTS)])
for i in range(len(day_TTS)):
    P_TTS[:,i] = price_TTS[i*131:(i+1)*131]
intraday_returns_TTS = np.diff(np.log(P_TTS),axis=0)

P_TT = np.zeros([131,len(day_TT)])
for i in range(len(day_TT)):
    P_TT[:,i] = price_TT[i*131:(i+1)*131]
intraday_returns_TT = np.diff(np.log(P_TT),axis=0)

P_TRTS = np.zeros([131,len(day_TRTS)])
for i in range(len(day_TRTS)):
    P_TRTS[:,i] = price_TRTS[i*131:(i+1)*131]
intraday_returns_TRTS = np.diff(np.log(P_TRTS),axis=0)

P_WSD = np.zeros([131,len(day_WSD)])
for i in range(len(day_WSD)):
    P_WSD[:,i] = price_WSD[i*131:(i+1)*131]
intraday_returns_WSD = np.diff(np.log(P_WSD),axis=0)

P_DA = np.zeros([131,len(day_DA)])
for i in range(len(day_DA)):
    P_DA[:,i] = price_DA[i*131:(i+1)*131]
intraday_returns_DA = np.diff(np.log(P_DA),axis=0)


rv_CTS=np.sum(intraday_returns_CTS**2,axis=0)
rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)
rv_TTS=np.sum(intraday_returns_TTS**2,axis=0)
rv_TT=np.sum(intraday_returns_TT**2,axis=0)
rv_TRTS=np.sum(intraday_returns_TRTS**2,axis=0)
rv_WSD=np.sum(intraday_returns_WSD**2,axis=0)
rv_DA=np.sum(intraday_returns_DA**2,axis=0)


dailyret_CTS=np.sum(intraday_returns_CTS,axis=0)
dailyret_BTS=np.sum(intraday_returns_BTS,axis=0)
dailyret_TTS=np.sum(intraday_returns_TTS,axis=0)
dailyret_TT=np.sum(intraday_returns_TT,axis=0)
dailyret_TRTS=np.sum(intraday_returns_TRTS,axis=0)
dailyret_WSD=np.sum(intraday_returns_WSD,axis=0)
dailyret_DA=np.sum(intraday_returns_DA,axis=0)

fig,ax = plt.subplots()
plt.plot(price_CTS,label='CTS',color='#ADD8E6')
plt.plot(price_BTS,label='BTS',color='#FF4500')
plt.plot(price_TTS,label='TTS',color='#90EE90')
plt.plot(price_TT,label='TT',color='#FF0000')
plt.plot(price_TRTS,label='TRTS',color='#9370DB')
plt.plot(price_WSD,label='WSD',color='#FFB6C1')
plt.plot(price_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Prices in Euros',fontsize=15)
plt.xlabel('Observations',fontsize=15)
plt.title('IBM stock prices between 2001 and 2019, sampled every 3 minute')

fig,ax = plt.subplots()
plt.plot(rv_CTS,label='CTS',color='#ADD8E6')
plt.plot(rv_BTS,label='BTS',color='#FF4500')
plt.plot(rv_TTS,label='TTS',color='#90EE90')
plt.plot(rv_TT,label='TT',color='#FF0000')
plt.plot(rv_TRTS,label='TRTS',color='#9370DB')
plt.plot(rv_WSD,label='WSD',color='#FFB6C1')
plt.plot(rv_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('RV',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock RV between 2001 and 2019, sampled every 3 minute')


fig,ax = plt.subplots()
plt.plot(dailyret_CTS,label='CTS',color='#ADD8E6')
plt.plot(dailyret_BTS,label='BTS',color='#FF4500')
plt.plot(dailyret_TTS,label='TTS',color='#90EE90')
plt.plot(dailyret_TT,label='TT',color='#FF0000')
plt.plot(dailyret_TRTS,label='TRTS',color='#9370DB')
plt.plot(dailyret_WSD,label='WSD',color='#FFB6C1')
plt.plot(dailyret_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Daily Returns',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock daily returns between 2001 and 2019, sampled every 3 minute')

##ACF and PACF
spacf_plot(rv_CTS,lags = 500)
spacf_plot(rv_BTS,lags = 500)
spacf_plot(rv_TTS,lags = 500)
spacf_plot(rv_TT,lags = 500)
spacf_plot(rv_TRTS,lags = 500)
spacf_plot(rv_WSD,lags = 500)
spacf_plot(rv_DA,lags = 500)

#standardized log returns
stdlr_CTS=dailyret_CTS/np.sqrt(rv_CTS)
stdlr_BTS=dailyret_BTS/np.sqrt(rv_BTS)
stdlr_TTS=dailyret_TTS/np.sqrt(rv_TTS)
stdlr_TT=dailyret_TT/np.sqrt(rv_TT)
stdlr_TRTS=dailyret_TRTS/np.sqrt(rv_TRTS)
stdlr_WSD=dailyret_WSD/np.sqrt(rv_WSD)
stdlr_DA=dailyret_DA/np.sqrt(rv_DA)

JB = pd.DataFrame(columns = ('CTS', 'BTS', 'TTS', 'TT', 'TRTS', 'WSD', 'DA'))

# for f in JB.columns:
JB['CTS'] = JB_test(stdlr_CTS).reshape([2,])
JB['BTS'] = JB_test(stdlr_BTS).reshape([2,])
JB['TTS'] = JB_test(stdlr_TTS).reshape([2,])
JB['TT'] = JB_test(stdlr_TT).reshape([2,])
JB['TRTS'] = JB_test(stdlr_TRTS).reshape([2,])
JB['WSD'] = JB_test(stdlr_WSD).reshape([2,])
JB['DA'] = JB_test(stdlr_DA).reshape([2,])

with pd.ExcelWriter('JB_3m_all_schemes.xlsx') as writer:  
    JB.to_excel(writer, sheet_name='JB_test_3m')
    
#Compare the descriptive statistics
summary_statistics_daily_returns_CTS = pd.DataFrame(dstats(dailyret_CTS))
summary_statistics_std_daily_returns_CTS = pd.DataFrame(dstats(stdlr_CTS))
summary_statistics_daily_returns_BTS = pd.DataFrame(dstats(dailyret_BTS))
summary_statistics_std_daily_returns_BTS = pd.DataFrame(dstats(stdlr_BTS))
summary_statistics_daily_returns_TTS = pd.DataFrame(dstats(dailyret_TTS))
summary_statistics_std_daily_returns_TTS = pd.DataFrame(dstats(stdlr_TTS))
summary_statistics_daily_returns_TT = pd.DataFrame(dstats(dailyret_TT))
summary_statistics_std_daily_returns_TT = pd.DataFrame(dstats(stdlr_TT))
summary_statistics_daily_returns_TRTS = pd.DataFrame(dstats(dailyret_TRTS))
summary_statistics_std_daily_returns_TRTS = pd.DataFrame(dstats(stdlr_TRTS))
summary_statistics_daily_returns_WSD = pd.DataFrame(dstats(dailyret_WSD))
summary_statistics_std_daily_returns_WSD = pd.DataFrame(dstats(stdlr_WSD))
summary_statistics_daily_returns_DA = pd.DataFrame(dstats(dailyret_DA))
summary_statistics_std_daily_returns_DA = pd.DataFrame(dstats(stdlr_DA))

with pd.ExcelWriter('Summary Statistics_3min_all_schemes.xlsx') as writer:  
    summary_statistics_daily_returns_CTS.to_excel(writer, sheet_name='stdlr_CTS')
    summary_statistics_std_daily_returns_CTS.to_excel(writer, sheet_name='dailyret_CTS')
    summary_statistics_daily_returns_BTS.to_excel(writer, sheet_name='stdlr_BTS')
    summary_statistics_std_daily_returns_BTS.to_excel(writer, sheet_name='dailyret_BTS')
    summary_statistics_daily_returns_TTS.to_excel(writer, sheet_name='stdlr_TTS')
    summary_statistics_std_daily_returns_TTS.to_excel(writer, sheet_name='dailyret_TTS')
    summary_statistics_daily_returns_TT.to_excel(writer, sheet_name='stdlr_TT')
    summary_statistics_std_daily_returns_TT.to_excel(writer, sheet_name='dailyret_TT')
    summary_statistics_daily_returns_TRTS.to_excel(writer, sheet_name='stdlr_TRTS')
    summary_statistics_std_daily_returns_TRTS.to_excel(writer, sheet_name='dailyret_TRTS')
    summary_statistics_daily_returns_WSD.to_excel(writer, sheet_name='stdlr_WSD')
    summary_statistics_std_daily_returns_WSD.to_excel(writer, sheet_name='dailyret_WSD')
    summary_statistics_daily_returns_DA.to_excel(writer, sheet_name='stdlr_DA')
    summary_statistics_std_daily_returns_DA.to_excel(writer, sheet_name='dailyret_DA')

##############################################################################
#5 minute
data_CTS = pd.read_csv('cts_5min.csv', sep=',' , header = None)
data_BTS=pd.read_csv('bts_5min.csv', sep=',' , header = None)
data_TTS=pd.read_csv('tts_5min.csv', sep=',' , header = None)
data_TT=pd.read_csv('tt_5min.csv', sep=',' , header = None)
data_TRTS=pd.read_csv('trts_5min.csv', sep=',' , header = None)
data_WSD=pd.read_csv('wsd_5min.csv', sep=',' , header = None)
data_DA=pd.read_csv('da_5min.csv', sep=',' , header = None)

data_CTS = data_CTS.astype(float, errors='ignore')
day_CTS = np.unique(data_CTS[0])
time_CTS = data_CTS[1][:79].values
price_CTS = data_CTS[data_CTS.columns[2]].values

data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:79].values
price_BTS = data_BTS[data_BTS.columns[2]].values

data_TTS = data_TTS.astype(float, errors='ignore')
day_TTS = np.unique(data_TTS[0])
time_TTS = data_TTS[1][:79].values
price_TTS = data_TTS[data_TTS.columns[2]].values

data_TT = data_TT.astype(float, errors='ignore')
day_TT = np.unique(data_TT[0])
time_TT = data_TT[1][:79].values
price_TT = data_TT[data_TT.columns[2]].values

data_TRTS = data_TRTS.astype(float, errors='ignore')
day_TRTS = np.unique(data_TRTS[0])
time_TRTS = data_TRTS[1][:79].values
price_TRTS = data_TRTS[data_TRTS.columns[2]].values

data_WSD = data_WSD.astype(float, errors='ignore')
day_WSD = np.unique(data_WSD[0])
time_WSD = data_WSD[1][:79].values
price_WSD = data_WSD[data_WSD.columns[2]].values

data_DA = data_DA.astype(float, errors='ignore')
day_DA = np.unique(data_DA[0])
time_DA = data_DA[1][:79].values
price_DA = data_DA[data_DA.columns[2]].values


P_CTS = np.zeros([79,len(day_CTS)])
for i in range(len(day_CTS)):
    P_CTS[:,i] = price_CTS[i*79:(i+1)*79]
intraday_returns_CTS = np.diff(np.log(P_CTS),axis=0)
#the days are shown horizontally and
#the timepoints are on the vertical axis

P_BTS = np.zeros([79,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*79:(i+1)*79]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

P_TTS = np.zeros([79,len(day_TTS)])
for i in range(len(day_TTS)):
    P_TTS[:,i] = price_TTS[i*79:(i+1)*79]
intraday_returns_TTS = np.diff(np.log(P_TTS),axis=0)

P_TT = np.zeros([79,len(day_TT)])
for i in range(len(day_TT)):
    P_TT[:,i] = price_TT[i*79:(i+1)*79]
intraday_returns_TT = np.diff(np.log(P_TT),axis=0)

P_TRTS = np.zeros([79,len(day_TRTS)])
for i in range(len(day_TRTS)):
    P_TRTS[:,i] = price_TRTS[i*79:(i+1)*79]
intraday_returns_TRTS = np.diff(np.log(P_TRTS),axis=0)

P_WSD = np.zeros([79,len(day_WSD)])
for i in range(len(day_WSD)):
    P_WSD[:,i] = price_WSD[i*79:(i+1)*79]
intraday_returns_WSD = np.diff(np.log(P_WSD),axis=0)

P_DA = np.zeros([79,len(day_DA)])
for i in range(len(day_DA)):
    P_DA[:,i] = price_DA[i*79:(i+1)*79]
intraday_returns_DA = np.diff(np.log(P_DA),axis=0)


rv_CTS=np.sum(intraday_returns_CTS**2,axis=0)
rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)
rv_TTS=np.sum(intraday_returns_TTS**2,axis=0)
rv_TT=np.sum(intraday_returns_TT**2,axis=0)
rv_TRTS=np.sum(intraday_returns_TRTS**2,axis=0)
rv_WSD=np.sum(intraday_returns_WSD**2,axis=0)
rv_DA=np.sum(intraday_returns_DA**2,axis=0)

dailyret_CTS=np.sum(intraday_returns_CTS,axis=0)
dailyret_BTS=np.sum(intraday_returns_BTS,axis=0)
dailyret_TTS=np.sum(intraday_returns_TTS,axis=0)
dailyret_TT=np.sum(intraday_returns_TT,axis=0)
dailyret_TRTS=np.sum(intraday_returns_TRTS,axis=0)
dailyret_WSD=np.sum(intraday_returns_WSD,axis=0)
dailyret_DA=np.sum(intraday_returns_DA,axis=0)

fig,ax = plt.subplots()
plt.plot(price_CTS,label='CTS',color='#ADD8E6')
plt.plot(price_BTS,label='BTS',color='#FF4500')
plt.plot(price_TTS,label='TTS',color='#90EE90')
plt.plot(price_TT,label='TT',color='#FF0000')
plt.plot(price_TRTS,label='TRTS',color='#9370DB')
plt.plot(price_WSD,label='WSD',color='#FFB6C1')
plt.plot(price_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Prices in Euros',fontsize=15)
plt.xlabel('Observations',fontsize=15)
plt.title('IBM stock prices between 2001 and 2019, sampled every 5 minute')

fig,ax = plt.subplots()
plt.plot(rv_CTS,label='CTS',color='#ADD8E6')
plt.plot(rv_BTS,label='BTS',color='#FF4500')
plt.plot(rv_TTS,label='TTS',color='#90EE90')
plt.plot(rv_TT,label='TT',color='#FF0000')
plt.plot(rv_TRTS,label='TRTS',color='#9370DB')
plt.plot(rv_WSD,label='WSD',color='#FFB6C1')
plt.plot(rv_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('RV',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock RV between 2001 and 2019, sampled every 5 minute')


fig,ax = plt.subplots()
plt.plot(dailyret_CTS,label='CTS',color='#ADD8E6')
plt.plot(dailyret_BTS,label='BTS',color='#FF4500')
plt.plot(dailyret_TTS,label='TTS',color='#90EE90')
plt.plot(dailyret_TT,label='TT',color='#FF0000')
plt.plot(dailyret_TRTS,label='TRTS',color='#9370DB')
plt.plot(dailyret_WSD,label='WSD',color='#FFB6C1')
plt.plot(dailyret_DA,label='DA',color='#CD853F')
plt.legend()
plt.ylabel('Daily Returns',fontsize=15)
plt.xlabel('Days',fontsize=15)
plt.title('IBM stock daily returns between 2001 and 2019, sampled every 5 minute')

##ACF and PACF
spacf_plot(rv_CTS,lags = 500)
spacf_plot(rv_BTS,lags = 500)
spacf_plot(rv_TTS,lags = 500)
spacf_plot(rv_TT,lags = 500)
spacf_plot(rv_TRTS,lags = 500)
spacf_plot(rv_WSD,lags = 500)
spacf_plot(rv_DA,lags = 500)

#standardized log returns
stdlr_CTS=dailyret_CTS/np.sqrt(rv_CTS)
stdlr_BTS=dailyret_BTS/np.sqrt(rv_BTS)
stdlr_TTS=dailyret_TTS/np.sqrt(rv_TTS)
stdlr_TT=dailyret_TT/np.sqrt(rv_TT)
stdlr_TRTS=dailyret_TRTS/np.sqrt(rv_TRTS)
stdlr_WSD=dailyret_WSD/np.sqrt(rv_WSD)
stdlr_DA=dailyret_DA/np.sqrt(rv_DA)

JB = pd.DataFrame(columns = ('CTS', 'BTS', 'TTS', 'TT', 'TRTS', 'WSD', 'DA'))

JB['CTS'] = JB_test(stdlr_CTS).reshape([2,])
JB['BTS'] = JB_test(stdlr_BTS).reshape([2,])
JB['TTS'] = JB_test(stdlr_TTS).reshape([2,])
JB['TT'] = JB_test(stdlr_TT).reshape([2,])
JB['TRTS'] = JB_test(stdlr_TRTS).reshape([2,])
JB['WSD'] = JB_test(stdlr_WSD).reshape([2,])
JB['DA'] = JB_test(stdlr_DA).reshape([2,])

with pd.ExcelWriter('JB_5m_all_schemes.xlsx') as writer:  
    JB.to_excel(writer, sheet_name='JB_test')
    
#Compare the descriptive statistics
summary_statistics_daily_returns_CTS = pd.DataFrame(dstats(dailyret_CTS))
summary_statistics_std_daily_returns_CTS = pd.DataFrame(dstats(stdlr_CTS))
summary_statistics_daily_returns_BTS = pd.DataFrame(dstats(dailyret_BTS))
summary_statistics_std_daily_returns_BTS = pd.DataFrame(dstats(stdlr_BTS))
summary_statistics_daily_returns_TTS = pd.DataFrame(dstats(dailyret_TTS))
summary_statistics_std_daily_returns_TTS = pd.DataFrame(dstats(stdlr_TTS))
summary_statistics_daily_returns_TT = pd.DataFrame(dstats(dailyret_TT))
summary_statistics_std_daily_returns_TT = pd.DataFrame(dstats(stdlr_TT))
summary_statistics_daily_returns_TRTS = pd.DataFrame(dstats(dailyret_TRTS))
summary_statistics_std_daily_returns_TRTS = pd.DataFrame(dstats(stdlr_TRTS))
summary_statistics_daily_returns_WSD = pd.DataFrame(dstats(dailyret_WSD))
summary_statistics_std_daily_returns_WSD = pd.DataFrame(dstats(stdlr_WSD))
summary_statistics_daily_returns_DA = pd.DataFrame(dstats(dailyret_DA))
summary_statistics_std_daily_returns_DA = pd.DataFrame(dstats(stdlr_DA))

with pd.ExcelWriter('Summary Statistics_5min_all_schemes.xlsx') as writer:  
    summary_statistics_daily_returns_CTS.to_excel(writer, sheet_name='stdlr_CTS')
    summary_statistics_std_daily_returns_CTS.to_excel(writer, sheet_name='dailyret_CTS')
    summary_statistics_daily_returns_BTS.to_excel(writer, sheet_name='stdlr_BTS')
    summary_statistics_std_daily_returns_BTS.to_excel(writer, sheet_name='dailyret_BTS')
    summary_statistics_daily_returns_TTS.to_excel(writer, sheet_name='stdlr_TTS')
    summary_statistics_std_daily_returns_TTS.to_excel(writer, sheet_name='dailyret_TTS')
    summary_statistics_daily_returns_TT.to_excel(writer, sheet_name='stdlr_TT')
    summary_statistics_std_daily_returns_TT.to_excel(writer, sheet_name='dailyret_TT')
    summary_statistics_daily_returns_TRTS.to_excel(writer, sheet_name='stdlr_TRTS')
    summary_statistics_std_daily_returns_TRTS.to_excel(writer, sheet_name='dailyret_TRTS')
    summary_statistics_daily_returns_WSD.to_excel(writer, sheet_name='stdlr_WSD')
    summary_statistics_std_daily_returns_WSD.to_excel(writer, sheet_name='dailyret_WSD')
    summary_statistics_daily_returns_DA.to_excel(writer, sheet_name='stdlr_DA')
    summary_statistics_std_daily_returns_DA.to_excel(writer, sheet_name='dailyret_DA')

