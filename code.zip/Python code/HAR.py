#Copyright: Kevin Sheppard
#kevin.sheppard@economics.ox.ac.uk
#Revision: 1    Date: 7/13/2009

import numpy as np
from scipy.linalg import lstsq
import os
cwd = os.getcwd()
os.chdir(cwd)
from helpfunctions import newlagmatrix, covnw, aicsbic,armaroots


#Heterogeneous Autoregression parameter estimation
def heterogeneousar(y,constant,p,*options): # in *opntions the first one is nw, second is spec
#USAGE:
# [PARAMETERS] = heterogeneousar(Y,CONSTANT,P)
# [PARAMETERS, ERRORS, SEREGRESSION, DIAGNOSTICS, VCVROBUST, VCV] 
#                                        = heterogeneousar(Y,CONSTANT,P,NW,SPEC)

#INPUTS:
#  Y            - A column of data
#  CONSTANT     - Scalar variable: 1 to include a constant, 0 to exclude
#  P            - A column vector or a matrix.
#                   If a vector, should include the indices to use for the lag length, such as in
#                   the usual case for monthly volatility data P=[1; 5; 22]. This indicates that
#                   the 1st lag, average of the first 5 lags, and the average of the first 22 lags
#                   should be used in estimation.  NOTE: When using the vector format, P MUST BE A
#                   COLUMN VECTOR to avoid ambiguity with the matrix format.  If P is a matrix, the
#                   values indicate the start and end points of the averages.  The above vector can
#                   be equivalently expressed as P=[1 1;1 5;1 22].  The matrix notation allows for
#                   the possibility of skipping lags, for example P=[1 1; 5 5; 1 22]; would have
#                   the 1st lag, the 5th lag and the average of lags 1 to 22.  NOTE: When using the
#                   matrix format, P MUST be # Entries by 2.  
#  NW           - [OPTIONAL] Number of lags to use when computing the long-run variance of the
#                   scores in VCVROBUST.  Default is 0. 
#  SPEC         - [OPTIONAL] String value indicating which representation to use in parameter
#                   estimation.  May be:
#                    'STANDARD' - Usual representation with overlapping lags
#                     'MODIFIED' - Modified representation with non-overlapping lags
#OUTPUTS:
#  PARAMETERS   - A 1+length(p) column vector of parameters with
#                 [constant har(1) ... har(P)]'
#  ERRORS       - A T by 1 length vector of errors from the regression with 0s in first max(max(P))
#                   places
#  SEREGRESSION - The standard error of the regressions
#  DIAGNOSTICS  - A structure of diagnostic information containing:
#                    P          - List of HAR lags used in estimation
#                    C          - Indicator if constant was included
#                    AIC        - Akaike Information Criteria for the estimated model
#                    SBIC       - Bayesian (Schwartz) Information Criteria for the
#                                  estimated model
#                    T          - Number of observations
#                    ADJT       - Length of sample used for estimation #                    ARROOTS    - The characteristic roots of the ARMA
#                                  process evaluated at the estimated parameters
#                    ABSARROOTS - The absolute value (complex modulus if
#                                   complex) of the ARROOTS
#  VCVROBUST    - Robust parameter covariance matrix, White if NW = 0,
#                   Newey-West if NW>0
#  VCV          - Non-robust standard errors (inverse Hessian)

#EXAMPLES:
#  Simulate data from a HAR model
#      y = armaxfilter_simulate(1000,1,22,[.1 .3/4*ones(1,4) .55/17*ones(1,17)])
#  Standard HAR with 1, 5 and 22 day lags
#      parameters = heterogeneousar(Y,1,[1 5 22]')
#  Standard HAR with 1, 5 and 22 days lags using matrix notation
#      parameters = heterogeneousar(Y,1,[1 1;1 5;1 22])
#  Standard HAR with 1, 5 and 22 day lags using the non-overlapping reparameterization
#      parameters = heterogeneousar(Y,1,[1 5 22]',[],'MODIFIED')
#  Standard HAR with 1, 5 and 22 day lags with Newey-West standard errors
#      [parameters, errors, seregression, diagnostics, vcvrobust, vcv] = ...
#                   heterogeneousar(Y,1,[1 5 22]',ceil(length(Y)^(1/3)))
#  Nonstandard HAR with lags 1, 2  and 10-22 day lags 
#      parameters = heterogeneousar(Y,1,[1 1;2 2;130 22])

#See also ARMAXFILTER, TARCH

#Copyright: Kevin Sheppard
#kevin.sheppard@economics.ox.ac.uk
#Revision: 1    Date: 7/13/2009


##############################
##Input Checking
#############################
    options = list(options)
    
    if len(options) == 0:
        nw = 0
        spec = 'STANDARD'
    elif len(options) ==1 and options[0] is not None:
        nw = options[0]
        spec = 'STANDARD'
    else:
        nw = options[0]
        spec = options[1]
        
    

##############################
## y checking
#############################
    if (len(np.shape(y)) > 1 and np.shape(y)[1] >1) or len(np.shape(y)) == 0:
        return print ('y series must be a column vector.')
    elif len(y) == 0:
        return print('y is empty.')
    else:
        # reshape input size to (T,1) instead of (T,) pattern
        if len(np.shape(y)) == 1 and y !=[]:
            y = np.reshape(y, (len(y), 1), order='F')
        
        ##############################
        ## p checking
        #############################
        # reshape input size to (T,1) instead of (T,) pattern
        if len(np.shape(p)) == 1 and p !=[]:
            p = np.reshape(p, (len(p), 1), order='F')
            
        if len(np.shape(p)) != 0 and len(p) >= 1:
            if min(np.shape(p)) == 1: # Then this will be interpreted as VECTOR format
                p = np.c_[np.ones((len(p),1), dtype=int),p] #convert vector (e.g. [1,5,22]) to matrix ([[1,1],[1,5],[1,22]])
                
            elif np.shape(p)[0] >=1 and np.shape(p)[1] ==2: #Then this will be interpreted as MATRIX format
                p = p #nothing to do
                
            else:
                return print('p must be either a column vector or a # entries by 2 matrix.')
        else:
            return print("p must be either a column vector or a # entries by 2 matrix.")
        
        # Eliminate any dupes
        p = np.unique(p, axis=0)
        
        # Confirm all elements are integers
        nonint = [j for i in p for j in i if j != np.floor(j)] #select out noninteger elements
        if p.min() < 1 or len(nonint) > 0:
            return print('p must contain only positive integers.')
        
        ##############################
        ## constant checking
        #############################        
        if constant == None and len(p) == 0:
            return print('At least one of CONSTANT or P must be nonempty.')
        if constant !=1 and constant !=0:
            return print ('CONSTANT must be 0 or 1.')

        ##############################
        ## nw checking
        #############################          
        if nw == None:
            nw = 0
        elif len(np.shape(nw)) != 0 or nw != np.floor(nw) or nw < 0:
            return print('NW must be a non-negative integer.')
        
        ##############################
        ## spec checking
        #############################          
        if spec == None:
            spec = "STANDARD"
        elif spec != "STANDARD" and  spec != "MODIFIED":
            return print('SPEC must be either "STANDARD" or "MODIFIED".')
        
##############################
##Input Checking End
#############################        
        
    # Spec transform if needed
    numP = len(p)
    maxP = p.max()
    if spec == "MODIFIED":
        ind = np.int32(np.zeros((numP,maxP)))
        for i in range(numP):
            ind[i][p[i][0]-1:p[i][1]] =1
        used = []
        #Transform ind to row echelon form
        for i in range(numP):
            notUsed = list(set(range(numP)) - set(used))
            rows = ind[notUsed]
            if len(rows)> 1:
                entry = rows.max() #get maximum value
                position = np.argmax(rows, axis= 1)[0] #get the index of the maximum value's index
            else:
                entry = rows.max()
                position = np.argmax(rows)
            if entry > 0:
                rowSelected = max(rows[:,position]) #ok<ASGLU>
                originalPosition = notUsed[rowSelected-1]
                used.append(originalPosition)
                row = rows[rowSelected-1]
                leadingElement = row[position]
                row = row/leadingElement
                # Find leading term location and Normalize to be 1
                tmp = list(range(numP))
                tmp.remove(originalPosition)
                
                for j in tmp:
                    ind[j] = ind[j] - ind[j][position]*row
                    # Subtract i from j if same position leading term
                    
        # Finally clean up ind
        for i in range(numP):
            elements =  [e for e,x in enumerate(ind[i]) if x !=0] #find the elements not equal to 0
            if len(elements) > 0:
                ind[i,:] = ind[i,:]/ind[i, elements[0]]
                
        #Is amenable to transformation if max(sum(abs(ind)))==1
        newp = np.zeros(np.shape(p),dtype=int)
        
        if max(np.sum(ind, axis = 0))==1:
            for i in range(numP):
                elements =  [e for e,x in enumerate(ind[i]) if x !=0]
                newp[i,:] = [elements[0], elements[-1]] #find the first and last element equal to 1
            p = newp
        else:
            return print('MFEToolbox:IncompatibleInput','Input P is not compatible with the MODIFIED parameterization.  Using STANDARD parameterization')
        p = np.sort(p) #sort rows based on first column elements
    else:
        p = p-1 #adjust p element to align with python index
        
        
    Y,X = newlagmatrix(y,maxP,0)
    T = len(Y)
    newX = np.zeros((T,numP))
    for i in range(numP):
        newX[:,i] = X[:,p[i,0]:p[i,1]+1].mean(1)
    if constant ==1:
        newX = np.c_[np.ones(len(newX)),newX]
    numX = np.size(newX,1)
    parameters = lstsq(newX, Y)[0] # calculation for newX\Y
    errors = Y - np.matmul(newX,parameters)
    errors = np.reshape(errors, (len(errors), 1), order='F') 
    SEregression = (sum(errors*errors)/(T-numP))**0.5
    A = np.matmul(np.transpose(newX),newX)/T
    Ainv = lstsq(A, np.eye(len(A)))[0]
    s = newX * np.tile(errors, (1,numX)) #repeat errors by (row, col) times
    B = covnw(s, nw, 0)
    VCVrobust = Ainv @ B @ Ainv/T
    VCV = SEregression**2 *Ainv/T
    #Pad errors with 0s for return
    errors = np.vstack([np.zeros((len(y)-T,1)), errors])
        
        
    #Outputs
    aic, sbic = aicsbic(errors,constant,numX-constant,0)
    
    if constant:
        noConstParam = parameters[1:numX]
    else:
        noConstParam = parameters
    
    coefficients = np.zeros((1,maxP))
    for i in range(numP):
        coefficients[:,p[i,0]:p[i,1]+1] = coefficients[:,p[i,0]:p[i,1]+1] + noConstParam[i]/(p[i,1]-p[i,0]+1)
    
    [arroots, absarroots]  = armaroots(coefficients,0,np.array(range(maxP)),0)
    
    diagnostics = {"P": p, "C": constant, "T": len(y), "adjT":T,
               "spec": spec, "AIC": aic, "SBIC": sbic,
               "ARparameterization": coefficients,
               "arroots": arroots, "absarroots": absarroots}
    return parameters, errors, SEregression, diagnostics, VCVrobust, VCV
        
        
        
        
        
        
        
            
                
                
                
                
                
        


    
y =[21, 34, 55, 1, 23, 45, 10, 19, 5, 6, 2, 11]
p=[1,4,5,7]
parameters, errors, SEregression, diagnostics, VCVrobust, VCV = heterogeneousar(y,0,p)

        

    
