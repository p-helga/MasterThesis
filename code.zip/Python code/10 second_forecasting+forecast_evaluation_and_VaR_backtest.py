"""
@author: phelg
References:
-pandas:Data structures for statistical computing in python, McKinney, Proceedings of the 9th Python in Science Conference, Volume 445, 2010.
-numpy:Harris, C.R., Millman, K.J., van der Walt, S.J. et al. Array programming with NumPy. Nature 585, 357–362 (2020). DOI: 10.1038/s41586-020-2649-2. (Publisher link).
-seaborn:Waskom, M. L., (2021). seaborn: statistical data visualization. Journal of Open Source Software, 6(60), 3021, https://doi.org/10.21105/joss.03021
-fun2: Christian Mücher, Financial Econometrics tutorials and Advanced Topics in Econometrics tutorials. Summer Semester 2022. University of Freiburg.
-garches: Kevin Sheppard (2021, March 3). bashtage/arch: Release 4.18 (Version v4.18). Zenodo. https://doi.org/10.5281/zenodo.593254
-Matplotlib: A 2D Graphics Environment", Computing in Science & Engineering, vol. 9, no. 3, pp. 90-95, 2007.
"""
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from arch import arch_model
import scipy.stats as stats
sns.set(color_codes=True)
np.set_printoptions(precision = 4,suppress=True)
from fun2 import evalforecast
import time
tic = time.time()

#import data and get intraday and daily returns and rv:
data_CTS = pd.read_csv('cts_10sec.csv', sep=',' , header = None)
data_BTS=pd.read_csv('bts_10sec.csv', sep=',' , header = None)
data_TTS=pd.read_csv('tts_10sec.csv', sep=',' , header = None)
data_TT=pd.read_csv('tt_10sec.csv', sep=',' , header = None)
data_TRTS=pd.read_csv('trts_10sec.csv', sep=',' , header = None)
data_WSD=pd.read_csv('wsd_10sec.csv', sep=',' , header = None)
data_DA=pd.read_csv('da_10sec.csv', sep=',' , header = None)

data_CTS = data_CTS.astype(float, errors='ignore')
day_CTS = np.unique(data_CTS[0])
time_CTS = data_CTS[1][:2341].values
price_CTS = data_CTS[data_CTS.columns[2]].values

data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:2341].values
price_BTS = data_BTS[data_BTS.columns[2]].values

data_TTS = data_TTS.astype(float, errors='ignore')
day_TTS = np.unique(data_TTS[0])
time_TTS = data_TTS[1][:2341].values
price_TTS = data_TTS[data_TTS.columns[2]].values

data_TT = data_TT.astype(float, errors='ignore')
day_TT = np.unique(data_TT[0])
time_TT = data_TT[1][:2341].values
price_TT = data_TT[data_TT.columns[2]].values

data_TRTS = data_TRTS.astype(float, errors='ignore')
day_TRTS = np.unique(data_TRTS[0])
time_TRTS = data_TRTS[1][:2341].values
price_TRTS = data_TRTS[data_TRTS.columns[2]].values

data_WSD = data_WSD.astype(float, errors='ignore')
day_WSD = np.unique(data_WSD[0])
time_WSD = data_WSD[1][:2341].values
price_WSD = data_WSD[data_WSD.columns[2]].values

data_DA = data_DA.astype(float, errors='ignore')
day_DA = np.unique(data_DA[0])
time_DA = data_DA[1][:2341].values
price_DA = data_DA[data_DA.columns[2]].values

P_CTS = np.zeros([2341,len(day_CTS)])
for i in range(len(day_CTS)):
    P_CTS[:,i] = price_CTS[i*2341:(i+1)*2341]
intraday_returns_CTS = np.diff(np.log(P_CTS),axis=0)
#the days are shown horizontally and
#the timepoints are on the vertical axis

P_BTS = np.zeros([2341,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*2341:(i+1)*2341]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

P_TTS = np.zeros([2341,len(day_TTS)])
for i in range(len(day_TTS)):
    P_TTS[:,i] = price_TTS[i*2341:(i+1)*2341]
intraday_returns_TTS = np.diff(np.log(P_TTS),axis=0)

P_TT = np.zeros([2341,len(day_TT)])
for i in range(len(day_TT)):
    P_TT[:,i] = price_TT[i*2341:(i+1)*2341]
intraday_returns_TT = np.diff(np.log(P_TT),axis=0)

P_TRTS = np.zeros([2341,len(day_TRTS)])
for i in range(len(day_TRTS)):
    P_TRTS[:,i] = price_TRTS[i*2341:(i+1)*2341]
intraday_returns_TRTS = np.diff(np.log(P_TRTS),axis=0)

P_WSD = np.zeros([2341,len(day_WSD)])
for i in range(len(day_WSD)):
    P_WSD[:,i] = price_WSD[i*2341:(i+1)*2341]
intraday_returns_WSD = np.diff(np.log(P_WSD),axis=0)

P_DA = np.zeros([2341,len(day_DA)])
for i in range(len(day_DA)):
    P_DA[:,i] = price_DA[i*2341:(i+1)*2341]
intraday_returns_DA = np.diff(np.log(P_DA),axis=0)

rv_CTS=np.sum(intraday_returns_CTS**2,axis=0)
rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)
rv_TTS=np.sum(intraday_returns_TTS**2,axis=0)
rv_TT=np.sum(intraday_returns_TT**2,axis=0)
rv_TRTS=np.sum(intraday_returns_TRTS**2,axis=0)
rv_WSD=np.sum(intraday_returns_WSD**2,axis=0)
rv_DA=np.sum(intraday_returns_DA**2,axis=0)


dailyret_CTS=np.sum(intraday_returns_CTS,axis=0)
dailyret_BTS=np.sum(intraday_returns_BTS,axis=0)
dailyret_TTS=np.sum(intraday_returns_TTS,axis=0)
dailyret_TT=np.sum(intraday_returns_TT,axis=0)
dailyret_TRTS=np.sum(intraday_returns_TRTS,axis=0)
dailyret_WSD=np.sum(intraday_returns_WSD,axis=0)
dailyret_DA=np.sum(intraday_returns_DA,axis=0)

###################################Split the data##############################
#in-sample daily returns and rv:
    
ind_CTS = np.where(day_CTS==20171229)[0][0]
ind_BTS = np.where(day_BTS==20171229)[0][0]
ind_TTS = np.where(day_TTS==20171229)[0][0]
ind_TT = np.where(day_TT==20171229)[0][0]
ind_TRTS = np.where(day_TRTS==20171229)[0][0]
ind_WSD = np.where(day_WSD==20171229)[0][0]
ind_DA = np.where(day_DA==20171229)[0][0]

r_in_CTS = dailyret_CTS[:ind_CTS+1]
r_in_BTS = dailyret_BTS[:ind_BTS+1]
r_in_TTS = dailyret_TTS[:ind_TTS+1]
r_in_TT = dailyret_TT[:ind_TT+1]
r_in_TRTS = dailyret_TRTS[:ind_TRTS+1]
r_in_WSD = dailyret_WSD[:ind_WSD+1]
r_in_DA = dailyret_DA[:ind_DA+1]

rv_in_CTS = rv_CTS[:ind_CTS+1]
rv_in_BTS = rv_BTS[:ind_BTS+1]
rv_in_TTS = rv_TTS[:ind_TTS+1]
rv_in_TT = rv_TT[:ind_TT+1]
rv_in_TRTS = rv_TRTS[:ind_TRTS+1]
rv_in_WSD = rv_WSD[:ind_WSD+1]
rv_in_DA = rv_DA[:ind_DA+1]
####################estimate HAR model
#@Christian Mücher, Financial Econometrics tutorials. HAR model estimation, Summer Semester 2022. University of Freiburg.
x_CTS = np.sqrt(rv_in_CTS)
X_CTS = np.c_[1,x_CTS[21],np.mean(x_CTS[21-4:22]),np.mean(x_CTS[:22])]
for t in range(22,len(rv_in_CTS)-1):
    X_CTS = np.vstack([X_CTS,np.c_[1,x_CTS[t],np.mean(x_CTS[t-4:t+1]),np.mean(x_CTS[t-21:t+1])]])
Y_CTS = x_CTS[22:]
params_CTS = np.linalg.inv(X_CTS.T@X_CTS)@X_CTS.T@Y_CTS

x_BTS = np.sqrt(rv_in_BTS)
X_BTS = np.c_[1,x_BTS[21],np.mean(x_BTS[21-4:22]),np.mean(x_BTS[:22])]
for t in range(22,len(rv_in_BTS)-1):
    X_BTS = np.vstack([X_BTS,np.c_[1,x_BTS[t],np.mean(x_BTS[t-4:t+1]),np.mean(x_BTS[t-21:t+1])]])
Y_BTS = x_BTS[22:]
params_BTS = np.linalg.inv(X_BTS.T@X_BTS)@X_BTS.T@Y_BTS

x_TTS = np.sqrt(rv_in_TTS)
X_TTS = np.c_[1,x_TTS[21],np.mean(x_TTS[21-4:22]),np.mean(x_TTS[:22])]
for t in range(22,len(rv_in_TTS)-1):
    X_TTS = np.vstack([X_TTS,np.c_[1,x_TTS[t],np.mean(x_TTS[t-4:t+1]),np.mean(x_TTS[t-21:t+1])]])
Y_TTS = x_TTS[22:]
params_TTS = np.linalg.inv(X_TTS.T@X_TTS)@X_TTS.T@Y_TTS

x_TT = np.sqrt(rv_in_TT)
X_TT = np.c_[1,x_TT[21],np.mean(x_TT[21-4:22]),np.mean(x_TT[:22])]
for t in range(22,len(rv_in_TT)-1):
    X_TT = np.vstack([X_TT,np.c_[1,x_TT[t],np.mean(x_TT[t-4:t+1]),np.mean(x_TT[t-21:t+1])]])
Y_TT = x_TT[22:]
params_TT = np.linalg.inv(X_TT.T@X_TT)@X_TT.T@Y_TT

x_TRTS = np.sqrt(rv_in_TRTS)
X_TRTS = np.c_[1,x_TRTS[21],np.mean(x_TRTS[21-4:22]),np.mean(x_TRTS[:22])]
for t in range(22,len(rv_in_TRTS)-1):
    X_TRTS = np.vstack([X_TRTS,np.c_[1,x_TRTS[t],np.mean(x_TRTS[t-4:t+1]),np.mean(x_TRTS[t-21:t+1])]])
Y_TRTS = x_TRTS[22:]
params_TRTS = np.linalg.inv(X_TRTS.T@X_TRTS)@X_TRTS.T@Y_TRTS

x_WSD = np.sqrt(rv_in_WSD)
X_WSD = np.c_[1,x_WSD[21],np.mean(x_WSD[21-4:22]),np.mean(x_WSD[:22])]
for t in range(22,len(rv_in_WSD)-1):
    X_WSD = np.vstack([X_WSD,np.c_[1,x_WSD[t],np.mean(x_WSD[t-4:t+1]),np.mean(x_WSD[t-21:t+1])]])
Y_WSD = x_WSD[22:]
params_WSD = np.linalg.inv(X_WSD.T@X_WSD)@X_WSD.T@Y_WSD

x_DA = np.sqrt(rv_in_DA)
X_DA = np.c_[1,x_DA[21],np.mean(x_DA[21-4:22]),np.mean(x_DA[:22])]
for t in range(22,len(rv_in_DA)-1):
    X_DA = np.vstack([X_DA,np.c_[1,x_DA[t],np.mean(x_DA[t-4:t+1]),np.mean(x_DA[t-21:t+1])]])
Y_DA = x_DA[22:]
params_DA = np.linalg.inv(X_DA.T@X_DA)@X_DA.T@Y_DA

##############################GARCHes#####################
#Kevin Sheppard (2021, March 3). bashtage/arch: Release 4.18 (Version v4.18). Zenodo. https://doi.org/10.5281/zenodo.593254

s_garch_CTS = pd.DataFrame(columns = ['garch','garch_t','egarch','egarch_t','tgarch',
                                  'tgarch_t','RM','RM_t'])
vol_CTS = ['garch','garch','egarch','egarch','garch','garch']
lev_CTS = [0,0,1,1,1,1] #order of asymmetric innovation
dist_CTS = ['normal','t','normal','t','normal','t','normal','t']
for i,p in enumerate(s_garch_CTS.columns[:-2]):
    s_garch_CTS[p] = arch_model(r_in_CTS*100,mean='zero',o = lev_CTS[i],vol = vol_CTS[i],dist = dist_CTS[i]).fit().conditional_volatility

s_garch_BTS = pd.DataFrame(columns = ['garch','garch_t','egarch','egarch_t','tgarch',
                                  'tgarch_t','RM','RM_t'])
vol_BTS = ['garch','garch','egarch','egarch','garch','garch']
lev_BTS = [0,0,1,1,1,1] #order of asymmetric innovation
dist_BTS = ['normal','t','normal','t','normal','t','normal','t']
for i,p in enumerate(s_garch_BTS.columns[:-2]):
    s_garch_BTS[p] = arch_model(r_in_BTS*100,mean='zero',o = lev_BTS[i],vol = vol_BTS[i],dist = dist_BTS[i]).fit().conditional_volatility

s_garch_TTS = pd.DataFrame(columns = ['garch','garch_t','egarch','egarch_t','tgarch',
                                  'tgarch_t','RM','RM_t'])
vol_TTS = ['garch','garch','egarch','egarch','garch','garch']
lev_TTS = [0,0,1,1,1,1] #order of asymmetric innovation
dist_TTS = ['normal','t','normal','t','normal','t','normal','t']
for i,p in enumerate(s_garch_TTS.columns[:-2]):
    s_garch_TTS[p] = arch_model(r_in_TTS*100,mean='zero',o = lev_TTS[i],vol = vol_TTS[i],dist = dist_TTS[i]).fit().conditional_volatility

s_garch_TT = pd.DataFrame(columns = ['garch','garch_t','egarch','egarch_t','tgarch',
                                  'tgarch_t','RM','RM_t'])
vol_TT = ['garch','garch','egarch','egarch','garch','garch']
lev_TT = [0,0,1,1,1,1] #order of asymmetric innovation
dist_TT = ['normal','t','normal','t','normal','t','normal','t']
for i,p in enumerate(s_garch_TT.columns[:-2]):
    s_garch_TT[p] = arch_model(r_in_TT*100,mean='zero',o = lev_TT[i],vol = vol_TT[i],dist = dist_TT[i]).fit().conditional_volatility

s_garch_TRTS = pd.DataFrame(columns = ['garch','garch_t','egarch','egarch_t','tgarch',
                                  'tgarch_t','RM','RM_t'])
vol_TRTS = ['garch','garch','egarch','egarch','garch','garch']
lev_TRTS = [0,0,1,1,1,1] #order of asymmetric innovation
dist_TRTS = ['normal','t','normal','t','normal','t','normal','t']
for i,p in enumerate(s_garch_TRTS.columns[:-2]):
    s_garch_TRTS[p] = arch_model(r_in_TRTS*100,mean='zero',o = lev_TRTS[i],vol = vol_TRTS[i],dist = dist_TRTS[i]).fit().conditional_volatility


s_garch_WSD = pd.DataFrame(columns = ['garch','garch_t','egarch','egarch_t','tgarch',
                                  'tgarch_t','RM','RM_t'])
vol_WSD = ['garch','garch','egarch','egarch','garch','garch']
lev_WSD = [0,0,1,1,1,1] #order of asymmetric innovation
dist_WSD = ['normal','t','normal','t','normal','t','normal','t']
for i,p in enumerate(s_garch_WSD.columns[:-2]):
    s_garch_WSD[p] = arch_model(r_in_WSD*100,mean='zero',o = lev_WSD[i],vol = vol_WSD[i],dist = dist_WSD[i]).fit().conditional_volatility


s_garch_DA = pd.DataFrame(columns = ['garch','garch_t','egarch','egarch_t','tgarch',
                                  'tgarch_t','RM','RM_t'])
vol_DA = ['garch','garch','egarch','egarch','garch','garch']
lev_DA = [0,0,1,1,1,1] #order of asymmetric innovation
dist_DA = ['normal','t','normal','t','normal','t','normal','t']
for i,p in enumerate(s_garch_DA.columns[:-2]):
    s_garch_DA[p] = arch_model(r_in_DA*100,mean='zero',o = lev_DA[i],vol = vol_DA[i],dist = dist_DA[i]).fit().conditional_volatility

################Risk Metrics#################
#@Christian Mücher, Financial Econometrics tutorials. RM model estimation, Summer Semester 2022. University of Freiburg.
def RM(y,lam):
    s = np.zeros_like(y)
    np.insert(s,0,np.mean(y**2))
    for i in range(1,len(y)):
        s[i] = lam*s[i-1]+(1-lam)*y[i-1]**2
    return(np.sqrt(s))
###############################################
s_garch_CTS['RM'] = RM(r_in_CTS*100,0.96)
s_garch_CTS['RM_t'] = RM(r_in_CTS*100,0.96)
s_garch_BTS['RM'] = RM(r_in_BTS*100,0.96)
s_garch_BTS['RM_t'] = RM(r_in_BTS*100,0.96)
s_garch_TTS['RM'] = RM(r_in_TTS*100,0.96)
s_garch_TTS['RM_t'] = RM(r_in_TTS*100,0.96)
s_garch_TT['RM'] = RM(r_in_TT*100,0.96)
s_garch_TT['RM_t'] = RM(r_in_TT*100,0.96)
s_garch_TRTS['RM'] = RM(r_in_TRTS*100,0.96)
s_garch_TRTS['RM_t'] = RM(r_in_TRTS*100,0.96)
s_garch_WSD['RM'] = RM(r_in_WSD*100,0.96)
s_garch_WSD['RM_t'] = RM(r_in_WSD*100,0.96)
s_garch_DA['RM'] = RM(r_in_DA*100,0.96)
s_garch_DA['RM_t'] = RM(r_in_DA*100,0.96)

################Forecasting by 1-step-ahead forecast
#@Christian Mücher, Financial Econometrics tutorials. Variance Forecast. Summer Semester 2022. University of Freiburg.
H_CTS = len(dailyret_CTS[ind_CTS+1:]) #length of the out-of-sample period
fc_CTS = pd.DataFrame(np.zeros([H_CTS,8]),columns = s_garch_CTS.columns)
fc_CTS = fc_CTS.drop(columns='RM_t')
fc_CTS.insert(7,'HAR',np.zeros(H_CTS)) #in the 7th column you add HAR
df_CTS = pd.DataFrame(np.zeros([H_CTS,3]),columns =['garch_t','egarch_t','tgarch_t']) #estimated degrees of freedom
for t in range(H_CTS):
    dat = dailyret_CTS[t:-H_CTS+t]
    for i,p in enumerate(fc_CTS.columns[:-2]):
        m = arch_model(dat*100,mean='zero',o = lev_CTS[i],vol = vol_CTS[i],dist = dist_CTS[i]).fit(disp='off')
        fc_CTS[p][t] = np.sqrt(m.forecast().variance.values[-1])/100
        if dist_CTS[i] == 't':
            df_CTS[p][t] = m.params.nu
    aux = RM((dat*100)**2,0.94)
    fc_CTS['RM'][t] = np.sqrt(0.94*aux[-1]+0.06*(dat[-1]*100)**2)/100
        
    dat2 = np.sqrt(rv_CTS[t:-H_CTS+t])    
    X = np.c_[1,dat[21],np.mean(dat[21-4:22]),np.mean(dat[:22])]
    for i in range(22,len(dat2)-1):
        X = np.vstack([X,np.c_[1,dat2[i],np.mean(dat2[i-4:i+1]),np.mean(dat2[i-21:i+1])]])
    Y = dat2[22:]
    params = np.linalg.inv(X.T@X)@X.T@Y
    fc_CTS['HAR'][t] = np.c_[1,dat2[-1],np.mean(dat2[-5:]),np.mean(dat2[-22:])]@params


H_BTS = len(dailyret_BTS[ind_BTS+1:]) #length of the out-of-sample period
fc_BTS = pd.DataFrame(np.zeros([H_BTS,8]),columns = s_garch_BTS.columns)
fc_BTS = fc_BTS.drop(columns='RM_t')
fc_BTS.insert(7,'HAR',np.zeros(H_BTS)) #in the 7th column you add HAR
df_BTS = pd.DataFrame(np.zeros([H_BTS,3]),columns =['garch_t','egarch_t','tgarch_t']) #estimated degrees of freedom
for t in range(H_BTS):
    dat = dailyret_BTS[t:-H_BTS+t]
    for i,p in enumerate(fc_BTS.columns[:-2]):
        m = arch_model(dat*100,mean='zero',o = lev_BTS[i],vol = vol_BTS[i],dist = dist_BTS[i]).fit(disp='off')
        fc_BTS[p][t] = np.sqrt(m.forecast().variance.values[-1])/100
        if dist_BTS[i] == 't':
            df_BTS[p][t] = m.params.nu
    aux = RM((dat*100)**2,0.94)
    fc_BTS['RM'][t] = np.sqrt(0.94*aux[-1]+0.06*(dat[-1]*100)**2)/100
        
    dat2 = np.sqrt(rv_BTS[t:-H_BTS+t])    
    X = np.c_[1,dat[21],np.mean(dat[21-4:22]),np.mean(dat[:22])]
    for i in range(22,len(dat2)-1):
        X = np.vstack([X,np.c_[1,dat2[i],np.mean(dat2[i-4:i+1]),np.mean(dat2[i-21:i+1])]])
    Y = dat2[22:]
    params = np.linalg.inv(X.T@X)@X.T@Y
    fc_BTS['HAR'][t] = np.c_[1,dat2[-1],np.mean(dat2[-5:]),np.mean(dat2[-22:])]@params



H_TTS = len(dailyret_TTS[ind_TTS+1:]) #length of the out-of-sample period
fc_TTS = pd.DataFrame(np.zeros([H_TTS,8]),columns = s_garch_TTS.columns)
fc_TTS = fc_TTS.drop(columns='RM_t')
fc_TTS.insert(7,'HAR',np.zeros(H_TTS)) #in the 7th column you add HAR
df_TTS = pd.DataFrame(np.zeros([H_TTS,3]),columns =['garch_t','egarch_t','tgarch_t']) #estimated degrees of freedom
for t in range(H_TTS):
    dat = dailyret_TTS[t:-H_TTS+t]
    for i,p in enumerate(fc_TTS.columns[:-2]):
        m = arch_model(dat*100,mean='zero',o = lev_TTS[i],vol = vol_TTS[i],dist = dist_TTS[i]).fit(disp='off')
        fc_TTS[p][t] = np.sqrt(m.forecast().variance.values[-1])/100
        if dist_TTS[i] == 't':
            df_TTS[p][t] = m.params.nu
    aux = RM((dat*100)**2,0.94)
    fc_TTS['RM'][t] = np.sqrt(0.94*aux[-1]+0.06*(dat[-1]*100)**2)/100
        
    dat2 = np.sqrt(rv_TTS[t:-H_TTS+t])    
    X = np.c_[1,dat[21],np.mean(dat[21-4:22]),np.mean(dat[:22])]
    for i in range(22,len(dat2)-1):
        X = np.vstack([X,np.c_[1,dat2[i],np.mean(dat2[i-4:i+1]),np.mean(dat2[i-21:i+1])]])
    Y = dat2[22:]
    params = np.linalg.inv(X.T@X)@X.T@Y
    fc_TTS['HAR'][t] = np.c_[1,dat2[-1],np.mean(dat2[-5:]),np.mean(dat2[-22:])]@params

H_TT = len(dailyret_TT[ind_TT+1:]) #length of the out-of-sample period
fc_TT = pd.DataFrame(np.zeros([H_TT,8]),columns = s_garch_TT.columns)
fc_TT = fc_TT.drop(columns='RM_t')
fc_TT.insert(7,'HAR',np.zeros(H_TT)) #in the 7th column you add HAR
df_TT = pd.DataFrame(np.zeros([H_TT,3]),columns =['garch_t','egarch_t','tgarch_t']) #estimated degrees of freedom
for t in range(H_TT):
    dat = dailyret_TT[t:-H_TT+t]
    for i,p in enumerate(fc_TT.columns[:-2]):
        m = arch_model(dat*100,mean='zero',o = lev_TT[i],vol = vol_TT[i],dist = dist_TT[i]).fit(disp='off')
        fc_TT[p][t] = np.sqrt(m.forecast().variance.values[-1])/100
        if dist_TT[i] == 't':
            df_TT[p][t] = m.params.nu
    aux = RM((dat*100)**2,0.94)
    fc_TT['RM'][t] = np.sqrt(0.94*aux[-1]+0.06*(dat[-1]*100)**2)/100
        
    dat2 = np.sqrt(rv_TT[t:-H_TT+t])    
    X = np.c_[1,dat[21],np.mean(dat[21-4:22]),np.mean(dat[:22])]
    for i in range(22,len(dat2)-1):
        X = np.vstack([X,np.c_[1,dat2[i],np.mean(dat2[i-4:i+1]),np.mean(dat2[i-21:i+1])]])
    Y = dat2[22:]
    params = np.linalg.inv(X.T@X)@X.T@Y
    fc_TT['HAR'][t] = np.c_[1,dat2[-1],np.mean(dat2[-5:]),np.mean(dat2[-22:])]@params
    
H_TRTS = len(dailyret_TRTS[ind_TRTS+1:]) #length of the out-of-sample period
fc_TRTS = pd.DataFrame(np.zeros([H_TRTS,8]),columns = s_garch_TRTS.columns)
fc_TRTS = fc_TRTS.drop(columns='RM_t')
fc_TRTS.insert(7,'HAR',np.zeros(H_TRTS)) #in the 7th column you add HAR
df_TRTS = pd.DataFrame(np.zeros([H_TRTS,3]),columns =['garch_t','egarch_t','tgarch_t']) #estimated degrees of freedom
for t in range(H_TRTS):
    dat = dailyret_TRTS[t:-H_TRTS+t]
    for i,p in enumerate(fc_TRTS.columns[:-2]):
        m = arch_model(dat*100,mean='zero',o = lev_TRTS[i],vol = vol_TRTS[i],dist = dist_TRTS[i]).fit(disp='off')
        fc_TRTS[p][t] = np.sqrt(m.forecast().variance.values[-1])/100
        if dist_TRTS[i] == 't':
            df_TRTS[p][t] = m.params.nu
    aux = RM((dat*100)**2,0.94)
    fc_TRTS['RM'][t] = np.sqrt(0.94*aux[-1]+0.06*(dat[-1]*100)**2)/100
        
    dat2 = np.sqrt(rv_TRTS[t:-H_TRTS+t])    
    X = np.c_[1,dat[21],np.mean(dat[21-4:22]),np.mean(dat[:22])]
    for i in range(22,len(dat2)-1):
        X = np.vstack([X,np.c_[1,dat2[i],np.mean(dat2[i-4:i+1]),np.mean(dat2[i-21:i+1])]])
    Y = dat2[22:]
    params = np.linalg.inv(X.T@X)@X.T@Y
    fc_TRTS['HAR'][t] = np.c_[1,dat2[-1],np.mean(dat2[-5:]),np.mean(dat2[-22:])]@params
    
H_WSD = len(dailyret_WSD[ind_WSD+1:]) #length of the out-of-sample period
fc_WSD = pd.DataFrame(np.zeros([H_WSD,8]),columns = s_garch_WSD.columns)
fc_WSD = fc_WSD.drop(columns='RM_t')
fc_WSD.insert(7,'HAR',np.zeros(H_WSD)) #in the 7th column you add HAR
df_WSD = pd.DataFrame(np.zeros([H_WSD,3]),columns =['garch_t','egarch_t','tgarch_t']) #estimated degrees of freedom
for t in range(H_WSD):
    dat = dailyret_WSD[t:-H_WSD+t]
    for i,p in enumerate(fc_WSD.columns[:-2]):
        m = arch_model(dat*100,mean='zero',o = lev_WSD[i],vol = vol_WSD[i],dist = dist_WSD[i]).fit(disp='off')
        fc_WSD[p][t] = np.sqrt(m.forecast().variance.values[-1])/100
        if dist_WSD[i] == 't':
            df_WSD[p][t] = m.params.nu
    aux = RM((dat*100)**2,0.94)
    fc_WSD['RM'][t] = np.sqrt(0.94*aux[-1]+0.06*(dat[-1]*100)**2)/100
        
    dat2 = np.sqrt(rv_WSD[t:-H_WSD+t])    
    X = np.c_[1,dat[21],np.mean(dat[21-4:22]),np.mean(dat[:22])]
    for i in range(22,len(dat2)-1):
        X = np.vstack([X,np.c_[1,dat2[i],np.mean(dat2[i-4:i+1]),np.mean(dat2[i-21:i+1])]])
    Y = dat2[22:]
    params = np.linalg.inv(X.T@X)@X.T@Y
    fc_WSD['HAR'][t] = np.c_[1,dat2[-1],np.mean(dat2[-5:]),np.mean(dat2[-22:])]@params
    
H_DA = len(dailyret_DA[ind_DA+1:]) #length of the out-of-sample period
fc_DA = pd.DataFrame(np.zeros([H_DA,8]),columns = s_garch_DA.columns)
fc_DA = fc_DA.drop(columns='RM_t')
fc_DA.insert(7,'HAR',np.zeros(H_DA)) #in the 7th column you add HAR
df_DA = pd.DataFrame(np.zeros([H_DA,3]),columns =['garch_t','egarch_t','tgarch_t']) #estimated degrees of freedom
for t in range(H_DA):
    dat = dailyret_DA[t:-H_DA+t]
    for i,p in enumerate(fc_DA.columns[:-2]):
        m = arch_model(dat*100,mean='zero',o = lev_DA[i],vol = vol_DA[i],dist = dist_DA[i]).fit(disp='off')
        fc_DA[p][t] = np.sqrt(m.forecast().variance.values[-1])/100
        if dist_DA[i] == 't':
            df_DA[p][t] = m.params.nu
    aux = RM((dat*100)**2,0.94)
    fc_DA['RM'][t] = np.sqrt(0.94*aux[-1]+0.06*(dat[-1]*100)**2)/100
        
    dat2 = np.sqrt(rv_DA[t:-H_DA+t])    
    X = np.c_[1,dat[21],np.mean(dat[21-4:22]),np.mean(dat[:22])]
    for i in range(22,len(dat2)-1):
        X = np.vstack([X,np.c_[1,dat2[i],np.mean(dat2[i-4:i+1]),np.mean(dat2[i-21:i+1])]])
    Y = dat2[22:]
    params = np.linalg.inv(X.T@X)@X.T@Y
    fc_DA['HAR'][t] = np.c_[1,dat2[-1],np.mean(dat2[-5:]),np.mean(dat2[-22:])]@params
##################################################################################################

#################Forecast Evaluation
FE_RV_CTS = pd.DataFrame(data=np.zeros([2,8]),columns=fc_CTS.columns,index = ['RMSFE','MAPE'])
for c in fc_CTS.columns:
    FE_RV_CTS[c]['RMSFE'] = evalforecast(fc_CTS[c],np.sqrt(rv_CTS[-H_CTS:]),1)
    FE_RV_CTS[c]['MAPE'] = evalforecast(fc_CTS[c],np.sqrt(rv_CTS[-H_CTS:]),2)
print(round(FE_RV_CTS,4))

FE_RV_BTS = pd.DataFrame(data=np.zeros([2,8]),columns=fc_BTS.columns,index = ['RMSFE','MAPE'])
for c in fc_BTS.columns:
    FE_RV_BTS[c]['RMSFE'] = evalforecast(fc_BTS[c],np.sqrt(rv_BTS[-H_BTS:]),1)
    FE_RV_BTS[c]['MAPE'] = evalforecast(fc_BTS[c],np.sqrt(rv_BTS[-H_BTS:]),2)
print(round(FE_RV_BTS,4))

FE_RV_TTS = pd.DataFrame(data=np.zeros([2,8]),columns=fc_TTS.columns,index = ['RMSFE','MAPE'])
for c in fc_TTS.columns:
    FE_RV_TTS[c]['RMSFE'] = evalforecast(fc_TTS[c],np.sqrt(rv_TTS[-H_TTS:]),1)
    FE_RV_TTS[c]['MAPE'] = evalforecast(fc_TTS[c],np.sqrt(rv_TTS[-H_TTS:]),2)
print(round(FE_RV_TTS,4))

FE_RV_TT = pd.DataFrame(data=np.zeros([2,8]),columns=fc_TT.columns,index = ['RMSFE','MAPE'])
for c in fc_TT.columns:
    FE_RV_TT[c]['RMSFE'] = evalforecast(fc_TT[c],np.sqrt(rv_TT[-H_TT:]),1)
    FE_RV_TT[c]['MAPE'] = evalforecast(fc_TT[c],np.sqrt(rv_TT[-H_TT:]),2)
print(round(FE_RV_TT,4))

FE_RV_TRTS = pd.DataFrame(data=np.zeros([2,8]),columns=fc_TRTS.columns,index = ['RMSFE','MAPE'])
for c in fc_TRTS.columns:
    FE_RV_TRTS[c]['RMSFE'] = evalforecast(fc_TRTS[c],np.sqrt(rv_TRTS[-H_TRTS:]),1)
    FE_RV_TRTS[c]['MAPE'] = evalforecast(fc_TRTS[c],np.sqrt(rv_TRTS[-H_TRTS:]),2)
print(round(FE_RV_TRTS,4))

FE_RV_WSD = pd.DataFrame(data=np.zeros([2,8]),columns=fc_WSD.columns,index = ['RMSFE','MAPE'])
for c in fc_WSD.columns:
    FE_RV_WSD[c]['RMSFE'] = evalforecast(fc_WSD[c],np.sqrt(rv_WSD[-H_WSD:]),1)
    FE_RV_WSD[c]['MAPE'] = evalforecast(fc_WSD[c],np.sqrt(rv_WSD[-H_WSD:]),2)
print(round(FE_RV_WSD,4))

FE_RV_DA = pd.DataFrame(data=np.zeros([2,8]),columns=fc_DA.columns,index = ['RMSFE','MAPE'])
for c in fc_DA.columns:
    FE_RV_DA[c]['RMSFE'] = evalforecast(fc_DA[c],np.sqrt(rv_DA[-H_DA:]),1)
    FE_RV_DA[c]['MAPE'] = evalforecast(fc_DA[c],np.sqrt(rv_DA[-H_DA:]),2)
print(round(FE_RV_DA,4))

with pd.ExcelWriter('Forecast Evaluation_10sec_all_schemes.xlsx') as writer:  
    FE_RV_CTS.to_excel(writer, sheet_name='RV_CTS')
    # FE_ret_CTS.to_excel(writer, sheet_name='ret_CTS')
    FE_RV_BTS.to_excel(writer, sheet_name='RV_BTS')
    # FE_ret_BTS.to_excel(writer, sheet_name='ret_BTS')
    FE_RV_TTS.to_excel(writer, sheet_name='RV_TTS')
    # FE_ret_TTS.to_excel(writer, sheet_name='ret_TTS')
    FE_RV_TT.to_excel(writer, sheet_name='RV_TT')
    FE_RV_TRTS.to_excel(writer, sheet_name='RV_TRTS')
    FE_RV_WSD.to_excel(writer, sheet_name='RV_WSD')
    FE_RV_DA.to_excel(writer, sheet_name='RV_DA')
  
#Model Confidence Set using 5m BTS as Proxy
ForecastEvaluationRV = pd.read_excel('RV BTS 5minutes.xlsx', sheet_name=None)
ForecastEvaluationReturns=pd.read_excel('dailyret BTS 5minutes.xlsx', sheet_name=None)
RV_BTS_5m=ForecastEvaluationRV['Realized Variances']['variances']
RV_BTS_5m=np.array(RV_BTS_5m)
dailyret_BTS_5m=ForecastEvaluationReturns['Daily Returns']['returns']
dailyret_BTS_5m=np.array(dailyret_BTS_5m)

from arch.bootstrap import MCS
#@Christian Mücher, Financial Econometrics tutorials. MCS. Summer Semester 2022. University of Freiburg.
losses_CTS = pd.DataFrame(columns = fc_CTS.keys())
for i in fc_CTS.keys():
    losses_CTS[i] = np.abs(fc_CTS[i]-np.sqrt(RV_BTS_5m[-H_BTS:]))
mcs_CTS = MCS(losses_CTS,0.05)
mcs_CTS.compute()
print('MCS P-values CTS')
print(mcs_CTS.pvalues)

losses_BTS = pd.DataFrame(columns = fc_BTS.keys())
for i in fc_BTS.keys():
    losses_BTS[i] = np.abs(fc_BTS[i]-np.sqrt(RV_BTS_5m[-H_BTS:]))
mcs_BTS = MCS(losses_BTS,0.05)
mcs_BTS.compute()
print('MCS P-values BTS')
print(mcs_BTS.pvalues)

losses_TTS = pd.DataFrame(columns = fc_TTS.keys())
for i in fc_TTS.keys():
    losses_TTS[i] = np.abs(fc_TTS[i]-np.sqrt(RV_BTS_5m[-H_BTS:]))
mcs_TTS = MCS(losses_TTS,0.05)
mcs_TTS.compute()
print('MCS P-values TTS')
print(mcs_TTS.pvalues)

losses_TT = pd.DataFrame(columns = fc_TT.keys())
for i in fc_TT.keys():
    losses_TT[i] = np.abs(fc_TT[i]-np.sqrt(RV_BTS_5m[-H_BTS:]))
mcs_TT = MCS(losses_TT,0.05)
mcs_TT.compute()
print('MCS P-values TT')
print(mcs_TT.pvalues)

losses_TRTS = pd.DataFrame(columns = fc_TRTS.keys())
for i in fc_TRTS.keys():
    losses_TRTS[i] = np.abs(fc_TRTS[i]-np.sqrt(RV_BTS_5m[-H_BTS:]))
mcs_TRTS = MCS(losses_TRTS,0.05)
mcs_TRTS.compute()
print('MCS P-values TRTS')
print(mcs_TRTS.pvalues)

losses_WSD = pd.DataFrame(columns = fc_WSD.keys())
for i in fc_WSD.keys():
    losses_WSD[i] = np.abs(fc_WSD[i]-np.sqrt(RV_BTS_5m[-H_BTS:]))
mcs_WSD = MCS(losses_WSD,0.05)
mcs_WSD.compute()
print('MCS P-values WSD')
print(mcs_WSD.pvalues)

losses_DA = pd.DataFrame(columns = fc_DA.keys())
for i in fc_DA.keys():
    losses_DA[i] = np.abs(fc_DA[i]-np.sqrt(RV_BTS_5m[-H_BTS:]))
mcs_DA = MCS(losses_DA,0.05)
mcs_DA.compute()
print('MCS P-values DA')
print(mcs_DA.pvalues)

with pd.ExcelWriter('Model Confidence Set 10sec_all.xlsx') as writer:  
    mcs_CTS.pvalues.to_excel(writer, sheet_name='CTS')
    mcs_BTS.pvalues.to_excel(writer, sheet_name='BTS')
    mcs_TTS.pvalues.to_excel(writer, sheet_name='TTS')
    mcs_TT.pvalues.to_excel(writer, sheet_name='TT')
    mcs_TRTS.pvalues.to_excel(writer, sheet_name='TRTS')
    mcs_WSD.pvalues.to_excel(writer, sheet_name='WSD')
    mcs_DA.pvalues.to_excel(writer, sheet_name='DA')

################################VaR###################################
alpha=0.05

VaR_CTS = pd.DataFrame(np.zeros([H_CTS,8]),columns=fc_CTS.columns)
VaR_BTS = pd.DataFrame(np.zeros([H_BTS,8]),columns=fc_BTS.columns)
VaR_TTS = pd.DataFrame(np.zeros([H_TTS,8]),columns=fc_TTS.columns)
VaR_TT = pd.DataFrame(np.zeros([H_TT,8]),columns=fc_TT.columns)
VaR_TRTS = pd.DataFrame(np.zeros([H_TRTS,8]),columns=fc_TRTS.columns)
VaR_WSD = pd.DataFrame(np.zeros([H_WSD,8]),columns=fc_WSD.columns)
VaR_DA = pd.DataFrame(np.zeros([H_DA,8]),columns=fc_DA.columns)

#estimate df by Max Likelihood on the standardized return series
#https://docs.scipy.org/doc/scipy-0.14.0/reference/generated/scipy.stats.rv_continuous.fit.html
df_RM_CTS=stats.t.fit(dailyret_CTS[:-H_CTS])[0]
df_HAR_CTS=stats.t.fit(dailyret_CTS[:-H_CTS])[0]
df_CTS.insert(3,'RM_t',df_RM_CTS)
df_CTS.insert(4, 'HAR_t', df_HAR_CTS)
#calculate the forecasted VaR:
fc_CTS.insert(7,'RM_t',fc_CTS['RM'])
fc_CTS.insert(9,'HAR_t',fc_CTS['HAR']) 
dist_CTS.append('normal') #we have a normal distribution for the HAR
#repeat in the case when HAR is t distributed:
dist_CTS.append('t')
VaR_CTS.insert(7,'RM_t',np.zeros(H_CTS))
VaR_CTS.insert(9,'HAR_t',np.zeros(H_CTS))

df_RM_BTS=stats.t.fit(dailyret_BTS[:-H_BTS])[0]
df_HAR_BTS=stats.t.fit(dailyret_BTS[:-H_BTS])[0]
df_BTS.insert(3,'RM_t',df_RM_BTS)
df_BTS.insert(4, 'HAR_t', df_HAR_BTS)
#calculate the forecasted VaR:
fc_BTS.insert(7,'RM_t',fc_BTS['RM'])
fc_BTS.insert(9,'HAR_t',fc_BTS['HAR']) 
dist_BTS.append('normal') #we have a normal distribution for the HAR
#repeat in the case when HAR is t distributed:
dist_BTS.append('t')
VaR_BTS.insert(7,'RM_t',np.zeros(H_BTS))
VaR_BTS.insert(9,'HAR_t',np.zeros(H_BTS))

df_RM_TTS=stats.t.fit(dailyret_TTS[:-H_TTS])[0]
df_HAR_TTS=stats.t.fit(dailyret_TTS[:-H_TTS])[0]
df_TTS.insert(3,'RM_t',df_RM_TTS)
df_TTS.insert(4, 'HAR_t', df_HAR_TTS)
#calculate the forecasted VaR:
fc_TTS.insert(7,'RM_t',fc_TTS['RM'])
fc_TTS.insert(9,'HAR_t',fc_TTS['HAR']) 
dist_TTS.append('normal') #we have a normal distribution for the HAR
#repeat in the case when HAR is t distributed:
dist_TTS.append('t')
VaR_TTS.insert(7,'RM_t',np.zeros(H_TTS))
VaR_TTS.insert(9,'HAR_t',np.zeros(H_TTS))

df_RM_TT=stats.t.fit(dailyret_TT[:-H_TT])[0]
df_HAR_TT=stats.t.fit(dailyret_TT[:-H_TT])[0]
df_TT.insert(3,'RM_t',df_RM_TT)
df_TT.insert(4, 'HAR_t', df_HAR_TT)
#calculate the forecasted VaR:
fc_TT.insert(7,'RM_t',fc_TT['RM'])
fc_TT.insert(9,'HAR_t',fc_TT['HAR']) 
dist_TT.append('normal') #we have a normal distribution for the HAR
#repeat in the case when HAR is t distributed:
dist_TT.append('t')
VaR_TT.insert(7,'RM_t',np.zeros(H_TT))
VaR_TT.insert(9,'HAR_t',np.zeros(H_TT))

df_RM_TRTS=stats.t.fit(dailyret_TRTS[:-H_TRTS])[0]
df_HAR_TRTS=stats.t.fit(dailyret_TRTS[:-H_TRTS])[0]
df_TRTS.insert(3,'RM_t',df_RM_TRTS)
df_TRTS.insert(4, 'HAR_t', df_HAR_TRTS)
#calculate the forecasted VaR:
fc_TRTS.insert(7,'RM_t',fc_TRTS['RM'])
fc_TRTS.insert(9,'HAR_t',fc_TRTS['HAR']) 
dist_TRTS.append('normal') #we have a normal distribution for the HAR
#repeat in the case when HAR is t distributed:
dist_TRTS.append('t')
VaR_TRTS.insert(7,'RM_t',np.zeros(H_TRTS))
VaR_TRTS.insert(9,'HAR_t',np.zeros(H_TRTS))

df_RM_WSD=stats.t.fit(dailyret_WSD[:-H_WSD])[0]
df_HAR_WSD=stats.t.fit(dailyret_WSD[:-H_WSD])[0]
df_WSD.insert(3,'RM_t',df_RM_WSD)
df_WSD.insert(4, 'HAR_t', df_HAR_WSD)
#calculate the forecasted VaR:
fc_WSD.insert(7,'RM_t',fc_WSD['RM'])
fc_WSD.insert(9,'HAR_t',fc_WSD['HAR']) 
dist_WSD.append('normal') #we have a normal distribution for the HAR
#repeat in the case when HAR is t distributed:
dist_WSD.append('t')
VaR_WSD.insert(7,'RM_t',np.zeros(H_WSD))
VaR_WSD.insert(9,'HAR_t',np.zeros(H_WSD))

df_RM_DA=stats.t.fit(dailyret_DA[:-H_DA])[0]
df_HAR_DA=stats.t.fit(dailyret_DA[:-H_DA])[0]
df_DA.insert(3,'RM_t',df_RM_DA)
df_DA.insert(4, 'HAR_t', df_HAR_DA)
#calculate the forecasted VaR:
fc_DA.insert(7,'RM_t',fc_DA['RM'])
fc_DA.insert(9,'HAR_t',fc_DA['HAR']) 
dist_DA.append('normal') #we have a normal distribution for the HAR
#repeat in the case when HAR is t distributed:
dist_DA.append('t')
VaR_DA.insert(7,'RM_t',np.zeros(H_DA))
VaR_DA.insert(9,'HAR_t',np.zeros(H_DA))

r_in_CTS = dailyret_CTS[:ind_CTS+1]*100
r_in_BTS = dailyret_BTS[:ind_BTS+1]*100
r_in_TTS = dailyret_TTS[:ind_TTS+1]*100
r_in_TT = dailyret_TT[:ind_TT+1]*100
r_in_TRTS = dailyret_TRTS[:ind_TRTS+1]*100
r_in_WSD = dailyret_WSD[:ind_WSD+1]*100
r_in_DA = dailyret_DA[:ind_DA+1]*100

intraday_r_in_CTS = np.zeros([2340,ind_CTS+1])
intraday_r_in_BTS = np.zeros([2340,ind_BTS+1])
intraday_r_in_TTS = np.zeros([2340,ind_TTS+1])
intraday_r_in_TT = np.zeros([2340,ind_TT+1])
intraday_r_in_TRTS = np.zeros([2340,ind_TRTS+1])
intraday_r_in_WSD = np.zeros([2340,ind_WSD+1])
intraday_r_in_DA = np.zeros([2340,ind_DA+1])

for t in range(0,2340):
    intraday_r_in_CTS[t]= intraday_returns_CTS[t][:ind_CTS+1]*100
 
for t in range(0,2340):
    intraday_r_in_BTS[t]= intraday_returns_BTS[t][:ind_BTS+1]*100
     
for t in range(0,2340):
    intraday_r_in_TTS[t]= intraday_returns_TTS[t][:ind_TTS+1]*100

for t in range(0,2340):
    intraday_r_in_TT[t]= intraday_returns_TT[t][:ind_TT+1]*100
    
for t in range(0,2340):
    intraday_r_in_TRTS[t]= intraday_returns_TRTS[t][:ind_TRTS+1]*100
    
for t in range(0,2340):
    intraday_r_in_WSD[t]= intraday_returns_WSD[t][:ind_WSD+1]*100
    
for t in range(0,2340):
    intraday_r_in_DA[t]= intraday_returns_DA[t][:ind_DA+1]*100
    
#unconditional VaR assumes that the volatility is constant over time

mu_CTS= np.mean(intraday_r_in_CTS,axis=0) #we study the unconditional VaR and we assume that mu, s are constant over time
mu_BTS= np.mean(intraday_r_in_BTS,axis=0)
mu_TTS= np.mean(intraday_r_in_TTS,axis=0)
mu_TT= np.mean(intraday_r_in_TT,axis=0)
mu_TRTS= np.mean(intraday_r_in_TRTS,axis=0)
mu_WSD= np.mean(intraday_r_in_WSD,axis=0)
mu_DA= np.mean(intraday_r_in_DA,axis=0)

s_CTS = np.std(intraday_r_in_CTS, axis=0)
s_BTS = np.std(intraday_r_in_BTS, axis=0)
s_TTS = np.std(intraday_r_in_TTS, axis=0)
s_TT = np.std(intraday_r_in_TT, axis=0)
s_TRTS = np.std(intraday_r_in_TRTS, axis=0)
s_WSD = np.std(intraday_r_in_WSD, axis=0)
s_DA = np.std(intraday_r_in_DA, axis=0)

#assume that the conditional mean is zero and use the conditional variance 
#that were forecasted by the models - fc table
for i,c in enumerate(VaR_CTS.columns[:]):
    if dist_CTS[i] == 'normal':
        VaR_CTS[c] = np.exp(stats.norm.ppf(alpha)*fc_CTS[c].values)-1
    else:
        VaR_CTS[c] = np.exp(stats.t.ppf(alpha,df_CTS[c].values)*fc_CTS[c].values)-1     

for i,c in enumerate(VaR_BTS.columns[:]):
    if dist_BTS[i] == 'normal':
        VaR_BTS[c] = np.exp(stats.norm.ppf(alpha)*fc_BTS[c].values)-1
    else:
        VaR_BTS[c] = np.exp(stats.t.ppf(alpha,df_BTS[c].values)*fc_BTS[c].values)-1     

for i,c in enumerate(VaR_TTS.columns[:]):
    if dist_TTS[i] == 'normal':
        VaR_TTS[c] = np.exp(stats.norm.ppf(alpha)*fc_TTS[c].values)-1
    else:
        VaR_TTS[c] = np.exp(stats.t.ppf(alpha,df_TTS[c].values)*fc_TTS[c].values)-1     

for i,c in enumerate(VaR_TT.columns[:]):
    if dist_TT[i] == 'normal':
        VaR_TT[c] = np.exp(stats.norm.ppf(alpha)*fc_TT[c].values)-1
    else:
        VaR_TT[c] = np.exp(stats.t.ppf(alpha,df_TT[c].values)*fc_TT[c].values)-1  
        
for i,c in enumerate(VaR_TRTS.columns[:]):
    if dist_TRTS[i] == 'normal':
        VaR_TRTS[c] = np.exp(stats.norm.ppf(alpha)*fc_TRTS[c].values)-1
    else:
        VaR_TRTS[c] = np.exp(stats.t.ppf(alpha,df_TRTS[c].values)*fc_TRTS[c].values)-1  
        
for i,c in enumerate(VaR_WSD.columns[:]):
    if dist_WSD[i] == 'normal':
        VaR_WSD[c] = np.exp(stats.norm.ppf(alpha)*fc_WSD[c].values)-1
    else:
        VaR_WSD[c] = np.exp(stats.t.ppf(alpha,df_WSD[c].values)*fc_WSD[c].values)-1  
        
for i,c in enumerate(VaR_DA.columns[:]):
    if dist_DA[i] == 'normal':
        VaR_DA[c] = np.exp(stats.norm.ppf(alpha)*fc_DA[c].values)-1
    else:
        VaR_DA[c] = np.exp(stats.t.ppf(alpha,df_DA[c].values)*fc_DA[c].values)-1  

########################Expected Shortfall#######################
#@Christian Mücher, Financial Econometrics tutorials. Expected Shortfall. Summer Semester 2022. University of Freiburg.
ES_CTS = pd.DataFrame(np.zeros([H_CTS,10]),columns=VaR_CTS.columns)
for i,c in enumerate(ES_CTS.columns[:]):
    if dist_CTS[i] == 'normal':
        alph = VaR_CTS[c]/fc_CTS[c]
        l = -stats.norm.pdf(alph)/stats.norm.cdf(alph)
        ES_CTS[c] = fc_CTS[c]*l     
    else:
        rat = VaR_CTS[c]/fc_CTS[c]
        ES_CTS[c] = -fc_CTS[c]/stats.t.cdf(rat,df_CTS[c])*stats.t.pdf(rat,df_CTS[c])*(df_CTS[c]+rat**2)/(df_CTS[c]-1)

ES_BTS = pd.DataFrame(np.zeros([H_BTS,10]),columns=VaR_BTS.columns)
for i,c in enumerate(ES_BTS.columns[:]):
    if dist_BTS[i] == 'normal':
        alph = VaR_BTS[c]/fc_BTS[c]
        l = -stats.norm.pdf(alph)/stats.norm.cdf(alph)
        ES_BTS[c] = fc_BTS[c]*l     
    else:
        rat = VaR_BTS[c]/fc_BTS[c]
        ES_BTS[c] = -fc_BTS[c]/stats.t.cdf(rat,df_BTS[c])*stats.t.pdf(rat,df_BTS[c])*(df_BTS[c]+rat**2)/(df_BTS[c]-1)

ES_TTS = pd.DataFrame(np.zeros([H_TTS,10]),columns=VaR_TTS.columns)
for i,c in enumerate(ES_TTS.columns[:]):
    if dist_TTS[i] == 'normal':
        alph = VaR_TTS[c]/fc_TTS[c]
        l = -stats.norm.pdf(alph)/stats.norm.cdf(alph)
        ES_TTS[c] = fc_TTS[c]*l     
    else:
        rat = VaR_TTS[c]/fc_TTS[c]
        ES_TTS[c] = -fc_TTS[c]/stats.t.cdf(rat,df_TTS[c])*stats.t.pdf(rat,df_TTS[c])*(df_TTS[c]+rat**2)/(df_TTS[c]-1)

ES_TT = pd.DataFrame(np.zeros([H_TT,10]),columns=VaR_TT.columns)
for i,c in enumerate(ES_TT.columns[:]):
    if dist_TT[i] == 'normal':
        alph = VaR_TT[c]/fc_TT[c]
        l = -stats.norm.pdf(alph)/stats.norm.cdf(alph)
        ES_TT[c] = fc_TT[c]*l     
    else:
        rat = VaR_TT[c]/fc_TT[c]
        ES_TT[c] = -fc_TT[c]/stats.t.cdf(rat,df_TT[c])*stats.t.pdf(rat,df_TT[c])*(df_TT[c]+rat**2)/(df_TT[c]-1)

ES_TRTS = pd.DataFrame(np.zeros([H_TRTS,10]),columns=VaR_TRTS.columns)
for i,c in enumerate(ES_TRTS.columns[:]):
    if dist_TRTS[i] == 'normal':
        alph = VaR_TRTS[c]/fc_TRTS[c]
        l = -stats.norm.pdf(alph)/stats.norm.cdf(alph)
        ES_TRTS[c] = fc_TRTS[c]*l     
    else:
        rat = VaR_TRTS[c]/fc_TRTS[c]
        ES_TRTS[c] = -fc_TRTS[c]/stats.t.cdf(rat,df_TRTS[c])*stats.t.pdf(rat,df_TRTS[c])*(df_TRTS[c]+rat**2)/(df_TRTS[c]-1)

ES_WSD = pd.DataFrame(np.zeros([H_WSD,10]),columns=VaR_WSD.columns)
for i,c in enumerate(ES_WSD.columns[:]):
    if dist_WSD[i] == 'normal':
        alph = VaR_WSD[c]/fc_WSD[c]
        l = -stats.norm.pdf(alph)/stats.norm.cdf(alph)
        ES_WSD[c] = fc_WSD[c]*l     
    else:
        rat = VaR_WSD[c]/fc_WSD[c]
        ES_WSD[c] = -fc_WSD[c]/stats.t.cdf(rat,df_WSD[c])*stats.t.pdf(rat,df_WSD[c])*(df_WSD[c]+rat**2)/(df_WSD[c]-1)

ES_DA = pd.DataFrame(np.zeros([H_DA,10]),columns=VaR_DA.columns)
for i,c in enumerate(ES_DA.columns[:]):
    if dist_DA[i] == 'normal':
        alph = VaR_DA[c]/fc_DA[c]
        l = -stats.norm.pdf(alph)/stats.norm.cdf(alph)
        ES_DA[c] = fc_DA[c]*l     
    else:
        rat = VaR_DA[c]/fc_DA[c]
        ES_DA[c] = -fc_DA[c]/stats.t.cdf(rat,df_DA[c])*stats.t.pdf(rat,df_DA[c])*(df_DA[c]+rat**2)/(df_DA[c]-1)

#########################################################################
### Backtest
# # Unconditional Backtest (counts the number of violations)
#@Christian Mücher, Financial Econometrics tutorials. Backtesting.Summer Semester 2022. University of Freiburg.
alpha_005=0.05
    
bt_005_CTS = pd.DataFrame(np.zeros([10,3]),index=VaR_CTS.columns,columns=["HIT","t","p"])
for c in bt_005_CTS.index:
    bt_005_CTS['HIT'][c] = np.sum(VaR_CTS[c]>dailyret_CTS[-H_CTS:])
    bt_005_CTS['t'][c] = (bt_005_CTS['HIT'][c] - H_CTS*alpha_005)/np.sqrt(H_CTS*alpha_005*(1-alpha_005))
    bt_005_CTS['p'][c]= 2*(1-stats.norm.cdf(np.abs(bt_005_CTS['t'][c])))
    
bt_005_BTS = pd.DataFrame(np.zeros([10,3]),index=VaR_BTS.columns,columns=["HIT","t","p"])
for c in bt_005_BTS.index:
    bt_005_BTS['HIT'][c] = np.sum(VaR_BTS[c]>dailyret_BTS[-H_BTS:])
    bt_005_BTS['t'][c] = (bt_005_BTS['HIT'][c] - H_BTS*alpha_005)/np.sqrt(H_BTS*alpha_005*(1-alpha_005))
    bt_005_BTS['p'][c]= 2*(1-stats.norm.cdf(np.abs(bt_005_BTS['t'][c])))
    
bt_005_TTS = pd.DataFrame(np.zeros([10,3]),index=VaR_TTS.columns,columns=["HIT","t","p"])
for c in bt_005_TTS.index:
    bt_005_TTS['HIT'][c] = np.sum(VaR_TTS[c]>dailyret_TTS[-H_TTS:])
    bt_005_TTS['t'][c] = (bt_005_TTS['HIT'][c] - H_TTS*alpha_005)/np.sqrt(H_TTS*alpha_005*(1-alpha_005))
    bt_005_TTS['p'][c]= 2*(1-stats.norm.cdf(np.abs(bt_005_TTS['t'][c])))
     
bt_005_TT = pd.DataFrame(np.zeros([10,3]),index=VaR_TT.columns,columns=["HIT","t","p"])
for c in bt_005_TT.index:
    bt_005_TT['HIT'][c] = np.sum(VaR_TT[c]>dailyret_TT[-H_TT:])
    bt_005_TT['t'][c] = (bt_005_TT['HIT'][c] - H_TT*alpha_005)/np.sqrt(H_TT*alpha_005*(1-alpha_005))
    bt_005_TT['p'][c]= 2*(1-stats.norm.cdf(np.abs(bt_005_TT['t'][c])))
         
bt_005_TRTS = pd.DataFrame(np.zeros([10,3]),index=VaR_TRTS.columns,columns=["HIT","t","p"])
for c in bt_005_TRTS.index:
    bt_005_TRTS['HIT'][c] = np.sum(VaR_TRTS[c]>dailyret_TRTS[-H_TRTS:])
    bt_005_TRTS['t'][c] = (bt_005_TRTS['HIT'][c] - H_TRTS*alpha_005)/np.sqrt(H_TRTS*alpha_005*(1-alpha_005))
    bt_005_TRTS['p'][c]= 2*(1-stats.norm.cdf(np.abs(bt_005_TRTS['t'][c])))
     
bt_005_WSD = pd.DataFrame(np.zeros([10,3]),index=VaR_WSD.columns,columns=["HIT","t","p"])
for c in bt_005_WSD.index:
    bt_005_WSD['HIT'][c] = np.sum(VaR_WSD[c]>dailyret_WSD[-H_WSD:])
    bt_005_WSD['t'][c] = (bt_005_WSD['HIT'][c] - H_WSD*alpha_005)/np.sqrt(H_WSD*alpha_005*(1-alpha_005))
    bt_005_WSD['p'][c]= 2*(1-stats.norm.cdf(np.abs(bt_005_WSD['t'][c])))
         
bt_005_DA = pd.DataFrame(np.zeros([10,3]),index=VaR_DA.columns,columns=["HIT","t","p"])
for c in bt_005_DA.index:
    bt_005_DA['HIT'][c] = np.sum(VaR_DA[c]>dailyret_DA[-H_DA:])
    bt_005_DA['t'][c] = (bt_005_DA['HIT'][c] - H_DA*alpha_005)/np.sqrt(H_DA*alpha_005*(1-alpha_005))
    bt_005_DA['p'][c]= 2*(1-stats.norm.cdf(np.abs(bt_005_DA['t'][c])))
 
with pd.ExcelWriter('Backtest 10sec_all.xlsx') as writer:  
    bt_005_CTS.to_excel(writer, sheet_name='005 CTS')
    bt_005_BTS.to_excel(writer, sheet_name='005 BTS')
    bt_005_TTS.to_excel(writer, sheet_name='005 TTS')
    bt_005_TT.to_excel(writer, sheet_name='005 TT')
    bt_005_TRTS.to_excel(writer, sheet_name='005 TRTS')
    bt_005_WSD.to_excel(writer, sheet_name='005 WSD')
    bt_005_DA.to_excel(writer, sheet_name='005 DA')
    
# Conditional Backtest
#@Christoffersen, P.F. (1998). Evaluating Interval Forecasts. International Economic Review , 39(4): 841-862
#Likelihood-ratio test
#tests for intertemporal dependence in the VaR exceendences
#Independence test
#POF=probability of failure
#CC: Conditional Coverage Test
LR_CTS = pd.DataFrame(np.zeros([3,len(VaR_CTS.columns)]),columns=VaR_CTS.columns,index=['Indep','POF','CC'])
LR_BTS = pd.DataFrame(np.zeros([3,len(VaR_BTS.columns)]),columns=VaR_BTS.columns,index=['Indep','POF','CC'])
LR_TTS = pd.DataFrame(np.zeros([3,len(VaR_TTS.columns)]),columns=VaR_TTS.columns,index=['Indep','POF','CC'])
LR_TT = pd.DataFrame(np.zeros([3,len(VaR_TT.columns)]),columns=VaR_TT.columns,index=['Indep','POF','CC'])
LR_TRTS = pd.DataFrame(np.zeros([3,len(VaR_TRTS.columns)]),columns=VaR_TRTS.columns,index=['Indep','POF','CC'])
LR_WSD = pd.DataFrame(np.zeros([3,len(VaR_WSD.columns)]),columns=VaR_WSD.columns,index=['Indep','POF','CC'])
LR_DA = pd.DataFrame(np.zeros([3,len(VaR_DA.columns)]),columns=VaR_DA.columns,index=['Indep','POF','CC'])

pval_CTS = LR_CTS.copy()
for c in VaR_CTS.columns:
    I = VaR_CTS[c].values > dailyret_CTS[-H_CTS:] #sequence of VaR exceedences
    CM = np.zeros([2,2]) #confusion matrix
    CM[0,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 0)) #we had no VaR exceedences today nor yesterday
    CM[0,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 0)) #we have VaR exceedence today but didnt have yesterday
    CM[1,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 1))
    CM[1,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 1))
    pi0 = CM[0,1]/(CM[0,0]+CM[0,1])
    pi1 = CM[1,1]/(CM[1,0]+CM[1,1])
    pi = (CM[0,1]+CM[1,1])/(CM.sum())
    aux1 = -2*np.log(((1-pi)**(CM[0,0]+CM[1,0])*pi**(CM[0,1]+CM[1,1]))
                      /((1-pi0)**(CM[0,0])*pi0**(CM[0,1])*(1-pi1)**(CM[1,0])*pi1**(CM[1,1])))
    LR_CTS[c]['Indep'] = aux1
    #we do the unconditional backtest, same as our t test
    x = I.sum()
    p = x/H_CTS
    aux2 = -2*np.log(((1-alpha)**(H_CTS-x)*alpha**(x))/((1-p)**(H_CTS-x)*p**(x)))
    LR_CTS[c]['UC'] = aux2#
    aux3 = aux1 + aux2
    LR_CTS[c]['CC'] =  aux3#
    LR_CTS[c] = np.vstack([aux1,aux2,aux3])
    pval_CTS[c] = np.vstack([1-stats.chi2.cdf(aux1,1),
                                1-stats.chi2.cdf(aux2,1),
                                1-stats.chi2.cdf(aux3,2)])

pval_BTS = LR_BTS.copy()
for c in VaR_BTS.columns:
    I = VaR_BTS[c].values > dailyret_BTS[-H_BTS:] #sequence of VaR exceedences
    CM = np.zeros([2,2]) #confusion matrix
    CM[0,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 0)) #we had no VaR exceedences today nor yesterday
    CM[0,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 0)) #we have VaR exceedence today but didnt have yesterday
    CM[1,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 1))
    CM[1,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 1))
    pi0 = CM[0,1]/(CM[0,0]+CM[0,1])
    pi1 = CM[1,1]/(CM[1,0]+CM[1,1])
    pi = (CM[0,1]+CM[1,1])/(CM.sum())
    aux1 = -2*np.log(((1-pi)**(CM[0,0]+CM[1,0])*pi**(CM[0,1]+CM[1,1]))
                      /((1-pi0)**(CM[0,0])*pi0**(CM[0,1])*(1-pi1)**(CM[1,0])*pi1**(CM[1,1])))
    LR_BTS[c]['Indep'] = aux1
    #we do the unconditional backtest, same as our t test
    x = I.sum()
    p = x/H_BTS
    aux2 = -2*np.log(((1-alpha)**(H_BTS-x)*alpha**(x))/((1-p)**(H_BTS-x)*p**(x)))
    LR_BTS[c]['UC'] = aux2#
    aux3 = aux1 + aux2
    LR_BTS[c]['CC'] =  aux3#
    LR_BTS[c] = np.vstack([aux1,aux2,aux3])
    pval_BTS[c] = np.vstack([1-stats.chi2.cdf(aux1,1),
                                1-stats.chi2.cdf(aux2,1),
                                1-stats.chi2.cdf(aux3,2)])

pval_TTS = LR_TTS.copy()
for c in VaR_TTS.columns:
    I = VaR_TTS[c].values > dailyret_TTS[-H_TTS:] #sequence of VaR exceedences
    CM = np.zeros([2,2]) #confusion matrix
    CM[0,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 0)) #we had no VaR exceedences today nor yesterday
    CM[0,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 0)) #we have VaR exceedence today but didnt have yesterday
    CM[1,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 1))
    CM[1,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 1))
    pi0 = CM[0,1]/(CM[0,0]+CM[0,1])
    pi1 = CM[1,1]/(CM[1,0]+CM[1,1])
    pi = (CM[0,1]+CM[1,1])/(CM.sum())
    aux1 = -2*np.log(((1-pi)**(CM[0,0]+CM[1,0])*pi**(CM[0,1]+CM[1,1]))
                      /((1-pi0)**(CM[0,0])*pi0**(CM[0,1])*(1-pi1)**(CM[1,0])*pi1**(CM[1,1])))
    LR_TTS[c]['Indep'] = aux1
    #we do the unconditional backtest, same as our t test
    x = I.sum()
    p = x/H_TTS
    aux2 = -2*np.log(((1-alpha)**(H_TTS-x)*alpha**(x))/((1-p)**(H_TTS-x)*p**(x)))
    LR_TTS[c]['UC'] = aux2#
    aux3 = aux1 + aux2
    LR_TTS[c]['CC'] =  aux3#
    LR_TTS[c] = np.vstack([aux1,aux2,aux3])
    pval_TTS[c] = np.vstack([1-stats.chi2.cdf(aux1,1),
                                1-stats.chi2.cdf(aux2,1),
                                1-stats.chi2.cdf(aux3,2)])
    
pval_TT = LR_TT.copy()
for c in VaR_TT.columns:
    I = VaR_TT[c].values > dailyret_TT[-H_TT:] #sequence of VaR exceedences
    CM = np.zeros([2,2]) #confusion matrix
    CM[0,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 0)) #we had no VaR exceedences today nor yesterday
    CM[0,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 0)) #we have VaR exceedence today but didnt have yesterday
    CM[1,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 1))
    CM[1,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 1))
    pi0 = CM[0,1]/(CM[0,0]+CM[0,1])
    pi1 = CM[1,1]/(CM[1,0]+CM[1,1])
    pi = (CM[0,1]+CM[1,1])/(CM.sum())
    aux1 = -2*np.log(((1-pi)**(CM[0,0]+CM[1,0])*pi**(CM[0,1]+CM[1,1]))
                      /((1-pi0)**(CM[0,0])*pi0**(CM[0,1])*(1-pi1)**(CM[1,0])*pi1**(CM[1,1])))
    LR_TT[c]['Indep'] = aux1
    #we do the unconditional backtest, same as our t test
    x = I.sum()
    p = x/H_TT
    aux2 = -2*np.log(((1-alpha)**(H_TT-x)*alpha**(x))/((1-p)**(H_TT-x)*p**(x)))
    LR_TT[c]['UC'] = aux2#
    aux3 = aux1 + aux2
    LR_TT[c]['CC'] =  aux3#
    LR_TT[c] = np.vstack([aux1,aux2,aux3])
    pval_TT[c] = np.vstack([1-stats.chi2.cdf(aux1,1),
                                1-stats.chi2.cdf(aux2,1),
                                1-stats.chi2.cdf(aux3,2)])

pval_TRTS = LR_TRTS.copy()
for c in VaR_TRTS.columns:
    I = VaR_TRTS[c].values > dailyret_TRTS[-H_TRTS:] #sequence of VaR exceedences
    CM = np.zeros([2,2]) #confusion matrix
    CM[0,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 0)) #we had no VaR exceedences today nor yesterday
    CM[0,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 0)) #we have VaR exceedence today but didnt have yesterday
    CM[1,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 1))
    CM[1,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 1))
    pi0 = CM[0,1]/(CM[0,0]+CM[0,1])
    pi1 = CM[1,1]/(CM[1,0]+CM[1,1])
    pi = (CM[0,1]+CM[1,1])/(CM.sum())
    aux1 = -2*np.log(((1-pi)**(CM[0,0]+CM[1,0])*pi**(CM[0,1]+CM[1,1]))
                      /((1-pi0)**(CM[0,0])*pi0**(CM[0,1])*(1-pi1)**(CM[1,0])*pi1**(CM[1,1])))
    LR_TRTS[c]['Indep'] = aux1
    #we do the unconditional backtest, same as our t test
    x = I.sum()
    p = x/H_TRTS
    aux2 = -2*np.log(((1-alpha)**(H_TRTS-x)*alpha**(x))/((1-p)**(H_TRTS-x)*p**(x)))
    LR_TRTS[c]['UC'] = aux2#
    aux3 = aux1 + aux2
    LR_TRTS[c]['CC'] =  aux3#
    LR_TRTS[c] = np.vstack([aux1,aux2,aux3])
    pval_TRTS[c] = np.vstack([1-stats.chi2.cdf(aux1,1),
                                1-stats.chi2.cdf(aux2,1),
                                1-stats.chi2.cdf(aux3,2)])

pval_WSD = LR_WSD.copy()
for c in VaR_WSD.columns:
    I = VaR_WSD[c].values > dailyret_WSD[-H_WSD:] #sequence of VaR exceedences
    CM = np.zeros([2,2]) #confusion matrix
    CM[0,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 0)) #we had no VaR exceedences today nor yesterday
    CM[0,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 0)) #we have VaR exceedence today but didnt have yesterday
    CM[1,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 1))
    CM[1,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 1))
    pi0 = CM[0,1]/(CM[0,0]+CM[0,1])
    pi1 = CM[1,1]/(CM[1,0]+CM[1,1])
    pi = (CM[0,1]+CM[1,1])/(CM.sum())
    aux1 = -2*np.log(((1-pi)**(CM[0,0]+CM[1,0])*pi**(CM[0,1]+CM[1,1]))
                      /((1-pi0)**(CM[0,0])*pi0**(CM[0,1])*(1-pi1)**(CM[1,0])*pi1**(CM[1,1])))
    LR_WSD[c]['Indep'] = aux1
    #we do the unconditional backtest, same as our t test
    x = I.sum()
    p = x/H_WSD
    aux2 = -2*np.log(((1-alpha)**(H_WSD-x)*alpha**(x))/((1-p)**(H_WSD-x)*p**(x)))
    LR_WSD[c]['UC'] = aux2#
    aux3 = aux1 + aux2
    LR_WSD[c]['CC'] =  aux3#
    LR_WSD[c] = np.vstack([aux1,aux2,aux3])
    pval_WSD[c] = np.vstack([1-stats.chi2.cdf(aux1,1),
                                1-stats.chi2.cdf(aux2,1),
                                1-stats.chi2.cdf(aux3,2)])
    
pval_DA = LR_DA.copy()
for c in VaR_DA.columns:
    I = VaR_DA[c].values > dailyret_DA[-H_DA:] #sequence of VaR exceedences
    CM = np.zeros([2,2]) #confusion matrix
    CM[0,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 0)) #we had no VaR exceedences today nor yesterday
    CM[0,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 0)) #we have VaR exceedence today but didnt have yesterday
    CM[1,0] = np.sum(np.logical_and(I[:-1] == 0,I[1:] == 1))
    CM[1,1] = np.sum(np.logical_and(I[:-1] == 1,I[1:] == 1))
    pi0 = CM[0,1]/(CM[0,0]+CM[0,1])
    pi1 = CM[1,1]/(CM[1,0]+CM[1,1])
    pi = (CM[0,1]+CM[1,1])/(CM.sum())
    aux1 = -2*np.log(((1-pi)**(CM[0,0]+CM[1,0])*pi**(CM[0,1]+CM[1,1]))
                      /((1-pi0)**(CM[0,0])*pi0**(CM[0,1])*(1-pi1)**(CM[1,0])*pi1**(CM[1,1])))
    LR_DA[c]['Indep'] = aux1
    #we do the unconditional backtest, same as our t test
    x = I.sum()
    p = x/H_DA
    aux2 = -2*np.log(((1-alpha)**(H_DA-x)*alpha**(x))/((1-p)**(H_DA-x)*p**(x)))
    LR_DA[c]['UC'] = aux2#
    aux3 = aux1 + aux2
    LR_DA[c]['CC'] =  aux3#
    LR_DA[c] = np.vstack([aux1,aux2,aux3])
    pval_DA[c] = np.vstack([1-stats.chi2.cdf(aux1,1),
                                1-stats.chi2.cdf(aux2,1),
                                1-stats.chi2.cdf(aux3,2)])

with pd.ExcelWriter('Conditional Backtest 10sec_all.xlsx') as writer:  
    pval_CTS.to_excel(writer, sheet_name='CTS')
    pval_BTS.to_excel(writer, sheet_name='BTS')
    pval_TTS.to_excel(writer, sheet_name='TTS')
    pval_TT.to_excel(writer, sheet_name='TT')
    pval_TRTS.to_excel(writer, sheet_name='TRTS')
    pval_WSD.to_excel(writer, sheet_name='WSD')
    pval_DA.to_excel(writer, sheet_name='DA')


####################plot##########################################x
#plot the VaR:
plt.plot(dailyret_CTS[-H_CTS:],lw=4)
plt.plot(VaR_CTS,lw=2)
plt.legend(VaR_CTS.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('VaR 10 sec CTS',fontsize=20)
plt.show()

#plot the ES:
plt.plot(dailyret_CTS[-H_CTS:],lw=4)
plt.plot(ES_CTS,lw=2)
plt.legend(ES_CTS.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('Expected Shortfall 10 sec CTS',fontsize=20)

#plot the VaR:
plt.plot(dailyret_BTS[-H_BTS:],lw=4)
plt.plot(VaR_BTS,lw=2)
plt.legend(VaR_BTS.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('VaR 10 sec BTS',fontsize=20)
plt.show()

#plot the ES:
plt.plot(dailyret_BTS[-H_BTS:],lw=4)
plt.plot(ES_BTS,lw=2)
plt.legend(ES_BTS.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('Expected Shortfall 10 sec BTS',fontsize=20)

#plot the VaR:
plt.plot(dailyret_TTS[-H_TTS:],lw=4)
plt.plot(VaR_TTS,lw=2)
plt.legend(VaR_TTS.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('VaR 10 sec TTS',fontsize=20)
plt.show()

#plot the ES:
plt.plot(dailyret_TTS[-H_TTS:],lw=4)
plt.plot(ES_TTS,lw=2)
plt.legend(ES_TTS.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('Expected Shortfall 10 sec TTS',fontsize=20)

#plot the VaR:
plt.plot(dailyret_TT[-H_TT:],lw=4)
plt.plot(VaR_TT,lw=2)
plt.legend(VaR_TT.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('VaR 10 sec TT',fontsize=20)
plt.show()

#plot the ES:
plt.plot(dailyret_TT[-H_TT:],lw=4)
plt.plot(ES_TT,lw=2)
plt.legend(ES_TT.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('Expected Shortfall 10 sec TT',fontsize=20)

#plot the VaR:
plt.plot(dailyret_TRTS[-H_TRTS:],lw=4)
plt.plot(VaR_TRTS,lw=2)
plt.legend(VaR_TRTS.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('VaR 10 sec TRTS',fontsize=20)
plt.show()

#plot the ES:
plt.plot(dailyret_TRTS[-H_TRTS:],lw=4)
plt.plot(ES_TRTS,lw=2)
plt.legend(ES_TRTS.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('Expected Shortfall 10 sec TRTS',fontsize=20)

#plot the VaR:
plt.plot(dailyret_WSD[-H_WSD:],lw=4)
plt.plot(VaR_WSD,lw=2)
plt.legend(VaR_WSD.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('VaR 10 sec WSD',fontsize=20)
plt.show()

#plot the ES:
plt.plot(dailyret_WSD[-H_WSD:],lw=4)
plt.plot(ES_WSD,lw=2)
plt.legend(ES_WSD.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('Expected Shortfall 10 sec WSD',fontsize=20)

#plot the VaR:
plt.plot(dailyret_DA[-H_DA:],lw=4)
plt.plot(VaR_DA,lw=2)
plt.legend(VaR_DA.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('VaR 10 sec DA',fontsize=20)
plt.show()

#plot the ES:
plt.plot(dailyret_DA[-H_DA:],lw=4)
plt.plot(ES_DA,lw=2)
plt.legend(ES_DA.columns.insert(0,'daily returns').values, fontsize = 10, bbox_to_anchor =(0.95, 0.7))
plt.title('Expected Shortfall 10 sec DA',fontsize=20)

toc = time.time()
print("Time Elapsed: ", toc - tic)