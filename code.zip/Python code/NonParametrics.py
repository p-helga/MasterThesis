#These helpfunctions were created for the Advanced Topics in Econometrics tutorials and made available by Christian Mücher in the Summer Semester 2022.
#I use this when estimating volatility signature plot with the Epanechnikov kernel with local linear estimation.

import numpy as np

import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
def is_invertible(A):
     return A.shape[0] == A.shape[1] and np.linalg.matrix_rank(A) == A.shape[0]
class NonParametrics:
    def __init__(self,Y,X):
        self.Y = Y
        self.X = X
    def Kernels(u,kernel='Gaussian'):
        I = np.abs(u)<1
        if kernel=='Uniform':
            K = I*1/2
        elif kernel == 'Epanechnikov':
            K = I*(0.75*(1-u**2))
        elif kernel == 'Biweight':
            K = I*(15/16*(1-u**2)**2)
        elif kernel == 'Triweight':
            K = I*(35/32*(1-u**2)**3)
        else:
            K = (2*np.pi)**(-1/2)*np.exp(-0.5*(u**2))
        # K[K<=1e-15] = 0
        K[K<0] = 0

        return(K)
    def roughness(kernel):
        if kernel=='Uniform':
            v2 = 1/2
        elif kernel == 'Epanechnikov':
            v2 = 3/5
        elif kernel == 'Biweight':
            v2 = 5/7
        elif kernel == 'Triweight':
            v2 = 350/429
        elif kernel == 'Gaussian':
            v2 = 1/(2*np.sqrt(np.pi))
        else:
            print('Error: Invalid Kernel')
        return(v2)

    def second_moment(kernel):
        if kernel=='Uniform':
            mu2 = 1/3
        elif kernel == 'Epanechnikov':
            mu2 = 1/5
        elif kernel == 'Biweight':
            mu2 = 1/7
        elif kernel == 'Triweight':
            mu2 = 1/9
        elif kernel == 'Gaussian':
            mu2 = 1
        else:
            print('Error: Invalid Kernel')
        return(mu2)
    
    def kde(sample,point,h,kernel='Gaussian'):
        u = (sample[np.newaxis] - point[np.newaxis].T)/h
        f = np.mean(1/h*NonParametrics.Kernels(u,kernel),axis=1)
        return(f)
    
    def WLS(Y,X,W):
        test = 'no'
        if X.ndim == 1:
            X = X[np.newaxis].T
            test = 'yes'
        a = X.T@W@X
        if X.ndim == 2 and is_invertible(a) == False and test =='no':
            a[1,1] = 1e-10
        b = X.T@W@Y
        return(np.linalg.inv(a)@b)

    class kds:
        def __init__(self,sample,h='Silverman',gridsize=None,kernel='Gaussian'
                     ,cut=0,alpha=None,plot=True):
            v2 = NonParametrics.roughness(kernel)
            mu2 = NonParametrics.second_moment(kernel)
            if h == 'Silverman':
                h = 1.364*(v2/(mu2**2))**(1/5)*\
                    (np.quantile(sample,0.75)-np.quantile(sample,0.25))*len(sample)**(-1/5)
            self.sample = sample
            self.h = h
            self.kernel = kernel
            self.cut = cut
            self.gridsize = gridsize
            a = NonParametrics.kds.estimate(self)
            self.f = a.f
            self.grid = a.grid
            self.var_f = v2*self.f/(self.gridsize*self.h)
            if plot==True:
                NonParametrics.kds.plot(self,alpha)
            
        def estimate(self):
            low = np.min(self.sample)-self.cut
            up = np.max(self.sample)+self.cut
            if self.gridsize == None:
                self.gridsize = len(self.sample)
            self.grid = np.linspace(low,up,self.gridsize)
            self.f = NonParametrics.kde(self.sample,self.grid,self.h,self.kernel)
            return(self)
    
        def plot(self,alpha=None):
            fig,ax = plt.subplots()
            ax.plot(self.grid,self.f)
            if alpha != None:
                ci = stats.norm.ppf(1-alpha/2)*np.sqrt(self.var_f)
                ax.fill_between(self.grid,self.f-ci,self.f+ci,color='grey', alpha=0.2)
            plt.show()    
            return(self)
    class Regression:
        def __init__ (self,Y,X):
            self.Y = Y
            self.X = X
            self.n = len(Y)
        def fit(self,method='local_linear',h=None,CV_grid=None,k=None,kernel='Epanechnikov'):
            self.method = method
            self.kernel = kernel
            if h ==None:
                h = self.n**(-1/5)
            if k ==None:
                k = int(np.floor(self.n**(4/5)))
            if self.method == 'knn':
                self.kernel = 'Uniform'
            if h == 'CV':
                if any(CV_grid == None):
                    print('please provide a grid of values for CV')
                else:
                    CV = np.zeros_like(CV_grid)
                    for j,h in enumerate(CV_grid):
                        cv = 0
                        for i in range(self.n):
                            Y_c = np.delete(self.Y,i)
                            X_c = np.delete(self.X,i)
                            bla = NonParametrics.Regression(Y_c,X_c)
                            bla.method = self.method
                            bla.h = h
                            bla.kernel = self.kernel
                            m_hat = bla.predict(self.X[i])[0]
                            cv += ((self.Y[i]-m_hat)**2)
                        CV[j] = cv/self.n
                    h = CV_grid[np.where(CV == CV.min())[0][0]]
            self.h,self.k = h,k
            self.m,self.m_prime = NonParametrics.Regression.predict(self,self.X)
            self.s2 = np.mean((self.Y-self.m)**2)
            self.V_m = NonParametrics.Regression.var(self,self.X)
            return(self)
        def weights(self,point):
            u = (self.X - point)/self.h
            K = (1/self.h)*NonParametrics.Kernels(u,self.kernel)
            return(np.diag(K))
        def predict(self,point):
            L = point.size
            if L == 1:
                point = np.array(point)[np.newaxis]
            m = np.zeros(L)
            m_prime = np.zeros(L)
            for i in range(L):
                if self.method=='knn':
                    Ind = np.argsort(np.abs(self.X - point[i]))
                    NN = self.X[Ind[:self.k]]
                    self.h = np.max(np.abs(point[i]-NN))*1.000001
                    if self.h == 0:
                        self.h = 1e-15
                W = NonParametrics.Regression.weights(self,point[i])
                if self.method == 'local_linear':
                    X1 = np.c_[np.ones(self.n),self.X-point[i]]
                    # W[W==0] = 1e-15
                else:
                    X1 = np.ones(self.n)
                theta = NonParametrics.WLS(self.Y,X1,W)
                m[i] = theta[0]
                m_prime[i]=np.nan
                if self.method == 'local_linear':
                    m_prime[i] = theta[1]
            return(m,m_prime)                    
        def var(self,points):
            self.v2 = NonParametrics.roughness(self.kernel)
            if self.method == 'knn':
                V_m = 2*self.s2*self.v2
            else:
                fhat = NonParametrics.kde(self.X,points,self.h,self.kernel)
                V = self.v2*self.s2/fhat
                V_m = V/(self.n*self.h)
            return(V_m)
        
        def my_regression(self,gridsize=100,cut=0,return_points=True):
            grid = np.linspace(np.min(self.X),np.max(self.X),gridsize)
            self.aux,self.aux_prime = NonParametrics.Regression.predict(self,grid)
            self.v_aux = NonParametrics.Regression.var(self,grid)
        #added so that I can plot more regressions in one plot
        
        def plot(self,gridsize=100,cut=0,return_points=True):
            grid = np.linspace(np.min(self.X),np.max(self.X),gridsize)
            aux,aux_prime = NonParametrics.Regression.predict(self,grid)
            v_aux = NonParametrics.Regression.var(self,grid)
            fig,ax = plt.subplots()
            ax.plot(self.X,self.Y,'o',alpha=0.5)
            ax.plot(grid,aux,'r-')
            ci = stats.norm.ppf(1-0.05/2)*np.sqrt(v_aux)
            ax.fill_between(grid, aux-ci, aux+ci,color='grey', alpha=0.2)
            if return_points==True:
                self.points_plt = aux
                self.grid = grid
                self.points_plt_der = aux_prime
                self.ci_plt = ci
                return(self)
            else:
                return()
            
            def plots(self,gridsize=100,cut=0,return_points=True):
                for i in range(0,3):
                    grid[i] = np.linspace(np.min(self[i].X),np.max(self[i].X),gridsize)
                    aux[i],aux_prime[i] = NonParametrics.Regression.predict(self[i],grid[i])
                    v_aux[i] = NonParametrics.Regression.var(self[i],grid[i])
                    fig,ax = plt.subplots()
                    ax.plot(self[i].X,self[i].Y,'o',alpha=0.5)
                    ax.plot(grid[i],aux[i],'r-')
                    ci[i] = stats.norm.ppf(1-0.05/2)*np.sqrt(v_aux[i])
                    ax.fill_between(grid[i], aux[i]-ci[i], aux[i]+ci[i],color='grey', alpha=0.2)
                    if return_points==True:
                        self[i].points_plt = aux[i]
                        self[i].grid = grid[i]
                        self[i].points_plt_der = aux_prime[i]
                        self[i].ci_plt = ci[i]
                        return(self[i])
                    else:
                        return()

