#These helpfunctions were created in the Financial Econometrics tutorials and made available by Christian Mücher in the Summer Semester 2022.
#I call these functions when analysing the price process and the rv series.
import numpy as np
from scipy import stats
from warnings import filterwarnings
from scipy.stats import t as tdist,norm,chi2
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf

def lr(x): 
    ret = np.log(x[1:])-np.log(x[0:-1])
    return(ret)
from scipy.optimize import minimize

def dstats(x):
    T = x.shape[0]
    mu = np.sum(x,axis = 0)/T
    std = np.sqrt(np.sum((x-mu)**2,axis=0)/T)
    y = (x-mu)/std
    skew = np.mean(y**3,axis=0)# np.sum(((x-mu)**3)/(std**3),axis=0)/T
    kurt = np.mean(y**4,axis = 0)
    out = np.array([mu,std,skew,kurt])
    return out


def JB_test(x):
    """
    Test for normality of the data
    """
    T = np.shape(x)[0]
    moments = dstats(x)
    t_JB = (T/6)*(moments[2]**2 + (moments[3]-3)**2/4)
    pv_JB = 1-stats.chi2.cdf(t_JB,2)
    
    return(np.array([t_JB,pv_JB]))


def norm_nll(theta,y,out=0):
    mu =theta[0]
    sigma2 = theta[1]
    T = y.shape[0]
    ll = -0.5*np.log(2*np.pi) - 0.5*np.log(sigma2)-((y-mu)**2)/(2*sigma2)
    if out == 1 :
        return -ll
    else:
        return np.sum(-ll)
    
    
def Grad(fun,par,**kwargs):
    '''
    Function that computes the Gradient of the specified function at the point
    specified par par. 
    Parameters
    ----------
    fun : function
        function to compute the Gradient for.
    par : array like
        point at which we want to compute the Gradient.
    **kwargs : Dictionary 
        Dictionary containing the inputs that function needs addiontal to the parameter values.

    Returns
    -------
    Numerical Gradient of fun at point par.

    '''
    f0 = fun(par,**kwargs)
    if np.size(f0) != 1:
        T = f0.shape[0]
    else:
        T = 1
    h = 0.0000001 
    k = par.shape[0]
    g = np.zeros([T,k])
    e = np.eye(k)
    for i in range(k):
        if par[i] >1 :
            f1 = fun(par*(np.ones(k)+e[:,i]*h),**kwargs)
            g[:,i] = (f1-f0)/(par[i]*h)
        else:
            f1 = fun(par + e[:,i]*h,**kwargs)
            g[:,i] = (f1-f0)/h
    return(g)
def Hess(fun,par,**kwargs):
    if np.size(par) != 1:
        k = len(par)
    else:
        k = 1
    h=0.00001
    
    H=np.zeros([k,k])
    e=np.eye(k)    
    h2=h/2;
    for ii in range(k):
        if par[ii]>100:
            x0P = par*(np.ones(k) +  e[:,ii]*h2);
            x0N = par*(np.ones(k) - e[:,ii]*h2);
            Deltaii = par[ii]*h;
        else:
            x0P = par +  e[:,ii] *h2;
            x0N = par -  e[:,ii] *h2;
            Deltaii = h;      
        for jj in range(ii+1):
            if par[jj]>100:
                x0PP = x0P * ( np.ones(k) +  e[:,jj] *h2 );
                x0PN = x0P * ( np.ones(k) -  e[:,jj] *h2 );
                x0NP = x0N * ( np.ones(k) +  e[:,jj] *h2 );
                x0NN = x0N * ( np.ones(k) -  e[:,jj] *h2 );
                Delta = Deltaii*par[jj]*h;
            else:
                x0PP = x0P  +  e[:,jj] *h2; 
                x0PN = x0P  -  e[:,jj] *h2; 
                x0NP = x0N  +  e[:,jj] *h2; 
                x0NN = x0N  -  e[:,jj] *h2; 
                Delta = Deltaii*h;
        
            fPP = fun(x0PP,**kwargs)
            fPN = fun(x0PN,**kwargs)
            fNP = fun(x0NP,**kwargs)
            fNN = fun(x0NN,**kwargs)
            
            H[ii,jj]=(np.sum(fPP)-np.sum(fPN)-np.sum(fNP)+np.sum(fNN))/Delta;
            H[jj,ii]=H[ii,jj];
    return(H)

def ols(x,y):
    x = np.asmatrix(x)
    y = np.asmatrix(y)
    if np.shape(x)[1] > np.shape(x)[0]:
        x = x.T
    if np.shape(y)[1] > np.shape(y)[0]:
        y = y.T
    n = np.shape(y)[0]
    k = np.shape(x)[1]
    a = np.linalg.inv(x.T*x)
    b = x.T*y
    bhat = np.reshape(a*b,(k,1))
    yhat = x*bhat
    ssr = (y-yhat).T*(y-yhat)
    s2 = float(ssr/(n-k))
    se = np.sqrt(np.diag(s2*a)).reshape((k,1))
    tstat = np.divide(bhat,se)
    p = 2*(1-tdist.cdf(np.abs(tstat),n-k))
    return(bhat,se,tstat,p,s2)





def ols_plus(X,Y,intercept=True,fname=False,varnames = False,out=True,disp=True):
    X = np.asmatrix(X)
    Y = np.asmatrix(Y)
    if np.shape(X)[1] > np.shape(X)[0]:
        X = X.transpose()
    if np.shape(Y) [1] > np.shape(Y)[0]:
        Y = Y.transpose()
    n = np.shape(X)[0]
    k = np.shape(X)[1]
    if intercept == True:
        X = np.hstack([np.ones([n,1]),X])
        k += 1
    a = np.linalg.inv(X.T*X)
    c = X.T*Y
    b = a*c
    Yhat = X*b
    SSR = np.asarray((Y-Yhat).T*(Y-Yhat)).reshape(1)
    s2 = float(SSR/(n-k))
    se = np.sqrt(np.diag(s2*a)).reshape((k,1))
    tstat = np.divide(b,se)
    p = 2*(1-tdist.cdf(np.abs(tstat),n-k))
    R2 = 1-np.divide(SSR,(Y-np.mean(Y)).T*(Y-np.mean(Y)))
    Ins = False
    if varnames == False:
        varnames = []
        for i in range((k-1)*(intercept)+ k*(1-intercept)):
            varnames.append('Var' + str(i+1))
        if intercept == True:
            varnames.insert(0,'Const')
    elif varnames != False and intercept == True:
        if len(varnames) == k-1:
            varnames.insert(0,'Const')
            Ins = True
    res = pd.DataFrame(np.hstack([b,se,tstat,p]),columns=['Coef','SE','t-stat','p-val'],
                       index=varnames)
    if Ins == True:
        varnames.pop(0)
    pd.options.display.float_format = '{:,.4f}'.format
    if disp== True:
        print(res)
        print('\n')
        print('Number of obs.: ' + str(n))
        print('R^2 = ' + "{:.4f}".format(float(R2)))
        print('SSR = ' + "{:.4f}".format(float(SSR)))
    if fname != False:
        f = open(fname,'w')
        print(res,file = f)
        print('\n',file=f)
        print('Number of obs.: ' + str(n),file = f)
        print('R^2 = ' + "{:.4f}".format(float(R2)),file = f)
        print('SSR = ' + "{:.4f}".format(float(s2*(n-k))),file = f)
        f.close()
    if out == True:
        OUT = {'Coef':b,'StdErr':se,'tstat':tstat,'pval':p,'sigma2':s2,'R2':R2,
               'fitted':Yhat,'resid':Y-Yhat}
        return(OUT)
    else:
        return(None)
  
SE = lambda x: np.sqrt(np.diag(x))

def spacf_plot(y,lags=30,title='Sample P_ACF Plot'):
    fig = plt.figure()
    ax = fig.add_subplot(2,1,1)
    plot_acf(y,lags=lags,ax = ax)
    ax = fig.add_subplot(2,1,2)
    plot_pacf(y,lags=lags,ax = ax)

def diff(y,d):
    y = list(y)
    x = []
    n = len(y)
    for t in range(n-d):
        x.append(y[t+d]-y[t])
    return(x)

def inv_list(l):
    i_list = []
    for i in l:
        i_list.append(-i)
    return(i_list)

class ARIMA:
    def __init__(self,order):
        self.p = order[0]
        self.d = order[1]
        self.q = order[2]
        
    def simulate(self,c,phi,theta,size,scale = 1,trend = 0,burnin = 500\
                     ,seed = None,dst='norm',df=4):
        """
        Takes inputs c,phi,d,theta and size and returns a series of data
        simulated from an ARIMA(p,d,q) process of length size. 
        Mandatory Inputs:
            c should be a float or integer
            phi should be a list of length p containing the AR parameters
            theta should be a list of length q containing the MA paramters
            d should be an integer specifying the order of integration
            size should be an integers specifying the number of observations that shall 
        be simulated
        optional inputs:
            scale specifies the scale of the error term distribution (default is 1)
            trend is the coefficient of a deterministic time trend included in the series
        the default is 0 (i.e. no determinist trend)
            burnin specifies the number of burnin periods. Default is 500
            seed sets the random number generator. Default is None.   
            dst can be either 'norm' for the normal distirbution or 't' for the 
        standard t distribution. When dist = 't', the default for the degrees of freedom is 4
            df change the degrees of freedom of t distributed errors. default is df = 4.
        """
        d = self.d
        m = False
        if type(phi) != list:
            print('phi needs to be a list with p elements')
            m = True
        if type(theta) != list:
            print('theta needs to be a list with q elements')
            m = True
        if type(c) != float and type(c) != int:
            print('c needs to be an integer or a float')
            m = True
        if type(d) != int:
            print('d needs to be an integer specifying the order of integration')
            m = True
        if m == True:
            return
        np.random.seed(seed)
        size = size+ burnin
        p = len(phi)
        q = len(theta)
        k = max(p,q)
        for i in range(k-p):
            phi.append(0)
        for i in range(k-q):
            theta.append(0)
        if dst == 't':
            e = np.random.standard_t(df = df,size=size+k)
        else:
            e = np.random.normal(size = size+k,scale =scale)    
        y = np.zeros(size+k)
        
        y[k] = c + np.sum(phi*y[k-1::-1]) + np.sum(theta*e[k-1::-1]) \
                + np.sum(trend*np.arange(0,k,1)) + e[k] 
        for i in range(k+1,size+k-1):
            y[i] = c + np.sum(phi*y[i-1:i-k-1:-1]) \
                + np.sum(theta*e[i-1:i-k-1:-1]) \
                + trend*i + e[i]
        y[-1] =  c + np.sum(phi*y[-2:-k-2:-1]) + np.sum(theta*e[-2:-k-2:-1]) \
                +trend*size + e[-1]         
        for i in range(d):
            y = np.cumsum(y)
        return(y[burnin+k:])
    
 
    def fit(self,Y,start = None,display = True):
        '''
        Parameters
        ----------
        Y : array like
            Contains the data the ARMA(p,q) model shall be applied to.
        order : tuple
            tuple containing p: the order of the AR part and q: the order of the 
            MA part
        start : dict, optional
            Can contain a dictionary specifying starting values in the form:
                {'c':val,'phi':val,'theta':val,'sigma2':val}. The default is None.
        display : bool, optional
            Whether to print the estimation results or not. The default is True.
    
        Returns
        -------
        OUT, a dictionary with the following keys:
        'Coef': array of the estimated parameters in the form [c,phi,theta,sigma2]
        'STD': standard errors estimated based on outer product of the Gradient
        'tstat':Values of a t-test for significance 
        'pval':p values of the estimated coefficients 
        'loglik':the log likelihood of the ARMA(p,q) model
        'Grad': The gradient of the likelihood at the estimated coeficients 
        'Fitted': The fitted values Yhat
        'resid': The model residuals.
        The function estimates an ARMA(p,q) model with constant by conditional 
        Maximum Likelihood. When q = 0, i.e. pure AR(p) model, estimation is done 
        by OLS
        
        When both p and q are zero, the constant and the variance are estimated
        by (unbiased) sample moments.
        
        Stationarity and Invertibility are given as non-linear inequality 
        constraints to the optimizer. 
    
        '''
        p = self.p
        q = self.q
        self.Y = Y
        if q == 0 and p != 0:
            Yb = np.append(np.zeros(p),Y)
            X = Yb[p-1:-1]
            for j in range(1,p):
                X = np.c_[X,Yb[p-j-1:-j-1]]
            names = ['c']
            for i in range(p):
                names.append('AR'+str(i+1))
            names.append('Sigma2')
            aux = ols_plus(X,Y,varnames=names[:-1],out = True,disp=display)
            s2 = aux['sigma2']
            self.coef = np.append(np.asarray(aux['Coef']).squeeze(),s2)    
            self.se = np.append(np.asarray(aux['StdErr']).squeeze(),(2*len(Y)*s2**2)/(len(Y)-p-1)**2)
            self.tstat = np.append(np.asarray(aux['tstat']).squeeze(),s2/self.se[-1])
            self.pval = np.append(np.asarray(aux['pval']).squeeze(),2*(1-tdist.cdf(np.abs(self.tstat[-1]),len(Y)-p-1)))
            
            self.ll = ARIMA.ARMA_loglik(self.coef,Y,p,q)
            self.Gradient = Grad(ARIMA.ARMA_loglik,self.coef,**{'Y':Y,'p':p,'q':q})
            self.const = self.coef[0]
            self.phi = self.coef[1:-1]
            self.theta = []
            self.sigma2 = self.coef[-1]
        elif p == 0 and q !=0:
            if start == None:
                c = 0
                theta = np.ones(q)/q-0.09
                sigma2 = np.var(Y)/10
            else:
                c = start['c']
                theta = start['theta']
                sigma2 = start['sigma2']
            par0 = np.array(c)
            par0 = np.append(par0,theta)
            par0 = np.append(par0,sigma2)
            con = {'type':'ineq','fun':ARIMA.MA_roots,'args':[q]}
            bounds = [(None,None)]
            for i in range(q):
                bounds.append((None,None))
            bounds.append((0.0001,None))
            bounds = tuple(bounds)
            res = minimize(ARIMA.ARMA_loglik,par0,args=(Y,p,q,True),\
                           bounds=bounds,constraints = con)
            
            self.coef = res.x
            self.ll = res.fun*(-1)
            self.Gradient = res.jac
            self.const = self.coef[0]
            self.theta = self.coef[1:-1]
            self.phi = []
            self.sigma2 = self.coef[-1]
            if res.success == False:
                print('Maximum Likelihood did not converge. Try to specify custom\
                      starting values.')
    
            g = Grad(ARIMA.ARMA_loglik,self.coef,**{'Y':Y,'p':p,'q':q,'OP':True})
            H = Hess(ARIMA.ARMA_loglik,self.coef,**{'Y':Y,'p':p,'q':q,'OP':True})
            cv = np.linalg.inv(H)*np.matmul(g.T,g)*np.linalg.inv(H)
            self.se =SE(cv)
            self.tstat = self.coef/self.se
            self.pval = 2*(1-norm.cdf(np.abs(self.tstat)))
            names = ['c']
            for i in range(q):
                names.append('MA'+str(i+1))    
            names.append('Sigma2')
       
        elif p == 0 and q == 0:
            b = np.mean(Y)
            s2 = np.var(Y)
            self.coef = np.hstack([b,s2])
            self.se = np.array([s2/len(Y),(2*len(Y)*s2**2)/(len(Y)-1)**2])
            self.tstat = b/self.se
            self.pval =  2*(1-tdist.cdf(np.abs(self.tstat),len(Y)-1))
            self.const = self.coef[0]
            self.phi = []
            self.theta = []
            self.sigma2 = self.coef[-1]           
            names = ['c','sigma2']
            self.ll = ARIMA.ARMA_loglik(self.coef,Y,p,q)
            self.Gradient = Grad(ARIMA.ARMA_loglik,self.coef,**{'Y':Y,'p':p,'q':q})
        else:
            if start == None:
                c = 0
                phi = np.ones(p)/p-0.09
                theta = np.ones(q)/q-0.09
                sigma2 = np.var(Y)/10
            else:
                c = start['c']
                phi = start['phi']
                theta = start['theta']
                sigma2 = start['sigma2']
            par0 = np.array(c)
            par0 = np.append(par0,phi)
            par0 = np.append(par0,theta)
            par0 = np.append(par0,sigma2)
            con = ({'type':'ineq','fun':ARIMA.AR_roots,'args':[p]},\
                   {'type':'ineq','fun':ARIMA.MA_roots,'args':[q]})
            bounds = [(None,None)]
            for i in range(p+q):
                bounds.append((None,None))
            bounds.append((0.0001,None))
            bounds = tuple(bounds)
            res = minimize(ARIMA.ARMA_loglik,par0,args=(Y,p,q,True),bounds=bounds\
                           ,constraints = con)
            self.coef = res.x
            self.const = self.coef[0]
            self.phi = self.coef[1:p+1]
            self.theta = self.coef[p+1:-1]
            self.sigma2 = self.coef[-1]
            self.ll = res.fun*(-1)
            self.Gradient = res.jac
            if res.success == False:
                print('Maximum Likelihood did not converge. Try to specify custom\
                      starting values.')
            g = Grad(ARIMA.ARMA_loglik,self.coef,**{'Y':Y,'p':p,'q':q,'OP':True})
            H = Hess(ARIMA.ARMA_loglik,self.coef,**{'Y':Y,'p':p,'q':q,'OP':True})
            cv = np.linalg.inv(H)*np.matmul(g.T,g)*np.linalg.inv(H)
            self.se =SE(cv)        
            self.tstat = self.coef/self.se
            self.pval = 2*(1-norm.cdf(np.abs(self.tstat)))
            names = ['c']
            for i in range(p):
                names.append('AR'+str(i+1))
            for i in range(q):
                names.append('MA'+str(i+1))
            names.append('Sigma2')           
        self.resid,self.fitted = ARIMA.ARMA_fit_res(self.coef,self.Y,self.p,self.q)
        self.names = names
        IC = InfoCrit(self.ll,len(self.coef),len(Y))
        self.aic = IC['AIC']
        self.bic = IC['BIC']
        self.hqic = IC['HQ']

        if display:
            print()
        return(self)    
    def summary(self):
        pd.options.display.float_format = '{:,.4f}'.format
        Out = pd.DataFrame(data = [self.coef,self.se,self.tstat,self.pval],columns = self.names,index = 
                               ['Coef','SE','T','P-val'])
        print(Out)
        return None
    def ARMA_fit_res(pars,Y,p,q):
        '''
    
        Parameters
        ----------
        pars : array like
            the parameters of an ARMA process [constant,phi,theta,sigma2].
        Y : array like
            Time series data the ARMA process is fitted on.
        p : int
            order of the AR part.
        q : int
            order of the MA parts
    
        Returns
        -------
        the residuals of fitting the ARMA process by cond. ML and the fitted values of Y
    
        '''
        c = pars[0]
        if p == 0:
            phi = 0
        else:
            phi = pars[1:p+1]
        if q == 0:
            theta = 0
        else:
            theta = pars[p+1:p+1+q]
        k = max(p,q)
        T = len(Y)
        Y0 = c/(1-np.sum(phi))*np.ones(k)
        e0 = np.zeros(k)
        Yt = np.append(Y0,Y)
        e = np.zeros(T)
        et = np.append(e0,e)
        et[k] = Y[k] - c-np.sum(phi*Y[k-p:k])-np.sum(theta*et[k-q:k])
        for t in range(k+1,T+k):
            et[t] = Yt[t]-c-np.sum(phi*Yt[t-1:t-p-1:-1]) - np.sum(theta*et[t-1:t-q-1:-1])
        e = et[k:]
        Y = Yt[k:]
        return(e,Y)
    
    def ARMA_loglik(pars,Y,p,q,neg = False,OP = False):
        '''
        This function takes a vector of paramter values, where the first value is 
        the constant of an ARMA process, the next p values are the AR coefficients 
        the next q values are the MA coefficients and the last value is the variance 
        coefficient
        further we can specify whether to return the negative log likelihood and 
        whether to return the gradient values at each point in time in order to compute 
        the VCOV Matrix by the outer product of the gradient. 
        '''
        filterwarnings("ignore","",RuntimeWarning)
        e,Yhat = ARIMA.ARMA_fit_res(pars,Y,p,q)
        sigma2 = pars[-1]
        ll = -1/2*np.log(2*np.pi)-1/2*np.log(sigma2) - (e**2)/(2*sigma2)
        filterwarnings("default","",RuntimeWarning)
        if OP == False:
            ll = np.sum(ll)
        if neg == True:
            ll = -ll
        return(ll)
    
    def AR_roots(par,p):
        # use the np.roots(par[0]**len(par0) + par[1]**(len(par0)-1) + ... par[-1]**1 = 0)
        z = np.abs(np.roots(np.hstack([-par[p+1:1:-1],1])))-0.9999999999
        return(z)
    def MA_roots(theta,q):
        z =np.abs(np.roots(np.hstack([theta[-2:-q-2:-1],1])))-0.99999999999
        return(z)
    
    # def AR_roots_nc(par,p):
    #     # use the np.roots(par[0]**len(par0) + par[1]**(len(par0)-1) + ... par[-1]**1 = 0)
    #     z = np.abs(np.roots(np.hstack([-par[-2::-1],1])))-0.9999999999
    #     return(z)
    
    
    def forecast(self,prob = 0.05):
        '''
    
        Parameters
        ----------
        Y : array like
            the data we use for the forecast.
        pars : array like
            estimated ARMA coefficients in the form [c,phi,theta,sigma2].
        order : tuple
            (p,q) specifying the orde of the AR and the MA parts.
        prob : float, optional
            1-prob gives the confidence interval. The default is 0.05.
    
        Returns
        -------
        pred : float
            contains the one step ahead prediction .
        ci : array
            1-prob CI for the forecast.
    
        '''
        pars = self.coef
        Y = self.Y
        
        c = pars[0]
        p = self.p
        q = self.q
        phi = pars[1:p+1]
        theta = pars[p+1:p+q+1]
        sigma2 = pars[-1]
        e,_ = ARIMA.ARMA_fit_res(pars,Y,p,q)
        ar = np.sum(phi*Y[-1:-p-1:-1])
        ma = np.sum(theta*e[-1:-q-1:-1])
        pred = c + ar + ma
        ci = pred + np.array([1,-1])*np.sqrt(sigma2)*norm.ppf(1-prob/2)
        return pred,ci 


def InfoCrit(ll,k,T):
    '''

    Parameters
    ----------
    ll : float
        Log Likelihood.
    k : int
        number of parameters.
    T : int
        number of observations.

    Returns
    -------
    Dictionary with Akaike, Bayesian-Schwarz and Hannan-Quinn Information 
    Criteria.

    '''
    c = -2*ll/T
    AIC = c + 2*k/T
    BIC = c + np.log(T)*k/T
    HQ = c + 2*k*np.log(np.log(T))/T
    return({'AIC':AIC,'BIC':BIC,'HQ':HQ})



def norm_ll(e,sigma2):
    ll = -1/2*np.log(2*np.pi)-1/2*np.log(sigma2) - e**2/(2*sigma2)
    return(ll)

def dmtest(f1,f2,true,test):
    T = len(f1)
    d = (f1-true)**2-(f2-true)**2 #using squared loss differential
    if test==1: # Sign test
        y = (2/np.sqrt(T))*(np.sum(d>0)-0.5*T)
        pv =2*(1- norm.cdf(np.abs(y)))
    elif test==2: # Diebold-Mariano test
        dbar = np.mean(d)
        vard = d.var()/T # if multi-step ahead forecast, the variance term is ugly
        y = dbar/np.sqrt(vard)
        pv =2*(1- norm.cdf(np.abs(y)))
    return np.array([y,pv])


def evalforecast(forecast,true,crit):
    if crit==1: #RMSPE
        y=np.sqrt(np.mean((forecast - true)**2,axis =0))
    elif crit==2: #MAPE
        y= np.mean(np.abs(forecast-true),axis = 0)
    elif crit==3: #MPE
        y=np.mean(forecast-true,axis = 0);
    return y
def aggret(x,freq,flat=True):
    T = x.shape[1]
    if freq=='daily':
        f = 1
    if freq == 'weekly':
        f = 5
    elif freq=='monthly':
        f =20 #monthly aggregation
    elif freq=='yearly':
        f = 250 #yearly aggregation 
    else:
        f2 = freq
    if type(freq) == str:
        x = np.reshape(np.sum(x,axis=0),T)
        l = int(np.floor(T/f))
        out = np.zeros(l)
        for i in range(l):
            out[i] = np.sum(x[i*f:(i+1)*f])
    else:
        l = int(np.floor(390/f2))
        out = np.zeros([l,T])
        for i in range(l):
            out[i,:] = np.sum(x[i*f2:(i+1)*f2,:],axis=0)
        if flat == True:
            out = np.reshape(out.T,[l*T])
    return out
