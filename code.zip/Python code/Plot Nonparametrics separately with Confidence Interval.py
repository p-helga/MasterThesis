
"""
This code was created to Plot the results of the nonparametrics estimation and the volatility signature plots.
The different sampling schemes are plotten in separate graphs together with their confidence intervals.
References:
-pandas:Data structures for statistical computing in python, McKinney, Proceedings of the 9th Python in Science Conference, Volume 445, 2010.
-numpy:Harris, C.R., Millman, K.J., van der Walt, S.J. et al. Array programming with NumPy. Nature 585, 357–362 (2020). DOI: 10.1038/s41586-020-2649-2. (Publisher link).
-seaborn:Waskom, M. L., (2021). seaborn: statistical data visualization. Journal of Open Source Software, 6(60), 3021, https://doi.org/10.21105/joss.03021
-fun2: Christian Mücher, Financial Econometrics tutorials and Advanced Topics in Econometrics tutorials. Summer Semester 2022. University of Freiburg.
-garches: Kevin Sheppard (2021, March 3). bashtage/arch: Release 4.18 (Version v4.18). Zenodo. https://doi.org/10.5281/zenodo.593254
-Matplotlib: A 2D Graphics Environment", Computing in Science & Engineering, vol. 9, no. 3, pp. 90-95, 2007.
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
sns.set(color_codes=True)
np.set_printoptions(precision = 4,suppress=True)
import time
tic = time.time()

data = pd.read_excel('Results_for_plot_all_schemes.xlsx', sheet_name=None)

#de-normalize values, multiply by std. and add the mean
freq = np.arange(1,1800,1)
m_freq,s_freq = freq.mean(),freq.std()
data2=pd.read_excel('Mean_and_Std.xlsx', sheet_name=None)

m_CTS, s_CTS=data2['Mean']['mean_CTS'].values , data2['Std']['std_CTS'].values
m_BTS, s_BTS=data2['Mean']['mean_BTS'].values , data2['Std']['std_BTS'].values
m_TTS, s_TTS=data2['Mean']['mean_TTS'].values , data2['Std']['std_TTS'].values
m_TT, s_TT=data2['Mean']['mean_TT'].values , data2['Std']['std_TT'].values
m_TRTS, s_TRTS=data2['Mean']['mean_TRTS'].values , data2['Std']['std_TRTS'].values
m_DA, s_DA=data2['Mean']['mean_DA'].values , data2['Std']['std_DA'].values
m_WSD, s_WSD=data2['Mean']['mean_WSD'].values , data2['Std']['std_WSD'].values

####################Confidence iv. results from the estimation
ci_CTS=3.00557e-07
ci_BTS=1.8698266776793085e-07
ci_TTS=2.911664476499286e-07
ci_TT=2.915791978941674e-07
ci_TRTS=2.9573440199212635e-07
ci_WSD=2.982361305589682e-07
ci_DA=2.915791978941674e-07

#CTS
fig, ax = plt.subplots()
ax.scatter((data['raw_CTS']['X']*s_freq)+m_freq,(data['raw_CTS']['Y']*s_CTS)+m_CTS, s=6, c='#ADD8E6')
ax.plot((data['estimate_CTS']['grid']*s_freq)+m_freq,(data['estimate_CTS']['aux']*s_CTS)+m_CTS)
ax.fill_between((data['estimate_CTS']['grid']*s_freq)+m_freq ,
                ((data['estimate_CTS']['aux']*s_CTS)+m_CTS-ci_CTS),
                ((data['estimate_CTS']['aux']*s_CTS)+m_CTS+ci_CTS),
                color='red', alpha=0.2)
plt.xlabel('k=frequency (1 second)',fontsize=15)
plt.ylabel('Average Realized Variance',fontsize=15)
plt.title('CTS: Volatility signature plot & Nonparametric Estimation',fontsize=20)
plt.show()

#BTS
fig, ax = plt.subplots()
ax.scatter((data['raw_BTS']['X']*s_freq)+m_freq,(data['raw_BTS']['Y']*s_BTS)+m_BTS, s=6, c='#FF4500')
ax.plot((data['estimate_BTS']['grid']*s_freq)+m_freq,(data['estimate_BTS']['aux']*s_BTS)+m_BTS)
ax.fill_between((data['estimate_BTS']['grid']*s_freq)+m_freq ,
                ((data['estimate_BTS']['aux']*s_BTS)+m_BTS-ci_BTS),
                ((data['estimate_BTS']['aux']*s_BTS)+m_BTS+ci_BTS),
                color='red', alpha=0.2)
plt.xlabel('k=frequency (1 second)',fontsize=15)
plt.ylabel('Average Realized Variance',fontsize=15)
plt.title('BTS: Volatility signature plot & Nonparametric Estimation',fontsize=20)
plt.show()

#TTS
fig, ax = plt.subplots()
ax.scatter((data['raw_TTS']['X']*s_freq)+m_freq,(data['raw_TTS']['Y']*s_TTS)+m_TTS, s=6, c='#90EE90')
ax.plot((data['estimate_TTS']['grid']*s_freq)+m_freq,(data['estimate_TTS']['aux']*s_TTS)+m_TTS)
ax.fill_between((data['estimate_TTS']['grid']*s_freq)+m_freq ,
                ((data['estimate_TTS']['aux']*s_TTS)+m_TTS-ci_TTS),
                ((data['estimate_TTS']['aux']*s_TTS)+m_TTS+ci_TTS),
                color='red', alpha=0.2)
plt.xlabel('k=frequency (1 second)',fontsize=15)
plt.ylabel('Average Realized Variance',fontsize=15)
plt.title('TTS: Volatility signature plot & Nonparametric Estimation',fontsize=20)
plt.show()

#TT
fig, ax = plt.subplots()
ax.scatter((data['raw_TT']['X']*s_freq)+m_freq,(data['raw_TT']['Y']*s_TT)+m_TT, s=6, c='#FF0000')
ax.plot((data['estimate_TT']['grid']*s_freq)+m_freq,(data['estimate_TT']['aux']*s_TT)+m_TT)
ax.fill_between((data['estimate_TT']['grid']*s_freq)+m_freq ,
                ((data['estimate_TT']['aux']*s_TT)+m_TT-ci_TT),
                ((data['estimate_TT']['aux']*s_TT)+m_TT+ci_TT),
                color='red', alpha=0.2)
plt.xlabel('k=frequency (1 second)',fontsize=15)
plt.ylabel('Average Realized Variance',fontsize=15)
plt.title('TT: Volatility signature plot & Nonparametric Estimation',fontsize=20)
plt.show()

#TRTS
fig, ax = plt.subplots()
ax.scatter((data['raw_TRTS']['X']*s_freq)+m_freq,(data['raw_TRTS']['Y']*s_TRTS)+m_TRTS, s=6, c='#9370DB')
ax.plot((data['estimate_TRTS']['grid']*s_freq)+m_freq,(data['estimate_TRTS']['aux']*s_TRTS)+m_TRTS)
ax.fill_between((data['estimate_TRTS']['grid']*s_freq)+m_freq ,
                ((data['estimate_TRTS']['aux']*s_TRTS)+m_TRTS-ci_TRTS),
                ((data['estimate_TRTS']['aux']*s_TRTS)+m_TRTS+ci_TRTS),
                color='red', alpha=0.2)
plt.xlabel('k=frequency (1 second)',fontsize=15)
plt.ylabel('Average Realized Variance',fontsize=15)
plt.title('TRTS: Volatility signature plot & Nonparametric Estimation',fontsize=20)
plt.show()

#WSD
fig, ax = plt.subplots()
ax.scatter((data['raw_WSD']['X']*s_freq)+m_freq,(data['raw_WSD']['Y']*s_WSD)+m_WSD, s=6, c='#FFB6C1')
ax.plot((data['estimate_WSD']['grid']*s_freq)+m_freq,(data['estimate_WSD']['aux']*s_WSD)+m_WSD)
ax.fill_between((data['estimate_WSD']['grid']*s_freq)+m_freq ,
                ((data['estimate_WSD']['aux']*s_WSD)+m_WSD-ci_WSD),
                ((data['estimate_WSD']['aux']*s_WSD)+m_WSD+ci_WSD),
                color='red', alpha=0.2)
plt.xlabel('k=frequency (1 second)',fontsize=15)
plt.ylabel('Average Realized Variance',fontsize=15)
plt.title('WSD: Volatility signature plot & Nonparametric Estimation',fontsize=20)
plt.show()

#DA
fig, ax = plt.subplots()
ax.scatter((data['raw_DA']['X']*s_freq)+m_freq,(data['raw_DA']['Y']*s_DA)+m_DA, s=6, c='#CD853F')
ax.plot((data['estimate_DA']['grid']*s_freq)+m_freq,(data['estimate_DA']['aux']*s_DA)+m_DA)
ax.fill_between((data['estimate_DA']['grid']*s_freq)+m_freq ,
                ((data['estimate_DA']['aux']*s_DA)+m_DA-ci_DA),
                ((data['estimate_DA']['aux']*s_DA)+m_DA+ci_DA),
                color='red', alpha=0.2)
plt.xlabel('k=frequency (1 second)',fontsize=15)
plt.ylabel('Average Realized Variance',fontsize=15)
plt.title('DA: Volatility signature plot & Nonparametric Estimation',fontsize=20)
plt.show()

