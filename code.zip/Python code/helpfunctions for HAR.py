# Author: Kevin Sheppard
# kevin.sheppard@economics.ox.ac.uk
# Revision: 5    Date: 12/1/2005

import numpy as np



###################################################################################################
################################################################################################### 
def newlagmatrix(x, nlags, *options):
# Construction of a matrix of lags (X) and a vector (Y) for use in an autoregression  
# USAGE:
#     [Y,X]=newlagmatrix(X,NLAGS,C)
#
# INPUTS:
#     X     - The dependant variable(Tx1)
#     NLAGS - The number of lags(scalar)
#     C     - [OPTIONAL] 1 if you want to include a constant; 0 is default
#
# OUTPUTS:
#     Y     - (n-p) by 1 vector of contemporaneous values
#     X     - (n-p) by p (or p+1 if c=1) matrix of lags and possibly constant.  The
#               matrix is of the form [constant(if included) t-1 t-2 ... t-p]
#
# COMMENTS:
#     Original name, 'lagmatrix' conflicts with a Matlab file, so newlagmatrix
#     replaces original 

# Author: Kevin Sheppard
# kevin.sheppard@economics.ox.ac.uk
# Revision: 5    Date: 12/1/2005

##############################
##Input Checking
#############################
    options = list(options)
    
    if len(options) == 0:
        c = 0
    elif len(options) == 1:
        c = options[0]
    else:
        return print('newlagmatrix requires either 2 or 3 arguments.')    
    if (len(np.shape(x)) > 1 and np.shape(x)[1] >1) or len(np.shape(x)) == 0 or len(x) ==1:
        return print ('x series must be a column vector.')
    elif len(x) <1:
        return print('x is empty.')
    else:
        if c !=1 and c!=0:
            return print('c should be 1 or 0')
        else:
            if len(np.shape(nlags)) > 1 or np.size(nlags) != 1 or nlags < 0 or np.floor(nlags) != nlags:
                return print('nlags should be non-negative integer.')
    
##############################
##Input Checking End
#############################   
    T = np.size(x,0)
    if nlags > 0:
        nlags +=1
        newX = np.concatenate((x,np.zeros((nlags,1),dtype = int))) 
        lagmatrix = np.tile(newX,(nlags,1)) #repeat the newX array by nlags times
        lagmatrix = np.reshape(lagmatrix[:-nlags], (T+nlags-1, nlags), order='F')
        lagmatrix = lagmatrix[nlags-1:T]
        y = lagmatrix[:,0]
        x = lagmatrix[:,1:]
        if c ==1:
            x = np.c_[np.ones(len(x), dtype = int),x]
    else:
        if c == 1:
            y = x
            x = np.ones(T, dtype = int)
        else:
            y = x
            x = []
    return y,x
###################################################################################################
###################################################################################################


###################################################################################################
###################################################################################################
def covnw(data,*options):        
# Long-run covariance estimation using Newey-West (Bartlett) weights 
    
# USAGE:
#   [V] = covnw(DATA)
#   [V] = covnw(DATA,NLAG,DEMEAN)
#
# INPUTS:
#   DATA   - T by K vector of dependent data
#   NLAG   - Non-negative integer containing the lag length to use.  If empty or not included,
#              NLAG=min(floor(1.2*T^(1/3)),T) is used 
#   DEMEAN - Logical true or false (0 or 1) indicating whether the mean should be subtracted when
#              computing the covariance 

# OUTPUTS:
#   V      - A K by K covariance matrix estimated using Newey-West (Bartlett) weights
#   
# COMMENTS:
#
# EXAMPLES:
#   Simulate an AR(1)
#       y = armaxfilter_simulate(1000,0,1,.9);
#   Newey-West covariance with automatic BW selection
#       lrcov = covnw(y)
#   Newey-West covariance with 10 lags
#       lrcov = covnw(y, 10)
#   Newey-West covariance with 10 lags and no demeaning
#       lrcov = covnw(y, 10, 0)
#
# See also COVVAR
 
# Copyright: Kevin Sheppard
# kevin.sheppard@economics.ox.ac.uk
# Revision: 3    Date: 5/1/2007
 
##############################
##Input Checking
#############################
    options = list(options)
    
    T =len(data)
    if len(options) == 0:
        nlag = min(np.floor(1.2 * T**(1/3)), T)
        demean = True
    elif len(options) == 1:
        nlag = options[0]
        demean = True
    else:
        nlag= options[0]
        demean = options[1]
    if len(np.shape(data)) == 1:
        data = np.reshape(data, (len(data), 1), order='F') #reshape data size to (T,1) instead of (T,) pattern
        
    if nlag == None:
        nlag = min(np.floor(1.2 * T**(1/3)), T)
    if demean == None:
        demean = True
        
    if demean != True and demean != False:
        return print('DEMEAN must be either logical true or false.')
    if len(np.shape(nlag)) > 1 or np.size(nlag) != 1 or nlag < 0 or np.floor(nlag) != nlag:
        return print('nlag should be non-negative integer.')
    if np.ndim(data) > 2:
        return print('DATA must be a T by K matrix of data.')
    
##############################
##Input Checking End
#############################   
        
    if demean:
        data = data - np.tile(np.mean(data),T)
    w = (nlag + 1 - np.array(range(nlag+1)))/(nlag + 1)
    data.reshape
    V = np.dot(np.transpose(data),data)/T
    for i in range(nlag):
        Gammai = np.matmul(np.transpose(data[i+1:]), data[0:T-i-1])/T
        GplusGprime = Gammai + np.transpose(Gammai)
        V = V + w[i+1] * GplusGprime
    return V
###################################################################################################
###################################################################################################        
   
   
###################################################################################################
###################################################################################################
def aicsbic(errors,constant,p, *options):
#Computes the Akaike and Schwartz/Bayes Information Criteria for an ARMA(P,Q) as parameterized in
# ARMAXFILTER 
#
# USAGE:
#   [AIC] = aicsbic(ERRORS,CONSTANT,P,Q)
#   [AIC,SBIC] = aicsbic(ERRORS,CONSTANT,P,Q,X)
# 
# INPUTS:
#   ERRORS   - A T by 1 length vector of errors from the regression
#   CONSTANT - Scalar variable: 1 to include a constant, 0 to exclude
#   P        - Non-negative integer vector representing the AR orders to include in the model.
#   Q        - Non-negative integer vector representing the MA orders to include in the model.
#   X        - [OPTIONAL]  a T by K  matrix of exogenous variables.
# 
# OUTPUTS:
#   AIC       - The Akaike Information Criteria 
#   SBIC      - The Schwartz/Bayes Information Criteria
# 
# COMMENTS:
#   This is a helper for ARMAXFILTER and uses the same inputs, CONSTANT, P, Q and X.  ERRORS should
#   be the errors returned from a call to ARMAXFILTER with the same values of P, Q, etc. 
#
# EXAMPLES:
#   Compute AIC and SBIC from an ARMA
#       [parameters, LL, errors] = armaxfilter(y, constant, p, q);
#       [aic,sbic] = aicsbic(errors,constant,p,q)
# 
#  See also ARMAXFILTER, HETEROGENEOUSAR

# Copyright: Kevin Sheppard
# kevin.sheppard@economics.ox.ac.uk
# Revision: 3    Date: 10/19/2009

##############################
##Input Checking
#############################
    options = list(options)
    
    if len(options) == 0:
        q = []
        X =[]
        
    elif len(options) == 1:
        q = options[0]
        X = []
    else:
        q= options[0]
        X = options[1]
    
    #####reshape inputs#####
    # reshape input size to (T,1) instead of (T,) pattern
    if len(np.shape(errors)) == 1 and errors !=[]:
        errors = np.reshape(errors, (len(errors), 1), order='F')
    if len(np.shape(p)) == 1 and p !=[]:
        p = np.reshape(p, (len(p), 1), order='F')
    if len(np.shape(q)) == 1 and q !=[]:
        q = np.reshape(q, (len(q), 1), order='F')
    if len(np.shape(X)) == 1 and X !=[]:
        X = np.reshape(X, (len(X), 1), order='F')
        
    #####Check for errors#####
    if (len(np.shape(errors)) > 1 and np.shape(errors)[1] > 1) or len(errors) == 1:
        return print ('ERRORS must be a column vector.')
    elif len(errors) < 1:
        return print ('ERRORS is empty.')
    
    #####Check for P#####
    if len(np.shape(p)) == 0 and p != []: #if p is not an array
        if p < 0 or np.floor(p) != p:
            return print('P must contain only positive integers.')
        elif p >= (len(errors) - p):
            return print('Too many lags in the AR.  max(P) < T/2')
        elif p == 0 or p == None:
            p = []
        else:
            p = [p]
    elif q != []:
        if np.shape(p)[1] > 1:
            if np.shape(p)[0] == 1:
                p = np.transpose(p)
            else:
                return print ('P must be a column vector of included lags')
            
        nonint = [i for i in p if i != np.floor(i)] #select out noninteger elements
        if min(p) < 0 or len(nonint) > 0:
            return print('P must contain only positive integers.')
        if max(p) >= (len(errors) -max(p)):
            return print('Too many lags in the AR.  max(P) < T/2')
        if len(np.unique(p, axis=0)) != len(p):
            return print('P must contain at most one of each lag')
        if np.size(p,0) == 1 and p[0] == 0:
            p = []

    
    
    #####Check for Q#####
    if len(np.shape(q)) == 0 and q !=[]: #if p is integer not an array
        if q < 0 or np.floor(q) != q:
            return print('P must contain only positive integers.')
        elif q >= len(errors):
            return print('Too many lags in the AR.  max(Q) < T')
        elif q == 0:
            q = []
        else:
            q = [q]
    elif q != []:
        if np.shape(q)[1] > 1:
            if np.shape(q)[0] == 1:
                q = np.transpose(q)
            else:
                return print ('Q must be a column vector of included lags')
        nonint = [i for i in q if i != np.floor(i)] #select out noninteger elements
        if min(q) < 0 or len(nonint) > 0:
            return print('Q must contain only positive integers.')
        if max(q) >= len(errors):
            return print('Too many lags in the AR.  max(Q) < T')
        if len(np.unique(q, axis=0)) != len(q):
            return print('Q must contain at most one of each lag')
        if np.size(q,0) == 1 and q[0] == 0:
            q = []
        
                     
##############################
##Input Checking End
#############################  
    T = len(errors)
    seregression = (sum(errors*errors)/T)**0.5
    lp = len(p)
    lq = len(q)
    if len(X) <1:
        lx = 0
    else:
        lx = np.size(X,1)
    K = constant + lp + lq + lx
    aic = np.log(seregression**2) + 2 * K / T
    sbic = np.log(seregression**2) + np.log(T) * K / T
    
    return aic, sbic
###################################################################################################
###################################################################################################
    

###################################################################################################
###################################################################################################


def armaroots(parameters, constant, p, q, *options):
# Computes the roots of the characteristic equation of an ARMAX(P,Q) as parameterized by ARMAXFILTER
#
# USAGE:
#   [ARROOTS,ABSARROOTS] = armaroots(PARAMETERS,CONSTANT,P,Q)
#   [ARROOTS,ABSARROOTS] = armaroots(PARAMETERS,CONSTANT,P,Q,X)
# 
# INPUTS:
#   PARAMETERS - A CONSTANT+length(P)+length(Q)+size(X,2) by 1 vector of parameters, usually an
#                  output from ARMAXFILTER 
#   CONSTANT   - Scalar variable: 1 to include a constant, 0 to exclude#   P          - Non-negative integer vector representing the AR orders to include in the model.
#   Q          - Non-negative integer vector representing the MA orders to include in the model.
#   X          - [OPTIONAL] A T by K matrix of exogenous variables. 
#
# OUTPUTS:
#   ARROOTS     - A max(P) by 1 vector containing the roots of the characteristic equation
#                   corresponding to the ARMA model input 
#   ABSARROOTS  - Absolute value or complex modulus of the autoregressive roots
# 
# COMMENTS:
#
# EXAMPLES:
#   Compute the AR roots of an ARMA(2,2)
#       phi = [1.3 -.35]; theta = [.4 .3]; parameters=[1 phi theta]'; 
#       [arroots, absarroots] = armaroots(parameters, 1, [1 2], [1 2])
#   Compute the AR roots of an irregular AR(3)
#       phi = [1.3 -.35]; parameters = [1 phi]';                    
#       [arroots, absarroots] = armaroots(parameters, 1, [1 3],[])  ## See also ARMAXFILTER, ROOTS
 
# Copyright: Kevin Sheppard
# kevin.sheppard@economics.ox.ac.uk
# Revision: 3    Date: 1/1/2007

##############################
##Input Checking
#############################
    options = list(options)
    
    if len(options) == 0:
        X =[]
    else:
        X = options[0]
    
    #####reshape inputs#####
    # reshape input size to (T,1) instead of (T,) pattern
    if len(np.shape(parameters)) == 1 and parameters !=[]:
        parameters = np.reshape(parameters, (len(parameters), 1), order='F')
    if len(np.shape(p)) == 1 and p !=[]:
        p = np.reshape(p, (len(p), 1), order='F')
    if len(np.shape(q)) == 1 and q !=[]:
        q = np.reshape(q, (len(q), 1), order='F')
    if len(np.shape(X)) == 1 and X !=[]:
        X = np.reshape(X, (len(X), 1), order='F')
    
    #####Check for P#####
    if len(np.shape(p)) == 0 and p!= []: #if p is not array
        if p < 0 or np.floor(p) != p:
            return print('P must contain only positive integers.')
        elif p == 0 or p == None:
            p = []
        else:
            p = [p]
    elif p != []:
        if np.shape(p)[1] > 1:
            if np.shape(p)[0] == 1:
                p = np.transpose(p)
            else:
                return print ('P must be a column vector of included lags')
        nonint = [i for i in p if i != np.floor(i)] #select out noninteger elements
        if min(p) < 0 or len(nonint) > 0:
            return print('P must contain only positive integers.')
        if len(np.unique(p, axis=0)) != len(p):
            return print('P must contain at most one of each lag')
        if np.size(p,0) == 1 and p[0] == 0:
            p = []
    lp = len(p)

    
    
    #####Check for Q#####
    if len(np.shape(q)) == 0 and q !=[]: #if p is not an array
        if q < 0 or np.floor(q) != q:
            return print('Q must contain only positive integers.')
        elif q == 0 or q == None:
            q = []
        else:
            q = [q]
    elif q != []:
        if np.shape(q)[1] > 1:
            if np.shape(q)[0] == 1:
                q = np.transpose(q)
            else:
                return print ('Q must be a column vector of included lags')
        nonint = [i for i in q if i != np.floor(i)] #select out noninteger elements
        if min(q) < 0 or len(nonint) > 0:
            return print('Q must contain only positive integers.')
        if len(np.unique(q, axis=0)) != len(q):
            return print('Q must contain at most one of each lag')
        if np.size(q,0) == 1 and q[0] == 0:
            q = []
    lq = len(q)
    
    #####Check for Constant#####
    if constant !=0 and constant != 1:
        return print('CONSTANT must be 0 or 1')
    
    #####Check for Parameters#####
    if np.shape(parameters)[1] > 1:
        if np.shape(parameters)[0] == 1:
            parameters = np.transpose(parameters)
        else:
            return print ('PARAMETERS must be a column vector')
    if len(np.shape(parameters)) == 0 and parameters != []: #input is an interger
        lparam = 1
    else:
        lparam = len(parameters) #integer has no function of length
    if len(np.shape(X)) == 0 or X==[]:
        lx = 0
    else:
        lx = np.size(X,1)
    if lparam != lp + lq + lx + constant:
        return print('PARAMETERS must have length compatible with P, Q, CONSTANT and X')
##############################
##Input Checking End
#############################
    if lp == 0:
        arroots = []
        absarroots = []
    else:
        if constant:
            arparameters = parameters[1:lp+1,:]
        else:
            arparameters = parameters[0:lp,:]
        
        formatted_arparameters = np.zeros((1,lp))
        formatted_arparameters[:,0:lp] = np.transpose(arparameters)
        formatted_arparameters = np.reshape(np.c_[1, -formatted_arparameters],(np.size(formatted_arparameters)+1,)) #combine 1 then transfer rank2 array to rank1 array
    arroots = np.roots(formatted_arparameters)
    absarroots=abs(arroots)
    
    return arroots, absarroots


