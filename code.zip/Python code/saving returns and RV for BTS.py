
"""

This code was prepared for calculating and saving the daily returns and RV from different frequencies in BTS so it can be referenced to later without always calculating
the values.
References:
-pandas:Data structures for statistical computing in python, McKinney, Proceedings of the 9th Python in Science Conference, Volume 445, 2010.
-numpy:Harris, C.R., Millman, K.J., van der Walt, S.J. et al. Array programming with NumPy. Nature 585, 357–362 (2020). DOI: 10.1038/s41586-020-2649-2. (Publisher link).
-seaborn:Waskom, M. L., (2021). seaborn: statistical data visualization. Journal of Open Source Software, 6(60), 3021, https://doi.org/10.21105/joss.03021
-fun2: Christian Mücher, Financial Econometrics tutorials and Advanced Topics in Econometrics tutorials. Summer Semester 2022. University of Freiburg.
-garches: Kevin Sheppard (2021, March 3). bashtage/arch: Release 4.18 (Version v4.18). Zenodo. https://doi.org/10.5281/zenodo.593254
-Matplotlib: A 2D Graphics Environment", Computing in Science & Engineering, vol. 9, no. 3, pp. 90-95, 2007.
"""
import numpy as np
import pandas as pd
np.set_printoptions(precision = 4,suppress=True)
import statsmodels
import scipy.stats as stats

#1 second
data_BTS=pd.read_csv('bts_1sec.csv', sep=',' , header = None)
data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:23401].values
price_BTS = data_BTS[data_BTS.columns[2]].values

#intraday log returns per day
P_BTS = np.zeros([23401,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*23401:(i+1)*23401]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)

RV_BTS_1s=pd.DataFrame(np.sum(intraday_returns_BTS**2,axis=0))
with pd.ExcelWriter('RV BTS 1second.xlsx') as writer:  
    RV_BTS_1s.to_excel(writer, sheet_name='Realized Variances')

dailyret_BTS_1s=np.sum(intraday_returns_BTS,axis=0)
with pd.ExcelWriter('dailyret BTS 1second.xlsx') as writer:  
    RV_BTS_1s.to_excel(writer, sheet_name='Daily Returns')
    
#10 second
data_BTS=pd.read_csv('bts_10sec.csv', sep=',' , header = None)
data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:2341].values
price_BTS = data_BTS[data_BTS.columns[2]].values

#intraday log returns per day
P_BTS = np.zeros([2341,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*2341:(i+1)*2341]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)

RV_BTS_10s=pd.DataFrame(np.sum(intraday_returns_BTS**2,axis=0))
with pd.ExcelWriter('RV BTS 10seconds.xlsx') as writer:  
    RV_BTS_1s.to_excel(writer, sheet_name='Realized Variances')

dailyret_BTS_10s=np.sum(intraday_returns_BTS,axis=0)
with pd.ExcelWriter('dailyret BTS 10seconds.xlsx') as writer:  
    RV_BTS_10s.to_excel(writer, sheet_name='Daily Returns')

#1 minute
data_BTS=pd.read_csv('bts_1min.csv', sep=',' , header = None)
data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:391].values
price_BTS = data_BTS[data_BTS.columns[2]].values

#intraday log returns per day
P_BTS = np.zeros([391,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*391:(i+1)*391]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)

RV_BTS_1m=pd.DataFrame(np.sum(intraday_returns_BTS**2,axis=0))
with pd.ExcelWriter('RV BTS 1minute.xlsx') as writer:  
    RV_BTS_1m.to_excel(writer, sheet_name='Realized Variances')

dailyret_BTS_1m=np.sum(intraday_returns_BTS,axis=0)
with pd.ExcelWriter('dailyret BTS 1minute.xlsx') as writer:  
    RV_BTS_1m.to_excel(writer, sheet_name='Daily Returns')
    
#3 minutes
data_BTS=pd.read_csv('bts_3min.csv', sep=',' , header = None)
data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:131].values
price_BTS = data_BTS[data_BTS.columns[2]].values

#intraday log returns per day
P_BTS = np.zeros([131,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*131:(i+1)*131]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)

RV_BTS_3m=pd.DataFrame(np.sum(intraday_returns_BTS**2,axis=0))
with pd.ExcelWriter('RV BTS 3minutes.xlsx') as writer:  
    RV_BTS_3m.to_excel(writer, sheet_name='Realized Variances')

dailyret_BTS_3m=np.sum(intraday_returns_BTS,axis=0)
with pd.ExcelWriter('dailyret BTS 3minutes.xlsx') as writer:  
    RV_BTS_3m.to_excel(writer, sheet_name='Daily Returns')    

#5 minutes
data_BTS=pd.read_csv('bts_5min.csv', sep=',' , header = None)
data_BTS = data_BTS.astype(float, errors='ignore')
day_BTS = np.unique(data_BTS[0])
time_BTS = data_BTS[1][:79].values
price_BTS = data_BTS[data_BTS.columns[2]].values

#intraday log returns per day
P_BTS = np.zeros([79,len(day_BTS)])
for i in range(len(day_BTS)):
    P_BTS[:,i] = price_BTS[i*79:(i+1)*79]
intraday_returns_BTS = np.diff(np.log(P_BTS),axis=0)

rv_BTS=np.sum(intraday_returns_BTS**2,axis=0)

RV_BTS_5m=pd.DataFrame(np.sum(intraday_returns_BTS**2,axis=0))
with pd.ExcelWriter('RV BTS 5minutes.xlsx') as writer:  
    RV_BTS_5m.to_excel(writer, sheet_name='Realized Variances')

dailyret_BTS_5m=np.sum(intraday_returns_BTS,axis=0)
with pd.ExcelWriter('dailyret BTS 5minutes.xlsx') as writer:  
    RV_BTS_5m.to_excel(writer, sheet_name='Daily Returns')
